# Jadikan APK (web tidak diubah sama sekali)

Semua file web sama persis dengan zip aslimu. Yang ditambahkan hanya folder `mobile/` dan `.github/`.
Alamat https://los-gk-bawel-ai-web.vercel.app sudah tertanam, jadi tidak ada yang perlu diisi.
Karena APK memuat web Vercel-mu langsung, semua fitur sama dan ikut ter-update tiap kamu deploy.

1. Upload seluruh isi folder ini ke repo GitHub (boleh repo yang sama dengan Vercel; folder mobile/.github tidak ikut ke Vercel).
2. Buka tab **Actions** → **Build APK Android** → **Run workflow**. Tunggu ±6 menit.
3. Buka hasil run itu → bagian **Artifacts** → unduh **Android-APK** → ekstrak → `LosGkBawelAI.apk`.
4. Kirim ke HP, izinkan "instal dari sumber tidak dikenal", pasang.

Catatan: login email jalan penuh; login Google/GitHub/Discord bisa terbuka di browser luar saat di APK. Mikrofon akan minta izin saat pertama dipakai.

## Windows (.exe)
Workflow yang sama juga membuat installer Windows: ambil **Windows-installer** di Artifacts
(`LosGkBawelAI-Setup-*.exe` untuk dipasang, `LosGkBawelAI-Portable-*.exe` tanpa instal). Alamat web juga sudah tertanam.
Tanpa build: di Chrome/Edge PC buka web-nya, klik ikon instal di kolom alamat (atau menu ⋮ → Instal).
