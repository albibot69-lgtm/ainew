// Los Gk Bawel AI untuk Windows: jendela native yang memuat web app (Vercel).
// Semua fitur, login, dan API tetap sama persis dengan versi web, dan otomatis ikut update.
const { app, BrowserWindow, shell, session, ipcMain, Menu, nativeTheme } = require('electron');
const path = require('path');
const fs = require('fs');

app.commandLine.appendSwitch('enable-gpu-rasterization');
app.commandLine.appendSwitch('enable-zero-copy');
app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('enable-features', 'CanvasOopRasterization,BackForwardCache');
nativeTheme.themeSource = 'dark';

const BG = '#14151a';
const userFile = () => path.join(app.getPath('userData'), 'settings.json');
const readJSON = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return d; } };
const writeJSON = (f, v) => { try { fs.writeFileSync(f, JSON.stringify(v)); } catch (e) { /* abaikan */ } };

function normUrl(u) {
  u = String(u || '').trim();
  if (!u) return '';
  if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
  try { const x = new URL(u); if (!/^https?:$/.test(x.protocol)) return ''; return x.origin + '/'; } catch (e) { return ''; }
}
function appUrl() {
  const env = normUrl(process.env.LGB_APP_URL);
  if (env) return env;
  const user = normUrl(readJSON(userFile(), {}).appUrl);
  if (user) return user;
  return normUrl(readJSON(path.join(__dirname, 'app.config.json'), {}).appUrl);
}

if (!app.requestSingleInstanceLock()) { app.quit(); }
let win = null;
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

function bounds() {
  const b = readJSON(path.join(app.getPath('userData'), 'window.json'), null);
  return b && b.width > 300 ? b : { width: 1180, height: 800 };
}
function saveBounds() {
  if (!win || win.isDestroyed()) return;
  const m = win.isMaximized();
  const b = m ? (readJSON(path.join(app.getPath('userData'), 'window.json'), {})) : win.getBounds();
  writeJSON(path.join(app.getPath('userData'), 'window.json'), Object.assign({}, b, { maximized: m }));
}

function sameSite(u, base) { try { return new URL(u).origin === new URL(base).origin; } catch (e) { return false; } }
// Domain login yang boleh dibuka sebagai popup di dalam aplikasi (hasilnya dikirim balik ke /oauth.html)
const AUTH_HOSTS = /(^|\.)(supabase\.co|accounts\.google\.com|github\.com|discord\.com)$/i;

function create() {
  const url = appUrl();
  const st = bounds();
  win = new BrowserWindow({
    width: st.width, height: st.height, x: st.x, y: st.y, minWidth: 380, minHeight: 560,
    backgroundColor: BG, show: false, autoHideMenuBar: true, title: 'Los Gk Bawel AI',
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: true, backgroundThrottling: true }
  });
  Menu.setApplicationMenu(null);
  if (st.maximized) win.maximize();
  win.once('ready-to-show', () => win.show()); // tidak ada kilatan putih saat dibuka
  ['resize', 'move', 'close'].forEach((e) => win.on(e, saveBounds));

  win.webContents.setWindowOpenHandler(({ url: u }) => {
    let host = ''; try { host = new URL(u).hostname; } catch (e) { return { action: 'deny' }; }
    if ((url && sameSite(u, url)) || AUTH_HOSTS.test(host)) {
      return { action: 'allow', overrideBrowserWindowOptions: { width: 520, height: 700, autoHideMenuBar: true, backgroundColor: BG, webPreferences: { sandbox: true, contextIsolation: true } } };
    }
    if (/^https?:/i.test(u)) shell.openExternal(u);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, u) => {
    if (u.startsWith('file:')) return;
    if (url && sameSite(u, url)) return;
    if (AUTH_HOSTS.test(new URL(u).hostname)) return;
    e.preventDefault(); if (/^https?:/i.test(u)) shell.openExternal(u);
  });
  win.webContents.on('did-fail-load', (e, code, desc, failedUrl, isMain) => {
    if (!isMain || code === -3) return;
    win.loadFile(path.join(__dirname, 'offline.html'), { query: { u: failedUrl || url } });
  });
  win.webContents.on('render-process-gone', () => { try { win.reload(); } catch (e) { /* abaikan */ } });

  if (!url) win.loadFile(path.join(__dirname, 'setup.html'));
  else win.loadURL(url, { userAgent: win.webContents.getUserAgent().replace(/\sElectron\/\S+/, '') });
}

app.whenReady().then(() => {
  const allowed = new Set(['media', 'audioCapture', 'clipboard-sanitized-write', 'clipboard-read', 'notifications', 'fullscreen', 'display-capture']);
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb, details) => {
    const origin = (details && details.requestingUrl) || wc.getURL();
    cb(allowed.has(perm) && (sameSite(origin, appUrl() || 'https://invalid.invalid') || origin.startsWith('file:')));
  });
  session.defaultSession.setPermissionCheckHandler((wc, perm) => allowed.has(perm));

  ipcMain.handle('lgb:setUrl', (e, u) => {
    const n = normUrl(u); if (!n) return { ok: false };
    writeJSON(userFile(), Object.assign(readJSON(userFile(), {}), { appUrl: n }));
    if (win) win.loadURL(n);
    return { ok: true };
  });
  ipcMain.handle('lgb:retry', (e, u) => { const n = normUrl(u) || appUrl(); if (win && n) win.loadURL(n); });
  ipcMain.handle('lgb:reset', () => { writeJSON(userFile(), {}); if (win) win.loadFile(path.join(__dirname, 'setup.html')); });
  create();
  app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) create(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
