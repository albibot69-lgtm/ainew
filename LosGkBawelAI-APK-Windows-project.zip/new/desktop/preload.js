const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('lgbDesktop', {
  setUrl: (u) => ipcRenderer.invoke('lgb:setUrl', u),
  retry: (u) => ipcRenderer.invoke('lgb:retry', u),
  reset: () => ipcRenderer.invoke('lgb:reset')
});
