// AnimatedList (port vanilla dari React Bits): daftar dengan animasi masuk saat scroll,
// indikator seleksi berpegas, fade tepi, dan navigasi keyboard.
// AnimatedList(container, opts) -> { setItems(items), select(i), destroy() }
(function () {
  const THEMES = {
    dark: { '--al-frame': 'rgba(38,35,46,.66)', '--al-frame-edge': 'rgba(255,255,255,.08)', '--al-frame-highlight': 'rgba(255,255,255,.07)', '--al-frame-shadow': '0 22px 44px -20px rgba(0,0,0,.8),0 6px 16px -8px rgba(0,0,0,.5)', '--al-tile': 'linear-gradient(180deg,#3a3644 0%,#27242f 100%)', '--al-tile-edge': 'rgba(255,255,255,.07)', '--al-tile-highlight': 'rgba(255,255,255,.12)', '--al-tile-shadow': '0 4px 10px -4px rgba(0,0,0,.7)', '--al-well': 'rgba(255,255,255,.08)', '--al-ink': '#f4f4f5', '--al-muted': 'rgba(244,244,245,.55)', '--al-thumb': 'rgba(255,255,255,.16)', '--al-ring': 'rgba(244,244,245,.3)', '--al-ring-fill': 'rgba(244,244,245,.05)', '--al-hover': 'brightness(1.12)', '--al-press': 'brightness(.85)', '--al-active': 'brightness(1.16)' },
    light: { '--al-frame': 'rgba(240,240,243,.8)', '--al-frame-edge': 'rgba(24,24,27,.07)', '--al-frame-highlight': 'rgba(255,255,255,.95)', '--al-frame-shadow': '0 22px 44px -22px rgba(24,24,27,.3),0 6px 16px -10px rgba(24,24,27,.16)', '--al-tile': 'linear-gradient(180deg,#fff 0%,#f6f6f8 100%)', '--al-tile-edge': 'rgba(24,24,27,.08)', '--al-tile-highlight': '#fff', '--al-tile-shadow': '0 4px 10px -5px rgba(24,24,27,.25)', '--al-well': 'rgba(24,24,27,.05)', '--al-ink': '#27272a', '--al-muted': 'rgba(39,39,42,.55)', '--al-thumb': 'rgba(24,24,27,.16)', '--al-ring': 'rgba(24,24,27,.28)', '--al-ring-fill': 'transparent', '--al-hover': 'brightness(.97)', '--al-press': 'brightness(.92)', '--al-active': 'none' }
  };
  const HIDDEN = {
    pop: { above: 'translate3d(0,-12px,0) scale(.8)', below: 'translate3d(0,12px,0) scale(.8)' },
    slide: { above: 'translate3d(0,-28px,0) scale(.98)', below: 'translate3d(0,28px,0) scale(.98)' },
    fade: { above: 'translate3d(0,-4px,0)', below: 'translate3d(0,4px,0)' }
  };
  const SPRING = 'linear(0,.0603,.2033,.3821,.5633,.7258,.8584,.9574,1.0242,1.0634,1.0809,1.0828,1.0747,1.0613,1.046,1.0313,1.0186,1.0085,1.0012,.9965,.994,.9931,.9933,.9941,.9953,.9966,.9978,.9988,1)';
  const sm = (t) => t * t * t * (t * (t * 6 - 15) + 10);
  const FADE_MASK = (() => {
    const steps = [0, .15, .3, .45, .6, .75, .9, 1];
    const top = steps.map((t) => `rgba(0,0,0,${sm(t).toFixed(3)}) calc(var(--al-fade-top) * ${t})`);
    const bot = [...steps].reverse().map((t) => `rgba(0,0,0,${sm(t).toFixed(3)}) calc(100% - var(--al-fade-bottom) * ${t})`);
    return `linear-gradient(to bottom,${[...top, ...bot].join(',')})`;
  })();
  const px = (v) => (typeof v === 'number' ? v + 'px' : v);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  function AnimatedList(container, o) {
    o = Object.assign({ items: [], onItemSelect: null, initialSelectedIndex: -1, selectOnHover: true, enableArrowNavigation: true, loop: false, animation: 'pop', animateOnce: false, stagger: 0.05, showGradients: true, fadeSize: 40, frame: false, theme: null, radius: 14, gap: 8, width: '100%', maxHeight: 360 }, o || {});
    const theme = o.theme || (document.documentElement.dataset.theme || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
    const root = document.createElement('div');
    root.className = 'animated-list' + (o.frame ? ' animated-list--framed' : '');
    if (o.animation !== 'none') root.setAttribute('data-animated', '');
    const vars = Object.assign({}, THEMES[theme] || THEMES.dark, { '--al-radius': o.radius + 'px', '--al-gap': o.gap + 'px', '--al-width': px(o.width), '--al-accent': o.accentColor || 'var(--al-ink)' });
    if (o.accentColor) { vars['--al-ring'] = o.accentColor; vars['--al-ring-fill'] = `color-mix(in srgb, ${o.accentColor} 8%, transparent)`; }
    Object.keys(vars).forEach((k) => root.style.setProperty(k, vars[k]));
    root.innerHTML = '<div class="animated-list__viewport" role="listbox" tabindex="0"><div class="animated-list__track"><span class="animated-list__indicator" aria-hidden="true"><span class="animated-list__ring"></span></span></div></div>';
    const viewport = root.firstChild, track = viewport.firstChild, indicator = track.firstChild, ring = indicator.firstChild;
    viewport.style.maxHeight = px(o.maxHeight);
    if (o.showGradients) { viewport.style.maskImage = FADE_MASK; viewport.style.webkitMaskImage = FADE_MASK; }
    container.appendChild(root);

    let items = [], els = [], selected = o.initialSelectedIndex;
    const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const ease = (window.CSS && CSS.supports && CSS.supports('transition-timing-function', 'linear(0,1)')) ? SPRING : 'cubic-bezier(.34,1.4,.64,1)';
    const transition = `transform 620ms ${ease}, opacity 300ms cubic-bezier(.22,1,.36,1), filter 200ms ease`;
    const motion = { y: 0, h: 0, vy: 0, vh: 0, ty: 0, th: 0, ready: false };
    const fades = { top: '', bottom: '' };
    let boxes = [], current = null, entered = false, engaged = false, pointer = [0, 0], raf = 0, last = 0, keyboard = false, navigating = false, dead = false;

    const mode = () => (o.animation === 'none' || !HIDDEN[o.animation]) ? 'none' : (reduced ? 'fade' : o.animation);
    const apply = (el, state) => {
      el.dataset.state = state;
      const pose = current && current !== 'none' && state !== 'in' ? HIDDEN[current][state] : '';
      el.style.transform = pose; el.style.opacity = pose ? '0' : '';
    };
    const syncRing = () => {
      const it = els[selected]; if (!it) return;
      const st = it.dataset.state || 'in'; if (st === ring.dataset.state) return;
      ring.style.transitionDelay = it.style.transitionDelay; apply(ring, st);
    };
    const write = () => { indicator.style.transform = `translate3d(0,${motion.y.toFixed(2)}px,0)`; indicator.style.height = motion.h.toFixed(2) + 'px'; };
    const frame = (now) => {
      raf = 0;
      const dt = Math.min(.05, (now - last) / 1000 || 0); last = now;
      const omega = 30, zeta = .78, steps = Math.max(1, Math.ceil(dt / (1 / 240))), h = dt / steps;
      for (let i = 0; i < steps; i++) {
        motion.vy += (omega * omega * (motion.ty - motion.y) - 2 * zeta * omega * motion.vy) * h;
        motion.vh += (omega * omega * (motion.th - motion.h) - 2 * zeta * omega * motion.vh) * h;
        motion.y += motion.vy * h; motion.h += motion.vh * h;
      }
      const moving = Math.abs(motion.ty - motion.y) > .05 || Math.abs(motion.th - motion.h) > .05 || Math.abs(motion.vy) + Math.abs(motion.vh) > .5;
      if (!moving) { motion.y = motion.ty; motion.h = motion.th; motion.vy = motion.vh = 0; }
      write();
      if (moving) raf = requestAnimationFrame(frame);
    };
    const place = (snap) => {
      const it = els[selected];
      if (!it) { indicator.style.opacity = '0'; motion.ready = false; return; }
      indicator.style.opacity = '1';
      motion.ty = it.offsetTop; motion.th = it.offsetHeight;
      if (snap || reduced || !motion.ready) { motion.y = motion.ty; motion.h = motion.th; motion.vy = motion.vh = 0; motion.ready = true; write(); return; }
      if (!raf) { last = performance.now(); raf = requestAnimationFrame(frame); }
    };
    const updateFades = () => {
      const span = Math.max(1, o.fadeSize), { scrollTop, scrollHeight, clientHeight } = viewport;
      const t = o.showGradients ? Math.min(span, Math.max(0, scrollTop)) : 0;
      const b = o.showGradients ? Math.min(span, Math.max(0, scrollHeight - clientHeight - scrollTop)) : 0;
      const nt = t.toFixed(1) + 'px', nb = b.toFixed(1) + 'px';
      if (nt !== fades.top) { fades.top = nt; viewport.style.setProperty('--al-fade-top', nt); }
      if (nb !== fades.bottom) { fades.bottom = nb; viewport.style.setProperty('--al-fade-bottom', nb); }
    };
    const measure = () => { const off = track.offsetTop; boxes = els.map((it) => (it ? [off + it.offsetTop, it.offsetHeight] : null)); };
    const reveal = (entrance) => {
      if (!entered) return;
      const top = viewport.scrollTop, view = viewport.clientHeight; let order = 0;
      els.forEach((it, i) => {
        const box = boxes[i]; if (!it || !box) return;
        const start = box[0] - top, overlap = Math.min(view, start + box[1]) - Math.max(0, start);
        const hidden = current !== 'none' && overlap < Math.min(box[1], view) * .5 && !(o.animateOnce && it.dataset.seen);
        const state = hidden ? (start + box[1] / 2 < view / 2 ? 'above' : 'below') : 'in';
        if (state === it.dataset.state) return;
        const delay = entrance && !hidden ? (order++ * Math.max(0, o.stagger)).toFixed(3) : 0;
        it.style.transitionDelay = delay ? `${delay}s, ${delay}s, 0s` : '';
        if (!hidden) it.dataset.seen = 'true';
        apply(it, state);
      });
      syncRing();
    };
    const sync = () => {
      const next = mode(), changed = next !== current;
      const restyle = changed ? els : els.filter((it) => !it.dataset.state);
      current = next;
      if (current === 'none') entered = true;
      if (restyle.length) {
        const all = changed ? [...restyle, ring] : restyle;
        all.forEach((e) => { e.style.transition = 'none'; });
        restyle.forEach((it) => apply(it, current === 'none' ? 'in' : it.dataset.state || 'below'));
        if (changed) apply(ring, (els[selected] && els[selected].dataset.state) || 'in');
        void root.offsetHeight;
        all.forEach((e) => { e.style.transition = transition; });
      }
      measure(); reveal(restyle.length > 0);
    };

    function build() {
      els.forEach((e) => e.remove()); els = [];
      items.forEach((raw, i) => {
        const it = raw !== null && typeof raw === 'object' ? raw : { title: raw };
        const el = document.createElement('div');
        el.className = 'animated-list__item'; el.setAttribute('role', 'option'); el.dataset.index = i;
        el.innerHTML = (it.icon ? '<span class="animated-list__lead">' + it.icon + '</span>' : '') +
          '<span class="animated-list__text"><span class="animated-list__title">' + esc(it.title) + '</span>' +
          (it.description ? '<span class="animated-list__description">' + esc(it.description) + '</span>' : '') + '</span>' +
          (it.meta ? '<span class="animated-list__meta">' + esc(it.meta) + '</span>' : '') +
          (it.actions || []).map((a, j) => '<button type="button" class="animated-list__act" data-act="' + j + '" title="' + esc(a.title) + '">' + a.icon + '</button>').join('') +
          '<span class="animated-list__rim" aria-hidden="true"></span>';
        el.addEventListener('pointerenter', () => { if (o.selectOnHover && !navigating) select(i, false); });
        el.addEventListener('click', (e) => {
          const b = e.target.closest('.animated-list__act');
          if (b) { e.stopPropagation(); const a = (it.actions || [])[+b.dataset.act]; a && a.onClick && a.onClick(it, i, e); return; }
          select(i, false); o.onItemSelect && o.onItemSelect(raw, i);
        });
        el.addEventListener('contextmenu', (e) => { if (!o.onContextMenu) return; e.preventDefault(); select(i, false); o.onContextMenu(raw, i, e); });
        track.insertBefore(el, indicator); els.push(el);
      });
      if (selected >= items.length) selected = -1;
      els.forEach((e, i) => { e.dataset.selected === undefined; if (i === selected) e.setAttribute('data-selected', ''); e.setAttribute('aria-selected', i === selected); });
      sync(); updateFades(); place(true); syncRing();
    }
    function select(i, byKey) {
      if (i === selected) return;
      if (els[selected]) { els[selected].removeAttribute('data-selected'); els[selected].setAttribute('aria-selected', 'false'); }
      selected = i;
      if (els[i]) { els[i].setAttribute('data-selected', ''); els[i].setAttribute('aria-selected', 'true'); }
      place(false); syncRing();
      if (!byKey || !els[i]) return;
      const it = els[i], top = track.offsetTop + it.offsetTop, bottom = top + it.offsetHeight;
      const room = Math.max(0, (viewport.clientHeight - it.offsetHeight) / 2);
      const margin = Math.min(o.showGradients ? Math.max(12, o.fadeSize) : 12, room);
      if (top < viewport.scrollTop + margin) viewport.scrollTo({ top: Math.max(0, top - margin), behavior: 'smooth' });
      else if (bottom > viewport.scrollTop + viewport.clientHeight - margin) viewport.scrollTo({ top: bottom - viewport.clientHeight + margin, behavior: 'smooth' });
    }

    const gate = typeof IntersectionObserver === 'undefined' ? null : new IntersectionObserver((entries, ob) => {
      if (!entries.some((e) => e.isIntersecting)) return;
      ob.disconnect(); if (entered) return; entered = true; measure(); reveal(true);
    }, { rootMargin: '0px 0px -10% 0px' });
    const ro = new ResizeObserver(() => { place(true); updateFades(); measure(); reveal(false); });
    ro.observe(viewport); ro.observe(track);
    const onScroll = () => { updateFades(); reveal(false); };
    const onKey = (e) => {
      if (!o.enableArrowNavigation || e.defaultPrevented || e.altKey || e.ctrlKey || e.metaKey) return;
      const a = document.activeElement, focused = a === viewport, idle = !a || a === document.body || a === document.documentElement;
      if (!focused && !(engaged && idle)) return;
      const n = items.length; if (!n) return;
      let next = null;
      if (e.key === 'ArrowDown') next = selected < 0 ? 0 : selected + 1;
      else if (e.key === 'ArrowUp') next = selected < 0 ? n - 1 : selected - 1;
      else if (e.key === 'Home') next = 0; else if (e.key === 'End') next = n - 1;
      else if ((e.key === 'Enter' || (focused && e.key === ' ')) && selected >= 0 && selected < n) { e.preventDefault(); o.onItemSelect && o.onItemSelect(items[selected], selected); return; }
      if (next === null) return;
      e.preventDefault();
      next = o.loop ? (next + n) % n : Math.min(n - 1, Math.max(0, next));
      navigating = true; select(next, true);
    };
    const onMove = (e) => {
      const moved = e.clientX !== pointer[0] || e.clientY !== pointer[1]; pointer = [e.clientX, e.clientY];
      if (!navigating || !moved) return;
      navigating = false;
      const it = e.target instanceof Element ? e.target.closest('[data-index]') : null;
      if (it && root.contains(it) && o.selectOnHover) select(Number(it.dataset.index), false);
    };
    viewport.addEventListener('scroll', onScroll, { passive: true });
    document.addEventListener('keydown', onKey, true);
    root.addEventListener('pointerenter', () => { engaged = true; });
    root.addEventListener('pointerleave', () => { engaged = false; });
    root.addEventListener('pointermove', onMove);

    items = o.items; build();
    if (!entered) { if (gate) gate.observe(root); else { entered = true; reveal(true); } }
    return {
      el: root, ok: true,
      setItems(next) { items = next; build(); },
      select: (i) => select(i, true),
      getSelected: () => selected,
      itemEl: (i) => els[i],
      focus: () => viewport.focus(),
      destroy() { if (dead) return; dead = true; cancelAnimationFrame(raf); gate && gate.disconnect(); ro.disconnect(); document.removeEventListener('keydown', onKey, true); root.remove(); }
    };
  }
  window.AnimatedList = AnimatedList;
})();
