// Halaman masuk/daftar di awal, jatah tamu vs anggota, dan blokir foto untuk tamu.
(function () {
  if (!window.LGB_WEB) return;
  const $ = (s, r) => (r || document).querySelector(s);
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const SS = { get: (k) => { try { return sessionStorage.getItem(k); } catch (e) { return null; } }, set: (k, v) => { try { sessionStorage.setItem(k, v); } catch (e) { /* abaikan */ } }, del: (k) => { try { sessionStorage.removeItem(k); } catch (e) { /* abaikan */ } } };
  let sess = null, quota = null, gateEl = null, bar = null, mode = 'in', busy = false, ready = false;

  const isIn = () => !!sess;
  window.lgbImageOk = function () {
    if (isIn()) return true;
    toast(TT('needImg'));
    openGate(TT('needImg'));
    return false;
  };
  window.lgbAuthHeader = async function () {
    try {
      const s = await Acct.session();
      if (!s) return '';
      if (s.kind === 'google') return 'g.' + (await Acct.googleToken());
      return 'sb.' + s.access_token;
    } catch (e) { return ''; }
  };

  function toast(t) { try { add('note', t); } catch (e) { /* abaikan */ } }

  async function refresh() {
    try { sess = await Acct.session(); } catch (e) { sess = null; }
    ready = true; renderBar();
    return sess;
  }

  // ---------- bar status di atas kolom tulis ----------
  function renderBar() {
    const form = $('#form'); if (!form) return;
    if (!bar) { bar = document.createElement('div'); bar.id = 'lgbBar'; form.parentNode.insertBefore(bar, form); }
    const q = quota && quota.limit ? ' · ' + Math.min(quota.used, quota.limit) + '/' + quota.limit + ' ' + TT('barToday') : '';
    if (isIn()) {
      const nm = (sess.user && (sess.user.email || sess.user.name)) || 'Akunmu';
      bar.className = 'in';
      bar.innerHTML = '<span class="dotk"></span><span class="t">' + esc(nm) + esc(q) + '</span><button type="button" id="lgbOut">' + esc(TT('logout')) + '</button>';
      $('#lgbOut', bar).onclick = signOut;
    } else {
      bar.className = 'guest';
      bar.innerHTML = '<span class="t">' + esc(TT('barGuest')) + esc(q) + ' · ' + esc(TT('barSub')) + '</span><button type="button" id="lgbIn">' + esc(TT('signinUp')) + '</button>';
      $('#lgbIn', bar).onclick = () => openGate();
    }
  }
  window.addEventListener('lgb-quota', (e) => { quota = e.detail; renderBar(); });
  window.addEventListener('lgb-denied', (e) => {
    const d = e.detail || {};
    if (!isIn() && (d.code === 'lgb_guest_image' || d.code === 'lgb_daily')) openGate(d.message);
  });

  async function signOut() {
    try { await Acct.signOut(); } catch (e) { /* abaikan */ }
    SS.del('lgbGuest'); sess = null; quota = null; renderBar(); openGate();
  }

  // ---------- kekuatan password ----------
  const COMMON = /^(password|passw0rd|qwerty|qwertyuiop|asdfgh|zxcvbn|letmein|welcome|admin|iloveyou|abc123|monkey|dragon|master|login|111111|123123|123456|12345678|123456789|1234567890|000000|bismillah|rahasia|indonesia|sayang)/i;
  function strength(pw, email) {
    let s = 0; const len = pw.length;
    const cls = [/[a-z]/, /[A-Z]/, /\d/, /[^A-Za-z0-9]/].filter((r) => r.test(pw)).length;
    if (len >= 8) s++; if (len >= 11) s++; if (cls >= 3) s++; if (len >= 14 && cls >= 3) s++;
    const local = String(email || '').split('@')[0].toLowerCase();
    if (COMMON.test(pw) || /^(.)\1+$/.test(pw) || /(0123|1234|2345|3456|4567|5678|6789|abcd|qwer)/i.test(pw) && len < 14 || (local.length > 3 && pw.toLowerCase().includes(local))) s = Math.min(s, 1);
    if (len < 8) s = 0;
    return s;
  }
  const PW = ['pwWeak', 'pwWeak', 'pwFair', 'pwGood', 'pwStrong'];

  // ---------- gerbang masuk ----------
  const TT = (k) => (window.T ? window.T(k) : k);
  function build() {
    gateEl = document.createElement('div');
    gateEl.id = 'lgbGate'; gateEl.setAttribute('role', 'dialog'); gateEl.setAttribute('aria-modal', 'true');
    gateEl.hidden = true;
    gateEl.innerHTML =
      '<div class="gcard">' +
      '<img class="glogo" src="avatar.png" alt="">' +
      '<h2>Los Gk Bawel AI</h2>' +
      '<p class="gsub" id="gSub" data-i18n="gSub"></p>' +
      '<div class="gtabs" role="tablist"><button type="button" data-m="in" class="on" data-i18n="tIn"></button><button type="button" data-m="up" data-i18n="tUp"></button></div>' +
      '<form id="gForm" autocomplete="on" novalidate>' +
      '<label><span data-i18n="email"></span><input id="gEmail" type="email" inputmode="email" autocomplete="email" placeholder="you@email.com" required></label>' +
      '<label><span data-i18n="pass"></span><span class="gpw"><input id="gPass" type="password" autocomplete="current-password" data-i18n-ph="passPh" minlength="8" required><button type="button" id="gEye" aria-label="Show password"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg></button></span></label>' +
      '<div class="gmeter" id="gMeter" hidden><i></i><i></i><i></i><i></i><b id="gMeterT"></b></div>' +
      '<div class="gmsg" id="gMsg" role="alert" hidden></div>' +
      '<button type="submit" class="gmain" id="gGo"></button>' +
      '</form>' +
      '<div class="gor" id="gOr"><span data-i18n="or"></span></div>' +
      '<div id="gSocial"></div>' +
      '<button type="button" class="gguest" id="gGuest"><span data-i18n="guest"></span> <small data-i18n="guestSub"></small></button>' +
      '</div>';
    document.body.appendChild(gateEl);
    gateEl.querySelectorAll('.gtabs button').forEach((b) => { b.onclick = () => setMode(b.dataset.m); });
    $('#gForm', gateEl).addEventListener('submit', (e) => { e.preventDefault(); submit(); });
    socials();
    $('#gGuest', gateEl).onclick = () => { SS.set('lgbGuest', '1'); closeGate(); };
    $('#gEye', gateEl).onclick = () => { const i = $('#gPass', gateEl); i.type = i.type === 'password' ? 'text' : 'password'; };
    $('#gPass', gateEl).addEventListener('input', meter);
    $('#gEmail', gateEl).addEventListener('input', meter);
    setMode('in');
    if (window.LGB_I18N) window.LGB_I18N.apply();
  }
  function meter() {
    const m = $('#gMeter', gateEl), pw = $('#gPass', gateEl).value;
    m.hidden = mode !== 'up' || !pw;
    if (m.hidden) return;
    const s = strength(pw, $('#gEmail', gateEl).value);
    m.dataset.s = s; $('#gMeterT', m).textContent = TT(PW[s]);
    m.querySelectorAll('i').forEach((el, k) => el.classList.toggle('on', k < Math.max(1, s)));
  }
  function setMode(m) {
    mode = m;
    gateEl.querySelectorAll('.gtabs button').forEach((b) => b.classList.toggle('on', b.dataset.m === m));
    $('#gGo', gateEl).textContent = TT(m === 'in' ? 'bIn' : 'bUp');
    $('#gPass', gateEl).autocomplete = m === 'in' ? 'current-password' : 'new-password';
    msg(''); meter();
  }
  window.addEventListener('lgb-lang', () => { if (gateEl) { setMode(mode); } renderBar(); });
  function msg(t, ok) { const m = $('#gMsg', gateEl); m.hidden = !t; m.textContent = t || ''; m.className = 'gmsg' + (ok ? ' ok' : ''); }
  function setBusy(b) { busy = b; $('#gGo', gateEl).disabled = b; gateEl.querySelectorAll('.gg').forEach((x) => { x.disabled = b; }); $('#gGo', gateEl).textContent = b ? TT('wait') : TT(mode === 'in' ? 'bIn' : 'bUp'); }

  async function done() {
    await refresh(); closeGate();
    try { await Acct.sync(); } catch (e) { /* abaikan */ }
    await new Promise((r) => setTimeout(r, 300)); // beri waktu sesi tersimpan ke IndexedDB
    location.reload(); // muat riwayat yang tersinkron
  }
  async function submit() {
    if (busy) return;
    const email = $('#gEmail', gateEl).value.trim(), pass = $('#gPass', gateEl).value;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return msg(TT('eEmail'));
    if (pass.length < 8 && mode === 'up') return msg(TT('ePass'));
    if (!pass) return msg(TT('ePass'));
    if (mode === 'up' && strength(pass, email) < 2) return msg(TT('eWeak'));
    setBusy(true); msg('');
    try {
      if (mode === 'in') { await Acct.signIn(email, pass); await done(); }
      else {
        const r = await Acct.signUp(email, pass);
        // pendaftaran TIDAK langsung masuk: email harus dikonfirmasi dulu lewat link yang dikirim ke kotak masuk
        if (r.signedIn) { try { await Acct.signOut(); } catch (e) { /* abaikan */ } }
        setBusy(false); setMode('in'); msg(TT('okSignup'), true); return;
      }
    } catch (e) { msg((e && e.message) || 'Error'); }
    setBusy(false);
  }
  // tombol login sosial hanya muncul bila provider-nya aktif di Supabase (tidak perlu Google Cloud)
  const PROV = { google: 'Google', github: 'GitHub', discord: 'Discord' };
  const PIC = { github: '<path fill="currentColor" d="M12 .5a11.5 11.5 0 0 0-3.6 22.4c.6.1.8-.3.8-.6v-2c-3.2.7-3.9-1.4-3.9-1.4-.5-1.3-1.3-1.7-1.3-1.7-1-.7.1-.7.1-.7 1.2.1 1.8 1.2 1.8 1.2 1 1.8 2.8 1.3 3.5 1 .1-.8.4-1.3.8-1.6-2.6-.3-5.3-1.3-5.3-5.7 0-1.3.5-2.3 1.2-3.1-.1-.3-.5-1.5.1-3.1 0 0 1-.3 3.2 1.2a11 11 0 0 1 5.8 0c2.2-1.5 3.2-1.2 3.2-1.2.6 1.6.2 2.8.1 3.1.8.8 1.2 1.8 1.2 3.1 0 4.4-2.7 5.4-5.3 5.7.4.4.8 1.1.8 2.2v3.2c0 .3.2.7.8.6A11.5 11.5 0 0 0 12 .5z"/>', discord: '<path fill="#5865F2" d="M20.3 4.4A19 19 0 0 0 15.7 3l-.2.4a17 17 0 0 1 4 1.9 14 14 0 0 0-15 0 17 17 0 0 1 4-1.9L8.3 3a19 19 0 0 0-4.6 1.4C.8 8.7 0 12.9.4 17a19 19 0 0 0 5.7 2.9l1.2-2a12 12 0 0 1-1.9-.9l.5-.4a13.6 13.6 0 0 0 11.8 0l.5.4a12 12 0 0 1-1.9.9l1.2 2a19 19 0 0 0 5.7-2.9c.5-4.8-.8-9-3.4-12.6zM8.5 14.5c-1.1 0-2-1-2-2.2s.9-2.2 2-2.2 2 1 2 2.2-.9 2.2-2 2.2zm7 0c-1.1 0-2-1-2-2.2s.9-2.2 2-2.2 2 1 2 2.2-.9 2.2-2 2.2z"/>', google: '<path fill="#4285F4" d="M23 12.3c0-.8-.1-1.5-.2-2.2H12v4.2h6.2a5.3 5.3 0 0 1-2.3 3.5v2.9h3.7c2.2-2 3.4-5 3.4-8.4z"/><path fill="#34A853" d="M12 24c3.1 0 5.7-1 7.6-2.8l-3.7-2.9c-1 .7-2.3 1.1-3.9 1.1-3 0-5.5-2-6.4-4.8H1.8v3A12 12 0 0 0 12 24z"/><path fill="#FBBC05" d="M5.6 14.6a7.2 7.2 0 0 1 0-4.6V7H1.8a12 12 0 0 0 0 10.7z"/><path fill="#EA4335" d="M12 4.8c1.7 0 3.2.6 4.4 1.7l3.3-3.3A12 12 0 0 0 1.8 7l3.8 3c.9-2.8 3.4-5.2 6.4-5.2z"/>' };
  async function socials() {
    const box = $('#gSocial', gateEl), or = $('#gOr', gateEl); or.hidden = true;
    let on = [];
    try {
      const c = await Acct.cfg();
      const r = await fetch(c.url + '/auth/v1/settings', { headers: { apikey: c.key } });
      const j = r.ok ? await r.json() : null; const ex = (j && j.external) || {};
      on = Object.keys(PROV).filter((k) => ex[k]);
    } catch (e) { on = []; }
    box.innerHTML = on.map((k) => '<button type="button" class="gg" data-p="' + k + '"><svg width="18" height="18" viewBox="0 0 24 24">' + PIC[k] + '</svg><span>' + esc(TT('google').replace('Google', PROV[k])) + '</span></button>').join('');
    box.querySelectorAll('.gg').forEach((b) => { b.onclick = () => social(b.dataset.p); });
    or.hidden = !on.length;
  }
  async function social(p) {
    if (busy) return;
    setBusy(true); msg('');
    try { await Acct.oauth(p); await done(); }
    catch (e) { msg((e && e.message) || 'Sign-in failed.'); }
    setBusy(false);
  }
  function openGate(why) {
    if (!gateEl) build();
    $('#gSub', gateEl).textContent = why || TT('gSub');
    gateEl.hidden = false; document.documentElement.classList.add('gate-open');
    setTimeout(() => { try { $('#gEmail', gateEl).focus({ preventScroll: true }); } catch (e) { /* abaikan */ } }, 60);
  }
  function closeGate() { if (gateEl) gateEl.hidden = true; document.documentElement.classList.remove('gate-open'); }
  window.lgbOpenGate = openGate;
  window.lgbSession = () => sess;
  window.lgbSignOut = signOut;

  (async function init() {
    if (typeof Acct === 'undefined') return;
    await refresh();
    if (!isIn() && SS.get('lgbGuest') !== '1') openGate();
    // sesi habis / login dari tab lain
    try { chrome.storage.onChanged.addListener((c) => { if (c.acctSession) refresh(); }); } catch (e) { /* abaikan */ }
    setInterval(refresh, 60000);
  })();
})();
