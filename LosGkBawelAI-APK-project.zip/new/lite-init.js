// Mode anti lag & mode senyap (hanya popup). Dibaca sinkron dari localStorage agar efek berat tidak pernah sempat dibuat.
(function () {
  const isPopup = /(popup\.html|index\.html|\/)$/.test(location.pathname);
  let lite = false, disguise = false;
  try { lite = localStorage.getItem('lgbLite') === '1'; disguise = localStorage.getItem('lgbDisguise') === '1'; } catch (e) {}
  window.LGB_LITE = isPopup && lite;
  window.LGB_DISGUISE = isPopup && disguise;
  const root = document.documentElement;
  if (window.LGB_LITE) root.classList.add('lite');
  if (window.LGB_DISGUISE) root.classList.add('disguise');

  const sync = (s) => { try { localStorage.setItem('lgbLite', s.lite ? '1' : '0'); localStorage.setItem('lgbDisguise', s.disguise ? '1' : '0'); } catch (e) {} };
  const mismatch = (s) => !!s.lite !== !!window.LGB_LITE || !!s.disguise !== !!window.LGB_DISGUISE;

  if (isPopup && window.LGB_DISGUISE) {
    document.addEventListener('DOMContentLoaded', () => {
      document.title = 'Catatan';
      const t = document.querySelector('header .titles strong');
      if (t) t.textContent = 'Catatan';
    });
  }
  try {
    chrome.storage.local.get({ lite: false, disguise: false }).then((s) => {
      sync(s);
      if (isPopup) { try { chrome.action.setTitle({ title: s.disguise ? 'Catatan' : 'Los Gk Bawel AI' }); } catch (e) {} }
      if (isPopup && mismatch(s)) location.reload();
    });
    chrome.storage.onChanged.addListener((c, area) => {
      if (area !== 'local' || !(c.lite || c.disguise)) return;
      chrome.storage.local.get({ lite: false, disguise: false }).then((s) => { sync(s); if (isPopup && mismatch(s)) location.reload(); });
    });
  } catch (e) {}
})();
