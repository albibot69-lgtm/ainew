try { SpecularButtons("button.btn, button[data-mode]"); } catch (e) {}
