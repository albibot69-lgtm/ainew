// Jalankan: node --experimental-default-type=module tests/security.mjs   (atau: node tests/security.mjs jika package.json type=module)
import assert from 'node:assert/strict';
process.env.SUPABASE_SECRET_KEY = 'test-secret';
process.env.OWNER_EMAILS = 'boss@example.com';
process.env.OWNER_GITHUB = 'bossgh';
process.env.GROQ_API_KEY = 'gsk_test';
let fails = 0, n = 0;
const t = async (name, fn) => { n++; try { await fn(); console.log('ok   ', name); } catch (e) { fails++; console.log('FAIL ', name, '-', e.message); } };

// ---- fetch palsu: Supabase & upstream ----
const USERS = {
  tok_boss: { id: 'u-boss', email: 'boss@example.com', email_confirmed_at: 'x', identities: [{ provider: 'email', identity_data: { email_verified: true } }] },
  tok_unverified_boss: { id: 'u-fake', email: 'boss@example.com', identities: [{ provider: 'email', identity_data: { email_verified: false } }] },
  tok_user: { id: 'u-user', email: 'a@example.com', email_confirmed_at: 'x', identities: [{ provider: 'email' }] },
  tok_admin: { id: 'u-admin', email: 'adm@example.com', email_confirmed_at: 'x', identities: [{ provider: 'email' }] },
  tok_gh: { id: 'u-gh', email: 'x@y.z', identities: [{ provider: 'github', identity_data: { user_name: 'BossGH' } }] },
  tok_gh_other: { id: 'u-gh2', email: 'x@y.z', identities: [{ provider: 'github', identity_data: { user_name: 'someoneelse' } }] }
};
const calls = [];
globalThis.fetch = async (u, init = {}) => {
  u = String(u); calls.push({ u, init });
  const J = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { 'content-type': 'application/json' } });
  if (u.includes('/auth/v1/user')) { const tok = String((init.headers || {}).Authorization || '').replace('Bearer ', ''); return USERS[tok] ? J(USERS[tok]) : J({ error: 'bad' }, 401); }
  if (u.includes('/rpc/lgb_bump')) return J(1);
  if (u.includes('/rest/v1/lgb_roles')) return J([{ user_id: 'u-admin', email: 'adm@example.com', display_name: 'Adi Admin', role: 'admin' }]);
  if (u.includes('/auth/v1/admin/users')) return J({ users: [] });
  if (u.includes('/rest/v1/lgb_usage')) return J([]);
  if (u.includes('api.groq.com')) return J({ ok: true });
  return new Response('upstream', { status: 200 });
};
const req = (path, { method = 'GET', headers = {}, body } = {}) => new Request('https://app.test' + path, { method, headers, body });
const auth = (tok) => ({ 'x-lgb-auth': 'sb.' + tok });

const guard = await import('../api/_lib/guard.js');
const owner = (await import('../api/owner.js')).default;
const proxy = (await import('../api/proxy.js')).default;
const p = (await import('../api/p.js')).default;
const me = (await import('../api/me.js')).default;
const yt = await import('../api/yt.js');
const gem = await import('../api/_lib/gemini.js');
const search = (await import('../api/search.js')).default;

await t('who: token jelek ditolak', async () => { assert.equal(await guard.who(req('/', { headers: { 'x-lgb-auth': 'sb.nope' } })), null); assert.equal(await guard.who(req('/', { headers: { 'x-lgb-auth': 'garbage' } })), null); });
await t('who: token sangat panjang ditolak', async () => assert.equal(await guard.who(req('/', { headers: { 'x-lgb-auth': 'sb.' + 'a'.repeat(5000) } })), null));
await t('owner: email terverifikasi = owner', async () => assert.equal((await guard.roleOf(await guard.who(req('/', { headers: auth('tok_boss') })))).role, 'owner'));
await t('owner: email BELUM terverifikasi != owner', async () => assert.notEqual((await guard.roleOf(await guard.who(req('/', { headers: auth('tok_unverified_boss') })))).role, 'owner'));
await t('owner: github username cocok (case-insensitive)', async () => assert.equal((await guard.roleOf(await guard.who(req('/', { headers: auth('tok_gh') })))).role, 'owner'));
await t('owner: github lain bukan owner', async () => assert.equal((await guard.roleOf(await guard.who(req('/', { headers: auth('tok_gh_other') })))).role, 'user'));
await t('admin dikenali dari tabel', async () => assert.equal((await guard.roleOf(await guard.who(req('/', { headers: auth('tok_admin') })))).role, 'admin'));

await t('owner API: anonim -> 404', async () => assert.equal((await owner(req('/api/owner?a=stats'))).status, 404));
await t('owner API: user biasa -> 404', async () => assert.equal((await owner(req('/api/owner?a=stats', { headers: auth('tok_user') }))).status, 404));
await t('owner API: admin boleh GET', async () => assert.equal((await owner(req('/api/owner?a=stats', { headers: auth('tok_admin') }))).status, 200));
for (const a of ['ban', 'unban', 'delete', 'reset', 'announce', 'unannounce', 'grant', 'revoke']) {
  await t('owner API: admin POST ' + a + ' -> 403', async () => assert.equal((await owner(req('/api/owner?a=' + a, { method: 'POST', headers: Object.assign({ 'content-type': 'application/json' }, auth('tok_admin')), body: '{"id":"u-user","email":"a@example.com","text":"x"}' }))).status, 403));
  await t('owner API: user POST ' + a + ' -> 404', async () => assert.equal((await owner(req('/api/owner?a=' + a, { method: 'POST', headers: Object.assign({ 'content-type': 'application/json' }, auth('tok_user')), body: '{}' }))).status, 404));
}
await t('owner API: origin asing ditolak', async () => assert.equal((await owner(req('/api/owner?a=stats', { headers: Object.assign({ origin: 'https://evil.test' }, auth('tok_boss')) }))).status, 403));
await t('owner API: tidak membocorkan secret', async () => { const r = await owner(req('/api/owner?a=stats', { headers: auth('tok_boss') })); assert.ok(!(await r.text()).includes('test-secret')); });

await t('me: owner/admin/user', async () => {
  const g = async (tok) => (await (await me(req('/api/me', { headers: tok ? auth(tok) : {} }))).json());
  assert.equal((await g('tok_boss')).role, 'owner'); assert.equal((await g('tok_admin')).role, 'admin'); assert.equal((await g('tok_user')).role, 'user'); assert.equal((await g(null)).role, 'user');
  assert.ok(!JSON.stringify(await g('tok_admin')).includes('adm@example.com'), 'email admin tidak boleh bocor');
});

// ---- SSRF proxy ----
const BADU = ['https://127.0.0.1/', 'https://localhost/', 'https://169.254.169.254/latest/meta-data', 'https://10.0.0.1/', 'https://192.168.1.1/', 'https://172.16.0.1/', 'https://[::1]/', 'https://0x7f000001/', 'https://2130706433/', 'https://017700000001/', 'https://127.1/', 'https://foo.internal/', 'https://x.local/', 'https://user:pw@example.com/', 'http://example.com/', 'file:///etc/passwd', 'ftp://example.com/', 'https://100.64.0.1/', 'https://0.0.0.0/', 'https://app.test/api/proxy'];
for (const u of BADU) await t('proxy SSRF blok: ' + u, async () => { const r = await proxy(req('/api/proxy?u=' + encodeURIComponent(u), { headers: { origin: 'https://app.test' } })); assert.ok([400, 403].includes(r.status), 'status ' + r.status); });
await t('proxy: origin asing ditolak', async () => assert.equal((await proxy(req('/api/proxy?u=' + encodeURIComponent('https://example.com/'), { headers: { origin: 'https://evil.test' } }))).status, 403));
await t('proxy: POST tanpa origin ditolak', async () => assert.equal((await proxy(req('/api/proxy?u=' + encodeURIComponent('https://example.com/'), { method: 'POST', body: 'x' }))).status, 403));
await t('proxy: tujuan publik diizinkan', async () => assert.equal((await proxy(req('/api/proxy?u=' + encodeURIComponent('https://example.com/'), { headers: { origin: 'https://app.test' } }))).status, 200));
await t('proxy: redirect ke internal diblokir', async () => {
  const old = globalThis.fetch; globalThis.fetch = async (u, i) => String(u).startsWith('https://example.com') ? new Response('', { status: 302, headers: { location: 'http://169.254.169.254/' } }) : old(u, i);
  const r = await proxy(req('/api/proxy?u=' + encodeURIComponent('https://example.com/r'), { headers: { origin: 'https://app.test' } })); globalThis.fetch = old; assert.ok(r.status === 400 || r.status === 403, 'status ' + r.status);
});

// ---- proxy AI ----
await t('p: provider tak dikenal -> 404', async () => assert.equal((await p(req('/api/p?id=evil&path=x', { headers: { origin: 'https://app.test' } }))).status, 404));
await t('p: path traversal ditolak', async () => assert.equal((await p(req('/api/p?id=groq&path=' + encodeURIComponent('../../admin'), { headers: { origin: 'https://app.test' } }))).status, 400));
await t('p: origin asing ditolak', async () => assert.equal((await p(req('/api/p?id=groq&path=models', { headers: { origin: 'https://evil.test' } }))).status, 403));
await t('p: host upstream tetap (tidak bisa dibelokkan lewat path)', async () => {
  calls.length = 0; await p(req('/api/p?id=groq&path=' + encodeURIComponent('@evil.test/x'), { headers: { origin: 'https://app.test' } }));
  const c = calls.find((x) => /groq|evil/.test(x.u)); assert.ok(!c || new URL(c.u).hostname === 'api.groq.com', c && c.u);
});
await t('p: key server tidak bocor di respons', async () => { const r = await p(req('/api/p?id=groq&path=models', { headers: { origin: 'https://app.test', authorization: 'Bearer server' } })); assert.ok(!(await r.text()).includes('gsk_test')); });

// ---- limit ----
await t('gate: tamu kena 423 saat lewat batas', async () => {
  const old = globalThis.fetch; globalThis.fetch = async (u, i) => String(u).includes('lgb_bump') ? new Response('9999', { status: 200 }) : old(u, i);
  const r = await guard.gate(req('/', { headers: { 'x-real-ip': '1.2.3.4' } }), 'chat', 1); globalThis.fetch = old; assert.equal(r.res.status, 423);
});

// ---- search / yt ----
await t('search: query kosong 400', async () => assert.equal((await search(req('/api/search?q='))).status, 400));
await t('search: origin asing 403', async () => assert.equal((await search(req('/api/search?q=hi', { headers: { origin: 'https://evil.test' } }))).status, 403));
await t('yt videoId: valid & tidak valid', () => {
  assert.equal(yt.videoId('https://youtu.be/dQw4w9WgXcQ'), 'dQw4w9WgXcQ'); assert.equal(yt.videoId('https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=3'), 'dQw4w9WgXcQ');
  assert.equal(yt.videoId('https://evil.com/watch?v=dQw4w9WgXcQ'), ''); assert.equal(yt.videoId('javascript:alert(1)'), ''); assert.equal(yt.videoId('https://youtube.com.evil.com/watch?v=dQw4w9WgXcQ'), '');
});
await t('yt: link jelek 400', async () => assert.equal((await yt.default(req('/api/yt?u=' + encodeURIComponent('https://evil.com/x')))).status, 400));

// ---- Gemini adaptor ----
process.env.GEMINI_API_KEY = 'AQ.testkey';
await t('gemini: konversi pesan + gambar + system', () => {
  const { convert } = gem;
  const r = convert({ model: 'models/gemini-2.5-flash', max_tokens: 100, messages: [{ role: 'system', content: 'S' }, { role: 'user', content: [{ type: 'text', text: 'hi' }, { type: 'image_url', image_url: { url: 'data:image/png;base64,AAAA' } }] }, { role: 'assistant', content: 'yo' }, { role: 'user', content: 'x' }] });
  assert.equal(r.model, 'gemini-2.5-flash'); assert.equal(r.req.systemInstruction.parts[0].text, 'S');
  assert.equal(r.req.contents.length, 3); assert.ok(r.req.contents[0].parts[1].inlineData); assert.equal(r.req.contents[1].role, 'model'); assert.equal(r.req.generationConfig.maxOutputTokens, 100);
});
await t('gemini: nama model berbahaya diganti default', () => assert.equal(gem.convert({ model: '../../x?y', messages: [] }).model, 'gemini-3.8-flash'));
await t('gemini: p.js memakai x-goog-api-key & endpoint asli, streaming ke format OpenAI', async () => {
  const old = globalThis.fetch; let seen;
  globalThis.fetch = async (u, i) => {
    if (String(u).includes('generativelanguage')) { seen = { u: String(u), h: i.headers }; const sse = 'data: ' + JSON.stringify({ candidates: [{ content: { parts: [{ text: 'Halo ' }] } }] }) + '\n\n' + 'data: ' + JSON.stringify({ candidates: [{ content: { parts: [{ text: 'dunia' }] }, finishReason: 'STOP' }] }) + '\n\n'; return new Response(sse, { status: 200 }); }
    return old(u, i);
  };
  const r = await p(req('/api/p?id=gemini&path=chat/completions', { method: 'POST', headers: { origin: 'https://app.test', authorization: 'Bearer server', 'content-type': 'application/json' }, body: JSON.stringify({ model: 'gemini-2.5-flash', stream: true, messages: [{ role: 'user', content: 'hai' }] }) }));
  const txt = await r.text(); globalThis.fetch = old;
  assert.equal(r.status, 200); assert.ok(seen.u.includes(':streamGenerateContent?alt=sse')); assert.equal(seen.h['x-goog-api-key'], 'AQ.testkey'); assert.ok(!/authorization/i.test(JSON.stringify(seen.h)));
  assert.ok(txt.includes('"content":"Halo "') && txt.includes('"content":"dunia"') && txt.includes('[DONE]'));
});
await t('gemini: error upstream 404 jadi pesan JSON yang jelas', async () => {
  const old = globalThis.fetch; globalThis.fetch = async (u, i) => String(u).includes('generativelanguage') ? new Response(JSON.stringify({ error: { message: 'model not found' } }), { status: 404 }) : old(u, i);
  const r = await p(req('/api/p?id=gemini&path=chat/completions', { method: 'POST', headers: { origin: 'https://app.test', authorization: 'Bearer server', 'content-type': 'application/json' }, body: JSON.stringify({ model: 'nope', messages: [{ role: 'user', content: 'hai' }] }) }));
  const j = await r.json(); globalThis.fetch = old; assert.ok(j.error.message.includes('model not found'));
});
await t('gemini: model pensiun -> otomatis pakai flash terbaru', async () => {
  const old = globalThis.fetch; const tried = [];
  globalThis.fetch = async (u, i) => {
    u = String(u);
    if (u.includes('/models?pageSize')) return new Response(JSON.stringify({ models: [{ name: 'models/gemini-2.5-flash', supportedGenerationMethods: ['generateContent'] }, { name: 'models/gemini-3.8-flash', supportedGenerationMethods: ['generateContent'] }, { name: 'models/gemini-3.8-pro', supportedGenerationMethods: ['generateContent'] }] }), { status: 200 });
    if (u.includes('generativelanguage')) { tried.push(u); return u.includes('gemini-2.5-flash') ? new Response(JSON.stringify({ error: { message: 'no longer available' } }), { status: 404 }) : new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: 'OK baru' }] }, finishReason: 'STOP' }] }), { status: 200 }); }
    return old(u, i);
  };
  const r = await p(req('/api/p?id=gemini&path=chat/completions', { method: 'POST', headers: { origin: 'https://app.test', authorization: 'Bearer server', 'content-type': 'application/json' }, body: JSON.stringify({ model: 'gemini-2.5-flash', messages: [{ role: 'user', content: 'hai' }] }) }));
  const j = await r.json(); globalThis.fetch = old; assert.equal(r.status, 200); assert.equal(j.choices[0].message.content, 'OK baru'); assert.ok(tried.some((x) => x.includes('gemini-3.8-flash:generateContent')));
});
await t('gemini: path lain ditolak', async () => assert.equal((await p(req('/api/p?id=gemini&path=files', { headers: { origin: 'https://app.test' } }))).status, 404));

console.log('\n' + (n - fails) + '/' + n + ' lulus');
process.exit(fails ? 1 : 0);
