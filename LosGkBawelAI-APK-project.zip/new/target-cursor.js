// TargetCursor: port JavaScript murni dari komponen React Bits <TargetCursor />.
// Pemakaian: const tc = TargetCursor({ spinDuration: 2, parallaxOn: true }); tc.update({...}); tc.destroy();
(function (global) {
  const CORNER_ANGLES = [0, 90, 180, 270];
  const QUARTER = Math.PI / 2;

  const spring = (state, goal, stiffness, damping, dt) => {
    const steps = 2;
    const h = dt / steps;
    for (let i = 0; i < steps; i++) {
      state.v += (stiffness * (goal - state.x) - damping * state.v) * h;
      state.x += state.v * h;
    }
  };

  const resolveElement = (value) => (value && 'current' in value ? value.current : value) || null;

  const DEFAULTS = {
    targetSelector: '.cursor-target',
    cursorColor: '#ffffff',
    cursorColorOnTarget: undefined,
    spinDuration: 2,
    hoverDuration: 0.2,
    parallaxOn: true,
    hideDefaultCursor: true,
    size: 36,
    cornerSize: 12,
    thickness: 3,
    padding: 6,
    matchRadius: true,
    dotSize: 4,
    blendMode: 'difference',
    showLabel: true,
    clickEffect: true,
    labelFromTitle: false, // tambahan: pakai atribut title sebagai label bila data-cursor-label tidak ada
    container: undefined
  };

  function normalize(o) {
    return Object.assign({}, o, {
      hoverDuration: Math.max(0.05, o.hoverDuration),
      size: Math.max(4, o.size),
      cornerSize: Math.max(2, o.cornerSize),
      thickness: Math.max(0.5, o.thickness),
      dotSize: Math.max(0, o.dotSize)
    });
  }

  function TargetCursor(options) {
    let settings = normalize(Object.assign({}, DEFAULTS, options || {}));
    let host = null; // elemen tempat kursor dipasang (null = pointer kasar / sentuh)
    let teardown = null;
    let wake = () => {};

    const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)');
    const onMedia = () => (finePointer.matches ? mount() : unmount());

    function unmount() { if (teardown) { teardown(); teardown = null; } host = null; }

    function mount() {
      if (teardown) return;
      host = document.documentElement;
      const root = document.createElement('div');
      root.className = 'target-cursor';
      root.style.mixBlendMode = settings.blendMode;
      root.style.opacity = '0';
      root.setAttribute('aria-hidden', 'true');
      const corners = CORNER_ANGLES.map(() => { const s = document.createElement('span'); s.className = 'target-cursor__corner'; root.appendChild(s); return s; });
      const dotEl = document.createElement('span'); dotEl.className = 'target-cursor__dot'; root.appendChild(dotEl);
      const labelEl = document.createElement('span'); labelEl.className = 'target-cursor__label'; root.appendChild(labelEl);
      host.appendChild(root);

      const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      const style = document.createElement('style');
      document.head.appendChild(style);

      const pointer = { x: 0, y: 0, inside: false, seen: false, pressed: false };
      const centerX = { x: 0, v: 0 }, centerY = { x: 0, v: 0 }, halfW = { x: 0, v: 0 }, halfH = { x: 0, v: 0 };
      const radius = { x: 0, v: 0 }, turn = { x: 0, v: 0 }, lock = { x: 0, v: 0 }, press = { x: 0, v: 0 }, presence = { x: 0, v: 0 };
      let target = null, targetRadius = 0, quarter = 0, spinSpeed = 0, raf = 0, last = 0, lastLabel = '', lastColor = '', lastScope = null, lastBlend = settings.blendMode;

      const scopeOf = () => resolveElement(settings.container);

      const hideCursor = () => {
        const s = settings;
        const scope = scopeOf();
        if (scope !== lastScope) {
          if (lastScope) lastScope.removeAttribute('data-target-cursor-scope');
          if (scope) scope.setAttribute('data-target-cursor-scope', '');
          lastScope = scope;
        }
        const selector = scope ? '[data-target-cursor-scope]' : 'html';
        const rule = s.hideDefaultCursor && pointer.inside ? `${selector}, ${selector} * { cursor: none !important; }` : '';
        if (style.textContent !== rule) style.textContent = rule;
      };

      const findTarget = (x, y, element) => {
        const node = element || document.elementFromPoint(x, y);
        const found = (node && node.closest && node.closest(settings.targetSelector)) || null;
        const scope = scopeOf();
        if (found && scope && !scope.contains(found)) return null;
        return found;
      };

      const labelOf = (el) => {
        if (!el) return '';
        let t = el.getAttribute('data-cursor-label') || '';
        if (!t && settings.labelFromTitle) {
          const title = el.getAttribute('title');
          if (title) {
            t = title.split('\n')[0].slice(0, 28);
            el.setAttribute('data-cursor-label', t);
            if (!el.getAttribute('aria-label')) el.setAttribute('aria-label', title);
            el.removeAttribute('title'); // hindari tooltip ganda
          }
        }
        return t;
      };

      const lockOn = (next) => {
        if (next === target) return;
        target = next;
        if (target) {
          quarter = Math.round(turn.x / QUARTER);
          targetRadius = parseFloat(getComputedStyle(target).borderTopLeftRadius) || 0;
          spinSpeed = 0;
          labelOf(target);
        }
      };

      const frame = (now) => {
        raf = 0;
        const s = settings;
        const dt = last ? Math.min(0.05, (now - last) / 1000) : 1 / 60;
        last = now;

        if (target && !target.isConnected) lockOn(null);
        const rect = target ? target.getBoundingClientRect() : null;
        const locked = !!rect && pointer.inside;
        const snapW = 4.6 / s.hoverDuration;
        const snapK = snapW * snapW;
        const snapC = 2 * 0.62 * snapW;

        spring(presence, pointer.inside ? 1 : 0, 260, 32, dt);
        spring(lock, locked ? 1 : 0, snapK, 2 * snapW, dt);
        spring(press, pointer.pressed && s.clickEffect ? 1 : 0, 900, 40, dt);

        let goalX = pointer.x, goalY = pointer.y, goalW = s.size / 2, goalH = s.size / 2, goalR = Math.min(2, s.cornerSize / 4);
        if (locked) {
          const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
          const lean = s.parallaxOn ? 0.08 : 0;
          goalX = cx + (pointer.x - cx) * lean;
          goalY = cy + (pointer.y - cy) * lean;
          const odd = Math.abs(quarter) % 2 === 1;
          const w = rect.width / 2 + s.padding, h = rect.height / 2 + s.padding;
          goalW = odd ? h : w;
          goalH = odd ? w : h;
          goalR = s.matchRadius ? Math.min(targetRadius + Math.max(0, s.padding), s.cornerSize) : 0;
        }

        if (!pointer.inside && presence.x < 0.01) pointer.seen = false;
        if (!pointer.seen) {
          centerX.x = goalX; centerY.x = goalY; halfW.x = goalW; halfH.x = goalH;
          pointer.seen = pointer.inside;
        }

        const follow = locked ? snapK : 2200;
        const followC = locked ? snapC : 2 * Math.sqrt(2200);
        spring(centerX, goalX, follow, followC, dt);
        spring(centerY, goalY, follow, followC, dt);
        spring(halfW, goalW, snapK, snapC, dt);
        spring(halfH, goalH, snapK, snapC, dt);
        spring(radius, goalR, snapK, 2 * snapW, dt);

        if (locked) spring(turn, quarter * QUARTER, snapK, snapC, dt);
        else {
          const speed = s.spinDuration > 0 && !reduce ? (Math.PI * 2) / s.spinDuration : 0;
          spinSpeed += (speed - spinSpeed) * (1 - Math.exp(-dt * 3));
          turn.v = spinSpeed;
          turn.x += spinSpeed * dt;
        }

        const squeeze = 1 - press.x * 0.14;
        const cos = Math.cos(turn.x), sin = Math.sin(turn.x);
        const w = Math.max(0, halfW.x) * squeeze, h = Math.max(0, halfH.x) * squeeze;
        const local = [[-w, -h], [w, -h], [w, h], [-w, h]];
        const r = Math.max(0, Math.min(radius.x, s.cornerSize));
        const degrees = (turn.x * 180) / Math.PI;
        let left = Infinity, top = Infinity;
        corners.forEach((corner, i) => {
          const [lx, ly] = local[i];
          const x = centerX.x + lx * cos - ly * sin;
          const y = centerY.x + lx * sin + ly * cos;
          left = Math.min(left, x); top = Math.min(top, y);
          corner.style.transform = `translate3d(${x.toFixed(2)}px, ${y.toFixed(2)}px, 0) rotate(${(CORNER_ANGLES[i] + degrees).toFixed(2)}deg)`;
          corner.style.width = `${s.cornerSize}px`;
          corner.style.height = `${s.cornerSize}px`;
          corner.style.borderWidth = `${s.thickness}px 0 0 ${s.thickness}px`;
          corner.style.borderTopLeftRadius = `${r.toFixed(2)}px`;
        });

        const dotScale = 1 - press.x * 0.35;
        dotEl.style.transform = `translate3d(${pointer.x}px, ${pointer.y}px, 0) translate(-50%, -50%) scale(${dotScale.toFixed(3)})`;
        dotEl.style.width = `${s.dotSize}px`;
        dotEl.style.height = `${s.dotSize}px`;

        const text = s.showLabel && target ? labelOf(target) : '';
        if (text && text !== lastLabel) labelEl.textContent = text;
        if (text) lastLabel = text;
        const shown = text ? Math.max(0, Math.min(1, lock.x)) : 0;
        labelEl.style.transform = `translate3d(${left.toFixed(2)}px, ${(top - 8).toFixed(2)}px, 0) translateY(-100%) translateY(${((1 - shown) * 4).toFixed(2)}px)`;
        labelEl.style.opacity = shown.toFixed(3);

        const mix = s.cursorColorOnTarget ? Math.round(Math.max(0, Math.min(1, lock.x)) * 100) : 0;
        const color = mix ? `color-mix(in oklab, ${s.cursorColorOnTarget} ${mix}%, ${s.cursorColor})` : s.cursorColor;
        if (color !== lastColor) { root.style.setProperty('--target-cursor-color', color); lastColor = color; }
        if (s.blendMode !== lastBlend) { root.style.mixBlendMode = s.blendMode; lastBlend = s.blendMode; }
        root.style.opacity = Math.max(0, Math.min(1, presence.x)).toFixed(3);

        const resting = !pointer.inside && presence.x < 0.002 && Math.abs(presence.v) < 0.002 && Math.abs(lock.x) < 0.002 && Math.abs(press.x) < 0.002;
        const spinning = pointer.inside && !locked && spinSpeed > 0.0001;
        const moving = Math.abs(centerX.v) + Math.abs(centerY.v) + Math.abs(halfW.v) + Math.abs(halfH.v) + Math.abs(turn.v) > 0.01 ||
          Math.abs(goalX - centerX.x) + Math.abs(goalY - centerY.x) > 0.05 ||
          Math.abs(lock.v) + Math.abs(press.v) + Math.abs(presence.v) > 0.001;
        if (!resting && (spinning || moving || locked)) raf = requestAnimationFrame(frame);
        else last = 0;
      };

      const wakeUp = () => { if (!raf) raf = requestAnimationFrame(frame); };
      wake = () => { hideCursor(); wakeUp(); };

      const insideScope = (x, y, element) => {
        const scope = scopeOf();
        if (!scope) return true;
        if (element && scope.contains(element)) return true;
        const box = scope.getBoundingClientRect();
        return x >= box.left && x <= box.right && y >= box.top && y <= box.bottom;
      };
      const onPointerMove = (event) => {
        if (event.pointerType && event.pointerType !== 'mouse') return;
        pointer.x = event.clientX; pointer.y = event.clientY;
        const inside = insideScope(pointer.x, pointer.y, event.target);
        if (inside !== pointer.inside) { pointer.inside = inside; hideCursor(); }
        lockOn(inside ? findTarget(pointer.x, pointer.y, event.target) : null);
        wakeUp();
      };
      const onPointerDown = (event) => { if (event.pointerType && event.pointerType !== 'mouse') return; pointer.pressed = true; wakeUp(); };
      const onPointerUp = () => { pointer.pressed = false; wakeUp(); };
      const onLeave = () => { pointer.inside = false; pointer.pressed = false; lockOn(null); hideCursor(); wakeUp(); };
      const onScroll = () => { if (!pointer.inside) return; lockOn(findTarget(pointer.x, pointer.y)); wakeUp(); };

      window.addEventListener('pointermove', onPointerMove, { passive: true });
      window.addEventListener('pointerdown', onPointerDown, { passive: true });
      window.addEventListener('pointerup', onPointerUp, { passive: true });
      window.addEventListener('scroll', onScroll, { passive: true, capture: true });
      document.documentElement.addEventListener('pointerleave', onLeave);
      window.addEventListener('blur', onLeave);

      teardown = () => {
        cancelAnimationFrame(raf);
        wake = () => {};
        window.removeEventListener('pointermove', onPointerMove);
        window.removeEventListener('pointerdown', onPointerDown);
        window.removeEventListener('pointerup', onPointerUp);
        window.removeEventListener('scroll', onScroll, { capture: true });
        document.documentElement.removeEventListener('pointerleave', onLeave);
        window.removeEventListener('blur', onLeave);
        if (lastScope) lastScope.removeAttribute('data-target-cursor-scope');
        style.remove();
        root.remove();
      };
    }

    finePointer.addEventListener('change', onMedia);
    onMedia();

    return {
      update(next) { settings = normalize(Object.assign({}, settings, next || {})); wake(); },
      destroy() { finePointer.removeEventListener('change', onMedia); unmount(); }
    };
  }

  global.TargetCursor = TargetCursor;
  global.TargetCursor.DEFAULTS = DEFAULTS;
})(window);
