// Alamat web sudah diisi bawaan. Tidak perlu diatur lagi.
let url = (process.env.APP_URL || 'https://los-gk-bawel-ai-web.vercel.app').trim();
if (url && !/^https?:\/\//i.test(url)) url = 'https://' + url;
if (!url) console.warn('[!] APP_URL belum diisi: aplikasi hanya menampilkan halaman cadangan.');

module.exports = {
  appId: 'id.losgkbawel.ai',
  appName: 'Los Gk Bawel AI',
  webDir: 'www',
  backgroundColor: '#14151a',
  server: url ? { url, cleartext: false, errorPath: 'offline.html', androidScheme: 'https' } : { androidScheme: 'https' },
  android: { allowMixedContent: false, backgroundColor: '#14151a', webContentsDebuggingEnabled: false },
  plugins: {
    SplashScreen: { launchShowDuration: 0, launchAutoHide: true, backgroundColor: '#14151a', androidScaleType: 'CENTER_INSIDE', showSpinner: false },
    StatusBar: { style: 'DARK', backgroundColor: '#14151a', overlaysWebView: false }
  }
};
