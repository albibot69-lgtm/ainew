// Menambah izin mikrofon (untuk input suara/Whisper) & pengaturan WebView ke proyek Android hasil `cap add android`.
import fs from 'node:fs';
const mf = 'android/app/src/main/AndroidManifest.xml';
let x = fs.readFileSync(mf, 'utf8');
const perms = ['android.permission.RECORD_AUDIO', 'android.permission.MODIFY_AUDIO_SETTINGS', 'android.permission.POST_NOTIFICATIONS'];
for (const p of perms) if (!x.includes(p)) x = x.replace('<application', `<uses-permission android:name="${p}" />\n    <application`);
if (!x.includes('android.hardware.microphone')) x = x.replace('<application', '<uses-feature android:name="android.hardware.microphone" android:required="false" />\n    <application');
x = x.replace(/android:windowSoftInputMode="[^"]*"/, 'android:windowSoftInputMode="adjustResize"');
if (!x.includes('android:hardwareAccelerated')) x = x.replace('<application', '<application android:hardwareAccelerated="true"');
fs.writeFileSync(mf, x);
const vf = 'android/variables.gradle';
console.log('Manifest dipatch.', fs.existsSync(vf) ? '' : '');
