// Render Markdown + rumus LaTeX (KaTeX) jadi HTML yang aman.
(function () {
  function splitCode(text) {
    // Bagian ganjil = blok/inline code (jangan diproses sebagai rumus)
    return text.split(/(```[\s\S]*?```|`[^`\n]+`)/g);
  }

  function renderMarkdown(text) {
    const maths = [];
    const stash = (tex, display) => {
      maths.push({ tex: tex.trim(), display });
      return 'MATHPH' + (maths.length - 1) + 'X';
    };

    const parts = splitCode(String(text)).map((seg, i) => {
      if (i % 2 === 1) return seg;
      return seg
        .replace(/\$\$([\s\S]+?)\$\$/g, (_, m) => stash(m, true))
        .replace(/\\\[([\s\S]+?)\\\]/g, (_, m) => stash(m, true))
        .replace(/\\\(([\s\S]+?)\\\)/g, (_, m) => stash(m, false))
        .replace(/(?<![\\$\d])\$(?!\s)([^$\n]+?)(?<!\s)\$(?!\d)/g, (_, m) => stash(m, false));
    });

    let html = marked.parse(parts.join(''), { gfm: true, breaks: true });
    html = DOMPurify.sanitize(html);

    return html.replace(/MATHPH(\d+)X/g, (_, n) => {
      const m = maths[Number(n)];
      if (!m) return '';
      try {
        return katex.renderToString(m.tex, {
          displayMode: m.display,
          throwOnError: false,
          output: 'html'
        });
      } catch {
        return m.tex.replace(/</g, '&lt;');
      }
    });
  }

  if (DOMPurify.addHook) {
    DOMPurify.addHook('afterSanitizeAttributes', (node) => {
      if (node.tagName === 'A') {
        node.setAttribute('target', '_blank');
        node.setAttribute('rel', 'noopener noreferrer');
      }
    });
  }

  globalThis.renderMarkdown = renderMarkdown;
})();
