// Saklar kursor target di panel tampilan popup + tombol menuju halaman pengaturan kursor.
(function () {
  const t = document.getElementById('tcursor');
  if (!t) return;
  chrome.storage.local.get({ cursorOn: false }).then((s) => { t.checked = s.cursorOn; });
  t.addEventListener('change', () => chrome.storage.local.set({ cursorOn: t.checked }));
  chrome.storage.onChanged.addListener((c) => { if (c.cursorOn) t.checked = c.cursorOn.newValue; });
  const b = document.getElementById('openCursor');
  if (b) b.addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('options.html#kursor') }));
})();
