// Mesin AI bersama (dipakai popup, background, dan halaman Atur).
// Butuh defaults.js dimuat lebih dulu.

// ---------- Provider ----------
async function loadProviders() {
  await ensureDefaults();
  const st = await chrome.storage.local.get({ activeProvider: 'groq', provCfg: {}, autoSwitch: true });
  const all = getProviders(st.provCfg).filter((p) => p.apiKey && p.baseUrl);
  const active = all.find((p) => p.id === st.activeProvider) || all[0];
  return { all, active, autoSwitch: st.autoSwitch, provCfg: st.provCfg };
}

// Pertanyaan soal kode/error/hitungan dijawab dengan nalar lebih dalam (lebih benar), obrolan biasa tetap cepat
function codeLike(messages) {
  const m = [...(messages || [])].reverse().find((x) => x.role === 'user');
  const t = String((m && m.content) || '').slice(-3000);
  return /```|\b(error|bug|exception|traceback|stack ?trace|undefined|null ?pointer|syntax|compile|debug|fungsi|function|script|skrip|kode|coding|code|algoritma|regex|query|sql|html|css|javascript|typescript|python|lua|luau|roblox|java|kotlin|c\+\+|php|api|json|hitung|rumus|integral|turunan|persamaan)\b/i.test(t) || /[{};]\s*$|=>|\bconsole\.|\bdef \w+\(|\bimport \w+/m.test(t);
}

function toConfig(p, system) {
  return { id: p.id, name: p.name, provider: p.type, baseUrl: p.baseUrl, apiKey: p.apiKey, model: p.model, system };
}

async function saveProviderModel(id, model) {
  const st = await chrome.storage.local.get({ provCfg: {} });
  st.provCfg[id] = Object.assign({}, st.provCfg[id], { model });
  await chrome.storage.local.set({ provCfg: st.provCfg });
}

function isSwitchable(e) {
  if (e.name === 'AbortError') return false;
  return [401, 402, 403, 413, 429].includes(e.status) ||
    /quota|credit|balance|insufficient|billing|exceeded|rate.?limit|payment|api key|unauthorized|does not exist|not found|decommission|no access|do not have access/i.test(e.message);
}

function httpError(r, j) {
  const msg = (typeof j.error === 'string' ? j.error : j.error?.message) || j.message || r.statusText || 'HTTP ' + r.status;
  const e = new Error(msg);
  e.status = r.status;
  return e;
}

// ---------- Format pesan ----------
function toOpenAI(m) {
  if (!m.images || !m.images.length) return { role: m.role, content: m.content };
  return {
    role: m.role,
    content: [
      { type: 'text', text: m.content },
      ...m.images.map((url) => ({ type: 'image_url', image_url: { url } }))
    ]
  };
}
function toAnthropic(m) {
  if (!m.images || !m.images.length) return { role: m.role, content: m.content };
  return {
    role: m.role,
    content: [
      ...m.images.map((url) => {
        const [, type, data] = url.match(/^data:(.+?);base64,(.*)$/);
        return { type: 'image', source: { type: 'base64', media_type: type, data } };
      }),
      { type: 'text', text: m.content }
    ]
  };
}

// ---------- Baca SSE ----------
async function readSSE(r, onEvent) {
  const reader = r.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).replace(/\r$/, '');
      buf = buf.slice(i + 1);
      if (line.startsWith('data:')) {
        const data = line.slice(5).trim();
        if (data === '[DONE]') return;
        if (data) { try { onEvent(JSON.parse(data)); } catch (e) { if (e.message && !(e instanceof SyntaxError)) throw e; } }
      }
    }
  }
}

// ---------- Satu panggilan (streaming) ----------
// Mengembalikan { text, finish } dan memanggil onDelta(fullText) tiap ada teks baru.
async function streamChat(s, model, messages, o) {
  if (s.provider === 'anthropic') {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST', signal: o.signal,
      headers: {
        'content-type': 'application/json', 'x-api-key': s.apiKey,
        'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({ model, max_tokens: o.maxTokens || 4096, stream: true, system: s.system, messages: messages.map(toAnthropic) })
    });
    if (!r.ok) throw httpError(r, await r.json().catch(() => ({})));
    let text = '', finish = null;
    await readSSE(r, (j) => {
      if (j.type === 'content_block_delta' && j.delta?.text) { text += j.delta.text; o.onDelta && o.onDelta(text); }
      if (j.type === 'message_delta' && j.delta?.stop_reason) finish = j.delta.stop_reason === 'max_tokens' ? 'length' : 'stop';
      if (j.type === 'error') throw new Error(j.error?.message || 'Error dari Anthropic');
    });
    return { text, finish };
  }

  // OpenAI-compatible
  const body = {
    model, stream: true,
    messages: [{ role: 'system', content: s.system }, ...messages.map(toOpenAI)]
  };
  const opt = { max_tokens: Math.min(o.maxTokens || 4096, s.id === 'groq' ? 5000 : 16000) };
  if (s.id === 'groq' && /gpt-oss/i.test(model)) opt.reasoning_effort = (o.deep || codeLike(messages)) ? 'medium' : 'low';
  Object.assign(body, opt);

  let r;
  for (let attempt = 0; attempt < 3; attempt++) {
    r = await fetch(s.baseUrl.replace(/\/$/, '') + '/chat/completions', {
      method: 'POST', signal: o.signal,
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + s.apiKey },
      body: JSON.stringify(body)
    });
    if (r.ok) break;
    const j = await r.json().catch(() => ({}));
    const err = httpError(r, j);
    // Parameter opsional tidak didukung: buang / ganti lalu coba lagi
    if (r.status === 400 || r.status === 422) {
      if (/reasoning_effort/i.test(err.message) && 'reasoning_effort' in body) { delete body.reasoning_effort; continue; }
      if (/max_tokens/i.test(err.message) && 'max_tokens' in body) { body.max_completion_tokens = body.max_tokens; delete body.max_tokens; continue; }
      if (/max_completion_tokens/i.test(err.message) && 'max_completion_tokens' in body) { delete body.max_completion_tokens; continue; }
    }
    throw err;
  }

  let text = '', finish = null;
  const ct = r.headers.get('content-type') || '';
  if (!ct.includes('event-stream')) {
    // Server tidak mendukung streaming: ambil jawaban utuh
    const j = await r.json();
    text = j.choices?.[0]?.message?.content || '';
    finish = j.choices?.[0]?.finish_reason || 'stop';
    o.onDelta && o.onDelta(text);
    return { text, finish };
  }
  await readSSE(r, (j) => {
    if (j.error) throw new Error(typeof j.error === 'string' ? j.error : j.error.message || 'Error dari server');
    const c = j.choices?.[0];
    const d = c?.delta?.content;
    if (typeof d === 'string' && d) { text += d; o.onDelta && o.onDelta(text); }
    if (c?.finish_reason) finish = c.finish_reason;
  });
  return { text, finish };
}

async function listModels(s) {
  const r = await fetch(s.baseUrl.replace(/\/$/, '') + '/models', { headers: { authorization: 'Bearer ' + s.apiKey } });
  const j = await r.json();
  if (!r.ok) throw new Error(j.error?.message || r.statusText);
  const skip = /whisper|tts|guard|safeguard|embed|orpheus|playai|moderation|transcribe/i;
  return (j.data || []).map((m) => m.id).filter((id) => id && !skip.test(id));
}

function pickModel(ids, wantVision, pid) {
  if (wantVision) return ids.find((id) => /gemini-2\.5-flash$|gemini.*flash|scout|maverick|vision|llama-4|gpt-4o|gemma3|qwen.*vl/i.test(id)) || null;
  const prefer = {
    groq: ['openai/gpt-oss-20b', 'llama-3.1-8b-instant', 'openai/gpt-oss-120b', 'llama-3.3-70b-versatile'],
    ollama: ['gpt-oss:20b', 'gpt-oss:120b'],
    openai: ['gpt-4o-mini', 'gpt-4.1-mini', 'gpt-4o'],
    openrouter: ['openai/gpt-4o-mini'],
    gemini: ['gemini-3.8-flash', 'models/gemini-3.8-flash', 'gemini-2.5-flash']
  }[pid] || [];
  return prefer.find((id) => ids.includes(id)) || null;
}


// ---------- Request terlalu besar (batas token per menit) ----------
function tooLargeInfo(e) {
  if (e.status === 413 || /request too large|reduce your message size|tokens per minute|too many tokens|maximum context|context length|context_length/i.test(e.message)) {
    const m = e.message.match(/Limit (\d+),?\s*Requested (\d+)/i);
    return { limit: m ? +m[1] : 0, requested: m ? +m[2] : 0 };
  }
  return null;
}

// Pesan galat yang ramah untuk ditampilkan ke pengguna
function friendlyError(msg, status) {
  if (/request too large|tokens per minute|reduce your message size/i.test(msg)) return 'melewati batas token per menit';
  if (status === 429 || /rate.?limit|quota|exceeded/i.test(msg)) return 'kena batas kuota / kecepatan';
  if (status === 401 || /api key|unauthorized|invalid.*key/i.test(msg)) return 'API key ditolak';
  if (status === 402 || /credit|balance|billing|insufficient|payment/i.test(msg)) return 'kredit habis';
  if (/not found|does not exist|decommission|no access|do not have access/i.test(msg)) return 'model tidak tersedia';
  return msg.replace(/\s+/g, ' ').slice(0, 70);
}

// Potong riwayat/isi pesan supaya total karakter muat di batas
function shrinkMessages(messages, maxChars) {
  let msgs = messages.map((m) => Object.assign({}, m));
  const total = () => msgs.reduce((a, m) => a + m.content.length, 0);
  while (total() > maxChars && msgs.length > 1) {
    msgs.shift();
    while (msgs.length > 1 && msgs[0].role !== 'user') msgs.shift();
  }
  if (total() > maxChars) {
    // masih terlalu besar: potong bagian tengah pesan terpanjang (awal dan akhir dipertahankan)
    const big = msgs.reduce((a, m) => (m.content.length > a.content.length ? m : a), msgs[0]);
    const over = total() - maxChars;
    const keep = Math.max(800, big.content.length - over - 60);
    const head = Math.floor(keep * 0.7), tail = keep - head;
    big.content = big.content.slice(0, head) + '\n[… sebagian isi dipotong agar muat di batas model …]\n' + big.content.slice(big.content.length - tail);
  }
  return msgs;
}

// Satu provider: kalau model tidak valid / tidak mendukung gambar, pilih model lain otomatis
async function callProviderOnce(s, messages, o) {
  try {
    return await streamChat(s, s.model, messages, o);
  } catch (e) {
    if (e.name === 'AbortError' || s.provider === 'anthropic') throw e;
    const hasImg = messages.some((m) => m.images && m.images.length);
    const modelErr = /does not exist|not found|decommission|do not have access|no access/i.test(e.message);
    const visionErr = hasImg && /image|vision|multimodal|support/i.test(e.message);
    if (!modelErr && !visionErr) throw e;
    let ids;
    try { ids = await listModels(s); } catch { throw e; }
    const pick = pickModel(ids, hasImg, s.id);
    if (!pick || pick === s.model) throw e;
    const out = await streamChat(s, pick, messages, o);
    if (modelErr && !hasImg) {
      await saveProviderModel(s.id, pick);
      o.onModel && o.onModel(s.id, pick);
    }
    return out;
  }
}


// Bungkus: kalau request kebesaran, kecilkan (max_tokens + isi pesan) lalu coba lagi di provider yang sama
async function callProvider(s, messages, o) {
  let msgs = messages, opts = Object.assign({}, o);
  for (let attempt = 0; ; attempt++) {
    try {
      return await callProviderOnce(s, msgs, opts);
    } catch (e) {
      const t = tooLargeInfo(e);
      if (!t || attempt >= 2 || e.name === 'AbortError') throw e;
      const limit = t.limit || (s.id === 'groq' ? 6000 : 12000);
      const out = Math.max(600, Math.min(opts.maxTokens || 4096, Math.floor(limit * 0.35)));
      const sysTok = Math.ceil((s.system || '').length / 3);
      const promptTok = Math.max(700, limit - out - 300 - sysTok);
      opts = Object.assign({}, opts, { maxTokens: out, deep: false });
      msgs = shrinkMessages(msgs, promptTok * 3);
      if (o.onShrink) o.onShrink(s);
    }
  }
}

// ---------- API utama ----------
// o: { signal, onDelta(text), onSwitch(from,to,why), onProvider(p), onModel, maxTokens, deep, system, autoContinue }
// Auto-lanjut: kalau jawaban terpotong karena batas token, minta lanjutan sampai 3 kali.
async function askAI(messages, o = {}) {
  const { all, active, autoSwitch } = await loadProviders();
  const sys = await chrome.storage.local.get({ system: SYSTEM_PROMPT });
  if (!active) throw new Error('Belum ada AI dengan API key. Buka "Atur" untuk mengisi.');
  // kepribadian + memori preferensi pengguna
  const px = await chrome.storage.local.get({ persona: 'default', memoryNotes: '' });
  const notes = String(px.memoryNotes || '').split('\n').map((x) => x.trim()).filter(Boolean).join('\n- ').slice(0, 2000);
  const extra = [(PERSONAS[px.persona] || {}).prompt, notes ? 'Hal yang diminta pengguna untuk selalu kamu ingat:\n- ' + notes : ''].filter(Boolean).join('\n\n');

  const start = all.findIndex((p) => p.id === active.id);
  const order = [...all.slice(start), ...all.slice(0, start)];
  const tried = [];
  let lastErr;

  for (const p of order) {
    const cfg = toConfig(p, [CORE_PROMPT, window.LGB_ROLES_LINE || '', window.LGB_USER_LINE || '', window.LGB_MEM_LINE || '', window.LGB_MODE_LINE || '', sys.system, extra, o.system].filter(Boolean).join('\n\n'));
    let got = false;
    const wrap = Object.assign({}, o, {
      onDelta: (t) => { got = true; o.onDelta && o.onDelta(t); }
    });
    try {
      o.onProvider && o.onProvider(p);
      let res = await callProvider(cfg, messages, wrap);
      let full = res.text;
      let rounds = 0;
      while (o.autoContinue !== false && res.finish === 'length' && full && rounds < 3) {
        rounds++;
        const more = [...messages, { role: 'assistant', content: full, images: [] },
          { role: 'user', content: 'Lanjutkan persis dari kata terakhir tanpa mengulang apa pun yang sudah ditulis.', images: [] }];
        const base = full;
        res = await callProvider(cfg, more, Object.assign({}, wrap, { onDelta: (t) => { got = true; o.onDelta && o.onDelta(base + t); } }));
        full = base + res.text;
      }
      if (!full.trim()) throw new Error('Jawaban kosong. Model mungkin kehabisan token saat berpikir; coba lagi atau ganti model.');
      if (p.id !== active.id) {
        await chrome.storage.local.set({ activeProvider: p.id });
        o.onActiveChanged && o.onActiveChanged(p);
      }
      return { text: full, provider: p, truncated: res.finish === 'length' };
    } catch (e) {
      lastErr = e;
      if (e.name === 'AbortError') throw e;
      // Jangan pindah AI kalau sudah ada teks yang tampil (hindari jawaban ganda)
      if (got || !autoSwitch || !isSwitchable(e)) throw e;
      tried.push(p.name);
      const next = order[order.indexOf(p) + 1];
      if (next && o.onSwitch) o.onSwitch(p, next, e.message);
    }
  }
  lastErr.message += ' (sudah dicoba: ' + tried.join(', ') + ')';
  throw lastErr;
}

// Panggilan singkat tanpa streaming (mis. memperbaiki prompt gambar)
async function askOnce(prompt, o = {}) {
  const r = await askAI([{ role: 'user', content: prompt, images: [] }], Object.assign({ maxTokens: 400, autoContinue: false }, o));
  return r.text.trim();
}

// ======================================================================
// ===== Gambar AI =====
// ======================================================================
const IMG_SIZES = {
  square:    { w: 1024, h: 1024, gpt: '1024x1024', dalle: '1024x1024', label: 'Kotak' },
  portrait:  { w: 768,  h: 1024, gpt: '1024x1536', dalle: '1024x1792', label: 'Potret' },
  landscape: { w: 1024, h: 768,  gpt: '1536x1024', dalle: '1792x1024', label: 'Lanskap' }
};

function blobToDataURL(blob) {
  return new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onload = () => res(fr.result);
    fr.onerror = rej;
    fr.readAsDataURL(blob);
  });
}

async function genOpenAI(p, prompt, size, signal) {
  const base = p.baseUrl.replace(/\/$/, '');
  const headers = { 'content-type': 'application/json', authorization: 'Bearer ' + p.apiKey };
  const sz = IMG_SIZES[size] || IMG_SIZES.square;
  const attempts = [
    { model: 'gpt-image-1', body: { model: 'gpt-image-1', prompt, size: sz.gpt, n: 1, quality: 'medium' } },
    { model: 'dall-e-3', body: { model: 'dall-e-3', prompt, size: sz.dalle, n: 1, response_format: 'b64_json' } }
  ];
  let last;
  for (const a of attempts) {
    const r = await fetch(base + '/images/generations', { method: 'POST', headers, body: JSON.stringify(a.body), signal });
    const j = await r.json().catch(() => ({}));
    if (r.ok) {
      const d = j.data?.[0];
      if (d?.b64_json) return { dataUrl: 'data:image/png;base64,' + d.b64_json, model: a.model };
      if (d?.url) { const b = await (await fetch(d.url, { signal })).blob(); return { dataUrl: await blobToDataURL(b), model: a.model }; }
      last = new Error('Respons gambar kosong');
      continue;
    }
    last = httpError(r, j);
    // 403 (organisasi belum terverifikasi untuk gpt-image-1) / model tidak ada: coba model berikutnya
    if ([400, 403, 404].includes(r.status)) continue;
    throw last;
  }
  throw last;
}

async function genOpenRouter(p, prompt, size, model, signal) {
  const sz = IMG_SIZES[size] || IMG_SIZES.square;
  const ratio = size === 'portrait' ? '3:4' : size === 'landscape' ? '4:3' : '1:1';
  const r = await fetch(p.baseUrl.replace(/\/$/, '') + '/chat/completions', {
    method: 'POST', signal,
    headers: { 'content-type': 'application/json', authorization: 'Bearer ' + p.apiKey },
    body: JSON.stringify({
      model, modalities: ['image', 'text'],
      messages: [{ role: 'user', content: prompt + '\n\n(Buat gambar rasio ' + ratio + ')' }]
    })
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw httpError(r, j);
  const m = j.choices?.[0]?.message;
  const url = m?.images?.[0]?.image_url?.url || m?.images?.[0]?.url;
  if (url) return { dataUrl: url, model };
  // Beberapa model menaruh gambar di content (array)
  const part = Array.isArray(m?.content) ? m.content.find((c) => c.type === 'image_url' || c.image_url) : null;
  if (part?.image_url?.url) return { dataUrl: part.image_url.url, model };
  throw new Error('Model tidak mengembalikan gambar (' + model + ')');
}

async function genPollinations(prompt, size, signal) {
  const sz = IMG_SIZES[size] || IMG_SIZES.square;
  const seed = Math.floor(Math.random() * 1e9);
  const url = 'https://image.pollinations.ai/prompt/' + encodeURIComponent(prompt) +
    `?width=${sz.w}&height=${sz.h}&model=flux&nologo=true&seed=${seed}`;
  const r = await fetch(url, { signal });
  if (!r.ok) { const e = new Error('Pollinations HTTP ' + r.status); e.status = r.status; throw e; }
  const blob = await r.blob();
  if (!blob.type.startsWith('image/')) throw new Error('Pollinations tidak mengembalikan gambar');
  return { dataUrl: await blobToDataURL(blob), model: 'flux' };
}

// Terjemah + perkaya prompt supaya hasil gambar bagus (dipakai untuk model open source)
async function enhanceImagePrompt(prompt, signal) {
  try {
    const out = await askOnce(
      'Ubah permintaan gambar berikut menjadi prompt gambar bahasa Inggris yang jelas dan visual (subjek, gaya, pencahayaan, komposisi), maksimal 60 kata. Jangan menambah hal yang bertentangan dengan permintaan. Tulis prompt-nya saja tanpa tanda kutip.\n\nPermintaan: ' + prompt,
      { signal }
    );
    return out.replace(/^["']|["']$/g, '').slice(0, 700) || prompt;
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    return prompt;
  }
}

// Coba beberapa mesin gambar berurutan sampai ada yang berhasil.
// o: { size, signal, onStatus(text) }
async function generateImage(prompt, o = {}) {
  const set = await getSettings();
  const { provCfg } = await loadProviders();
  const provs = getProviders(provCfg);
  const openai = provs.find((p) => p.id === 'openai' && p.apiKey);
  const orouter = provs.find((p) => p.id === 'openrouter' && p.apiKey);
  const size = o.size || set.imgSize || 'square';

  const engines = [];
  const want = set.imgEngine || 'auto';
  if ((want === 'auto' || want === 'openai') && openai) engines.push({ id: 'openai', name: 'OpenAI' });
  if ((want === 'auto' || want === 'openrouter') && orouter) engines.push({ id: 'openrouter', name: 'OpenRouter' });
  if (want === 'auto' || want === 'pollinations' || !engines.length) engines.push({ id: 'pollinations', name: 'Pollinations (gratis)' });

  let enhanced = null;
  const errors = [];
  for (const en of engines) {
    try {
      o.onStatus && o.onStatus('Membuat gambar dengan ' + en.name + '…');
      if (en.id === 'openai') return Object.assign(await genOpenAI(openai, prompt, size, o.signal), { engine: en.name, prompt });
      if (en.id === 'openrouter') return Object.assign(await genOpenRouter(orouter, prompt, size, set.openrouterImageModel, o.signal), { engine: en.name, prompt });
      if (set.imgEnhance) {
        o.onStatus && o.onStatus('Menyempurnakan prompt…');
        enhanced = enhanced || await enhanceImagePrompt(prompt, o.signal);
      }
      o.onStatus && o.onStatus('Membuat gambar dengan ' + en.name + '…');
      return Object.assign(await genPollinations(enhanced || prompt, size, o.signal), { engine: en.name, prompt, enhanced });
    } catch (e) {
      if (e.name === 'AbortError') throw e;
      errors.push(en.name + ': ' + e.message);
    }
  }
  throw new Error('Semua mesin gambar gagal.\n' + errors.join('\n'));
}
