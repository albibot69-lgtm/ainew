const $ = (id) => document.getElementById(id);
const ic = (n) => '<svg class="i"><use href="#i-' + n + '"/></svg>';

// ---------- Navigasi ----------
const I = (n) => '<svg class="i" viewBox="0 0 24 24"><use href="#i-' + n + '"/></svg>';
const showSection = (v) => document.querySelectorAll('main section').forEach((s) => s.classList.toggle('on', s.id === 's-' + v));
const bmenu = BranchedMenu($('bmenu'), {
  items: [
    { label: 'Tampilan & fitur', children: [
      { value: 'tampilan', label: 'Tampilan', icon: I('palette') },
      { value: 'kursor', label: 'Kursor', icon: I('crosshair') },
      { value: 'perintah', label: 'Perintah kustom', icon: I('zap') },
      { value: 'gambar', label: 'Gambar AI', icon: I('image') },
      { value: 'umum', label: 'Umum', icon: I('settings') }
    ] },
    { label: 'AI & keamanan', children: [
      { value: 'provider', label: 'Provider AI', icon: I('key-round') },
      { value: 'keamanan', label: 'Password', icon: I('shield-check') }
    ] },
    { label: 'Privasi & pintasan', children: [
      { value: 'privasi', label: 'Privasi & data', icon: I('lock') },
      { value: 'pintasan', label: 'Pintasan', icon: I('keyboard') }
    ] }
  ],
  defaultOpen: [0, 1, 2], defaultActive: 'tampilan', rowHeight: 38, fontSize: 14,
  onSelect: (v) => showSection(v)
});
showSection('tampilan');
// buka bagian lewat hash, mis. options.html#kursor (dipakai tombol "Atur kursor" di popup)
if (location.hash && document.getElementById('s-' + location.hash.slice(1))) {
  const want = location.hash.slice(1);
  try { bmenu.select(want); } catch (e) { /* abaikan */ }
  showSection(want);
}
let toastT;
function toast(text, cls) {
  const t = $('toast');
  t.innerHTML = ic(cls === 'bad' ? 'triangle-alert' : 'check') + '<span></span>'; t.querySelector('span').textContent = text; t.className = (cls === 'bad' ? 'bad ' : '') + 'on';
  clearTimeout(toastT);
  toastT = setTimeout(() => t.classList.remove('on'), 2200);
}
const flash = (el, text, cls) => toast(text, cls);

// ---------- Privasi ----------
let S = {};
async function loadAll() {
  await ensureDefaults();
  S = await getSettings();
  $('selToolbar').checked = S.selToolbar && await chrome.permissions.contains({ origins: ['http://*/*', 'https://*/*'] });
  $('autoHighlight').checked = S.autoHighlight;
  $('noHistory').checked = S.noHistory;
  $('autoDeleteDays').value = String(S.autoDeleteDays || 0);
  $('imgEngine').value = S.imgEngine; $('imgSize').value = S.imgSize;
  $('orModel').value = S.openrouterImageModel; $('imgEnhance').checked = S.imgEnhance;
  $('translateTo').value = S.translateTo;
  if (!$('persona').options.length) Object.entries(PERSONAS).forEach(([k, v]) => $('persona').add(new Option(v.label, k)));
  $('persona').value = PERSONAS[S.persona] ? S.persona : 'default';
  $('memoryNotes').value = S.memoryNotes || '';
  $('ver').textContent = 'Los Gk Bawel AI v' + chrome.runtime.getManifest().version;
  $('pingUnit').value = S.pingUnit || 'ms';
  const sys = await chrome.storage.local.get({ system: SYSTEM_PROMPT });
  $('system').value = sys.system;
  drawSites(); drawCmds();
}

$('selToolbar').onchange = async () => {
  if ($('selToolbar').checked) {
    const ok = await chrome.permissions.request({ origins: ['http://*/*', 'https://*/*'] });
    $('selToolbar').checked = ok;
    await chrome.storage.local.set({ selToolbar: ok });
  } else {
    await chrome.storage.local.set({ selToolbar: false });
    try { await chrome.permissions.remove({ origins: ['http://*/*', 'https://*/*'] }); } catch (e) { /* abaikan */ }
  }
};
$('autoHighlight').onchange = () => chrome.storage.local.set({ autoHighlight: $('autoHighlight').checked });
$('noHistory').onchange = async () => {
  await chrome.storage.local.set({ noHistory: $('noHistory').checked });
  if ($('noHistory').checked) await chrome.storage.local.remove(['chatLog', 'chatHistory', 'chats', 'draft']);
};
$('autoDeleteDays').onchange = () => chrome.storage.local.set({ autoDeleteDays: Number($('autoDeleteDays').value) });
$('wipe').onclick = async () => {
  if (!confirm('Hapus semua riwayat chat dan arsip dari perangkat ini?')) return;
  await chrome.storage.local.remove(['chatLog', 'chatHistory', 'chats', 'draft', 'pendingShot']);
  flash($('wipeSt'), 'Riwayat dihapus');
};

function chipList(box, items, onRemove, empty) {
  box.innerHTML = '';
  if (!items.length) { box.innerHTML = '<div class="empty">' + ic('info') + empty + '</div>'; return; }
  items.forEach((h) => {
    const d = document.createElement('div');
    d.className = 'item';
    d.innerHTML = '<div class="t"><b></b></div>';
    d.querySelector('b').textContent = h;
    const x = document.createElement('button');
    x.className = 'btn sm danger'; x.innerHTML = ic('x') + 'Cabut'; x.onclick = () => onRemove(h);
    d.appendChild(x);
    box.appendChild(d);
  });
}
function drawSites() {
  chipList($('sites'), Object.keys(S.allowedSites || {}), async (h) => {
    delete S.allowedSites[h];
    await chrome.storage.local.set({ allowedSites: S.allowedSites });
    drawSites();
  }, 'Belum ada situs yang diizinkan.');
  chipList($('blocked'), S.blockedSites || [], async (h) => {
    S.blockedSites = S.blockedSites.filter((x) => x !== h);
    await chrome.storage.local.set({ blockedSites: S.blockedSites });
    drawSites();
  }, 'Tidak ada.');
}

// ---------- Perintah kustom ----------
let editing = null;
function drawCmds() {
  const box = $('cmdList');
  box.innerHTML = '';
  const list = S.customCmds || [];
  if (!list.length) box.innerHTML = '<div class="empty">' + ic('info') + 'Belum ada perintah kustom.</div>';
  list.forEach((c) => {
    const d = document.createElement('div');
    d.className = 'item';
    d.innerHTML = '<div class="t"><b></b> <span class="pill"></span><pre></pre></div>';
    d.querySelector('b').textContent = c.name;
    d.querySelector('.pill').textContent = '/' + c.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    d.querySelector('pre').textContent = c.prompt;
    const e = document.createElement('button'); e.className = 'btn sm ghost'; e.innerHTML = ic('pencil') + 'Edit';
    e.onclick = () => { editing = c.id; $('cName').value = c.name; $('cPrompt').value = c.prompt; $('cCancel').hidden = false; $('cName').focus(); };
    const x = document.createElement('button'); x.className = 'btn sm danger'; x.innerHTML = ic('trash-2') + 'Hapus';
    x.onclick = async () => { S.customCmds = S.customCmds.filter((y) => y.id !== c.id); await chrome.storage.local.set({ customCmds: S.customCmds }); drawCmds(); };
    d.append(e, x);
    box.appendChild(d);
  });
}
$('cSave').onclick = async () => {
  const name = $('cName').value.trim(), prompt = $('cPrompt').value.trim();
  if (!name || !prompt) { flash($('cSt'), 'Isi nama dan perintah.', 'bad'); return; }
  let list = (S.customCmds || []).filter((x) => x.id !== editing);
  list.push({ id: editing || 'c' + Date.now(), name, prompt });
  S.customCmds = list;
  await chrome.storage.local.set({ customCmds: list });
  editing = null; $('cName').value = ''; $('cPrompt').value = ''; $('cCancel').hidden = true;
  drawCmds(); flash($('cSt'), 'Tersimpan');
};
$('cCancel').onclick = () => { editing = null; $('cName').value = ''; $('cPrompt').value = ''; $('cCancel').hidden = true; };

// ---------- Gambar AI & Umum ----------
$('imgSave').onclick = async () => {
  await chrome.storage.local.set({
    imgEngine: $('imgEngine').value, imgSize: $('imgSize').value,
    openrouterImageModel: $('orModel').value.trim() || DEFAULT_SETTINGS.openrouterImageModel, imgEnhance: $('imgEnhance').checked
  });
  flash($('imgSt'), 'Tersimpan');
};
$('saveUmum').onclick = async () => {
  await chrome.storage.local.set({ persona: $('persona').value, memoryNotes: $('memoryNotes').value, translateTo: $('translateTo').value, system: $('system').value.trim() || SYSTEM_PROMPT });
  flash($('umumSt'), 'Tersimpan');
};

// ---------- Kunci password (Provider & Password) ----------
async function currentHash() {
  const s = await chrome.storage.local.get({ pwHash: DEFAULT_PW_HASH });
  return s.pwHash || DEFAULT_PW_HASH;
}
async function tryUnlock() {
  const pw = $('pw').value;
  if (!pw) return;
  if ((await hashPw(pw)) === (await currentHash())) {
    $('lockP').hidden = true; $('panelP').hidden = false;
    $('lockK').hidden = true; $('panelK').hidden = false;
    await initProv();
  } else {
    $('lockMsg').textContent = 'Password salah.';
    $('pw').value = ''; $('pw').focus();
  }
}
$('unlock').onclick = tryUnlock;
$('pw').addEventListener('keydown', (e) => { if (e.key === 'Enter') tryUnlock(); });

// ---------- Provider ----------
let provCfg = {}, activeId = 'groq';

function fillProviderSelect() {
  const sel = $('provSel'); const keep = sel.value;
  sel.innerHTML = '';
  getProviders(provCfg).forEach((p) => {
    const o = document.createElement('option');
    o.value = p.id;
    o.textContent = p.name + (p.apiKey ? '' : ' (kosong)') + (p.id === activeId ? '  - aktif' : '');
    sel.appendChild(o);
  });
  sel.value = keep || activeId;
}
function showProvider() {
  const id = $('provSel').value;
  const p = getProviders(provCfg).find((x) => x.id === id);
  $('typeRow').hidden = id !== 'custom';
  $('ptype').value = p.type; $('baseUrl').value = p.baseUrl; $('apiKey').value = p.apiKey; $('model').value = p.model;
  $('modelList').innerHTML = ''; $('modelStatus').textContent = '';
  $('activeInfo').textContent = id === activeId ? ' Provider ini sedang aktif.' : ' Ganti AI yang aktif lewat dropdown di popup.';
}
async function initProv() {
  const s = await chrome.storage.local.get({ provCfg: {}, activeProvider: 'groq' });
  provCfg = s.provCfg; activeId = s.activeProvider;
  fillProviderSelect(); showProvider();
}
$('provSel').addEventListener('change', showProvider);

// Provider custom di domain lain: minta izin akses hanya untuk domain itu
async function ensureOrigin(url) {
  try {
    const u = new URL(url);
    const origins = [u.origin + '/*'];
    if (await chrome.permissions.contains({ origins })) return true;
    return await chrome.permissions.request({ origins });
  } catch (e) { return false; }
}

$('save').onclick = async () => {
  const id = $('provSel').value;
  const baseUrl = $('baseUrl').value.trim();
  if (baseUrl && !(await ensureOrigin(baseUrl))) { flash($('status'), 'Izin akses ke server ditolak', 'bad'); return; }
  provCfg[id] = { type: $('ptype').value, baseUrl, apiKey: $('apiKey').value.trim(), model: $('model').value.trim() };
  await chrome.storage.local.set({ provCfg });
  fillProviderSelect();
  flash($('status'), 'Tersimpan');
};
$('resetProv').onclick = async () => {
  delete provCfg[$('provSel').value];
  await chrome.storage.local.set({ provCfg });
  fillProviderSelect(); showProvider();
  flash($('status'), 'Dikembalikan ke bawaan');
};
$('fetchModels').onclick = async () => {
  const st = $('modelStatus');
  const type = $('ptype').value, key = $('apiKey').value.trim(), base = $('baseUrl').value.trim().replace(/\/$/, '');
  if (!key) { st.textContent = ' Isi API key dulu.'; st.className = 'bad'; return; }
  st.className = ''; st.textContent = ' Mengambil...';
  try {
    if (type !== 'anthropic' && !(await ensureOrigin(base))) throw new Error('izin akses ke server ditolak');
    const url = type === 'anthropic' ? 'https://api.anthropic.com/v1/models?limit=100' : base + '/models';
    const headers = type === 'anthropic'
      ? { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' }
      : { authorization: 'Bearer ' + key };
    const r = await fetch(url, { headers });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error?.message || j.error || r.statusText);
    const skip = /whisper|tts|guard|safeguard|embed|orpheus|playai|moderation|transcribe/i;
    const list = (j.data || j.models || []).map((m) => m.id || m.name || m.model).filter((id) => id && !skip.test(id)).sort();
    if (!list.length) throw new Error('Daftar model kosong.');
    const dl = $('modelList'); dl.innerHTML = '';
    list.forEach((id) => { const o = document.createElement('option'); o.value = id; dl.appendChild(o); });
    if (!list.includes($('model').value)) $('model').value = list[0];
    st.className = 'ok';
    st.textContent = ' ' + list.length + ' model ditemukan. Dipilih: ' + $('model').value + ' (ubah lewat kolom Model, lalu Simpan)';
  } catch (err) { st.className = 'bad'; st.textContent = ' Gagal: ' + err.message; }
};

$('changePw').onclick = async () => {
  const np = $('newPw').value;
  if (np.length < 4) { flash($('pwStatus'), 'Minimal 4 karakter.', 'bad'); return; }
  await chrome.storage.local.set({ pwHash: await hashPw(np) });
  $('newPw').value = '';
  flash($('pwStatus'), 'Password diganti');
};

// ---------- Tampilan (sinkron dengan popup) ----------
const PALX = window.LGB_PALETTE;
async function drawTheme() {
  const t = await chrome.storage.local.get({ popupAccent: 'hitam', themeMode: 'dark', customColor: '#7c3aed', glow: 30 });
  document.querySelectorAll('#modeSeg button').forEach((b) => b.classList.toggle('on', b.dataset.mode === t.themeMode));
  const box = $('swatches');
  box.innerHTML = '';
  Object.entries(PALX).forEach(([name, [c1, c2]]) => {
    const b = document.createElement('button');
    b.type = 'button'; b.title = name; b.style.background = `linear-gradient(135deg, ${c1}, ${c2})`;
    if (t.popupAccent === name) b.classList.add('active');
    b.onclick = async () => { await chrome.storage.local.set({ popupAccent: name }); drawTheme(); };
    box.appendChild(b);
  });
  const c = document.createElement('input');
  c.type = 'color'; c.value = t.customColor; c.title = 'Warna sendiri';
  if (t.popupAccent === 'custom') c.style.outline = '2px solid var(--text)';
  c.onchange = async () => { await chrome.storage.local.set({ customColor: c.value, popupAccent: 'custom' }); drawTheme(); };
  box.appendChild(c);
  $('glow').value = t.glow;
  $('gVal').textContent = Number(t.glow) === 0 ? '(mati)' : '(' + t.glow + '%)';
}
document.querySelectorAll('#modeSeg button').forEach((b) => {
  b.onclick = async () => { await chrome.storage.local.set({ themeMode: b.dataset.mode }); drawTheme(); };
});
$('glow').oninput = () => { chrome.storage.local.set({ glow: Number($('glow').value) }); $('gVal').textContent = Number($('glow').value) === 0 ? '(mati)' : '(' + $('glow').value + '%)'; };
$('pingUnit').onchange = () => { chrome.storage.local.set({ pingUnit: $('pingUnit').value }); toast('Indikator jaringan diperbarui'); };
drawTheme();

// ---------- Pintasan ----------
const MAC = /Mac|iPhone|iPad/.test(navigator.platform);
const MOD = MAC ? '⌘' : 'Ctrl';
function kbdHtml(keys) {
  if (!keys) return '<span class="kbd none">belum diatur</span>';
  const parts = keys.includes('+') ? keys.split('+') : [keys];
  return parts.map((k) => '<span class="kbd">' + k.trim() + '</span>').join('');
}
function fillTable(id, rows) {
  $(id).innerHTML = rows.map((r) => '<tr><td style="width:46%;white-space:nowrap">' + r[0] + '</td><td>' + r[1] + '</td></tr>').join('');
}
async function drawKeys() {
  const names = { _execute_action: 'Buka panel AI', 'summarize-page': 'Ringkas halaman ini', 'area-shot': 'Screenshot area ke AI' };
  let cmds = [];
  try { cmds = await chrome.commands.getAll(); } catch (e) { /* abaikan */ }
  const rows = cmds.filter((c) => names[c.name]).map((c) => [kbdHtml(c.shortcut), names[c.name]]);
  fillTable('keysGlobal', rows.length ? rows : [[kbdHtml('Alt+A'), 'Buka panel AI'], [kbdHtml('Alt+S'), 'Ringkas halaman ini'], [kbdHtml('Alt+Shift+S'), 'Screenshot area ke AI']]);
  fillTable('keysPopup', [
    [kbdHtml(MOD + '+K'), 'Command palette (perintah + cari riwayat)'],
    [kbdHtml('Enter'), 'Kirim pesan'],
    [kbdHtml('Shift+Enter'), 'Baris baru'],
    [kbdHtml('/'), 'Daftar perintah: /gambar, /ringkas, /jelaskan, /terjemahkan, /balas, dan perintah kustommu'],
    [kbdHtml('?'), 'Tampilkan semua pintasan (saat kolom tulis kosong)'],
    [kbdHtml('Esc'), 'Tutup menu / dialog'],
    [kbdHtml(MOD + '+V'), 'Tempel gambar dari clipboard']
  ]);
  fillTable('keysPage', [
    ['<span class="kbd">Blok teks</span>', 'Toolbar Jelaskan · Ringkas · Terjemahkan · Balas muncul'],
    [kbdHtml('Esc'), 'Tutup toolbar atau kartu jawaban'],
    ['<span class="kbd">Seret mouse</span>', 'Pilih area screenshot (Esc untuk batal)']
  ]);
}
$('editKeys').onclick = () => chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
drawKeys();
window.addEventListener('focus', drawKeys); // segarkan setelah mengubah di tab lain

// ---------- Target cursor ----------
const CUR = [
  ['cursorOn', 'bool'], ['cursorColor', 'str'], ['cursorColorOnTarget', 'str'], ['cursorSpin', 'num', 1, ' dtk'], ['cursorHover', 'num', 2, ' dtk'],
  ['cursorSize', 'num', 0, ' px'], ['cursorCorner', 'num', 0, ' px'], ['cursorThickness', 'num', 1, ' px'], ['cursorPadding', 'num', 0, ' px'],
  ['cursorDot', 'num', 0, ' px'], ['cursorBlend', 'str'], ['cursorParallax', 'bool'], ['cursorLabel', 'bool'], ['cursorClick', 'bool'],
  ['cursorMatchRadius', 'bool'], ['cursorHide', 'bool']
];
async function loadCursorUI() {
  const st = await chrome.storage.local.get(window.LGB_CURSOR_KEYS);
  CUR.forEach(([k, type, dec, unit]) => {
    const el = $(k); if (!el) return;
    if (type === 'bool') el.checked = !!st[k];
    else if (k === 'cursorColorOnTarget') el.value = st[k] || '#7c3aed';
    else el.value = st[k];
    if (type === 'num') $('v-' + k).textContent = '(' + Number(st[k]).toFixed(dec) + unit + ')';
  });
}
CUR.forEach(([k, type, dec, unit]) => {
  const el = $(k); if (!el) return;
  el.addEventListener(type === 'bool' || el.tagName === 'SELECT' ? 'change' : 'input', () => {
    const v = type === 'bool' ? el.checked : type === 'num' ? Number(el.value) : el.value;
    if (type === 'num') $('v-' + k).textContent = '(' + v.toFixed(dec) + unit + ')';
    chrome.storage.local.set({ [k]: v });
  });
});
$('ccClear').onclick = () => { chrome.storage.local.set({ cursorColorOnTarget: '' }); $('cursorColorOnTarget').value = '#7c3aed'; toast('Warna saat mengunci dikosongkan'); };
$('cursorReset').onclick = async () => { await chrome.storage.local.set(window.LGB_CURSOR_KEYS); loadCursorUI(); toast('Kursor dikembalikan ke bawaan'); };
loadCursorUI();

loadAll();
