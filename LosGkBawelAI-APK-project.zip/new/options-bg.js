// Latar animasi halaman pengaturan (tidak dipakai di popup): bola cair, ferrofluid, topografi.
(function () {
  const KEYS = { bgType: 'balls', bgBalls: true, bgBallsOpacity: 0.35, bgBallsMotion: 'drift' };
  const host = document.getElementById('mbBg');
  if (!host) return;
  const $ = (id) => document.getElementById(id);
  let inst = null, instType = '', st = Object.assign({}, KEYS), randomPick = '';

  const probe = document.createElement('canvas').getContext('2d');
  const hex = (c) => { probe.fillStyle = '#000'; probe.fillStyle = c; return String(probe.fillStyle); };
  const lum = (h) => { const n = parseInt(h.slice(1), 16); return (0.2126 * (n >> 16) + 0.7152 * ((n >> 8) & 255) + 0.0722 * (n & 255)) / 255; };
  function colors() {
    const cs = getComputedStyle(document.documentElement);
    const text = hex(cs.color || '#fff');
    const bg = hex(getComputedStyle(document.body).backgroundColor || '#000');
    const accent = hex((cs.getPropertyValue('--accent') || '').trim() || text);
    const accent2 = hex((cs.getPropertyValue('--accent2') || '').trim() || accent);
    // aksen yang terlalu mirip latar (mis. palet hitam) diganti warna teks agar tetap terlihat
    const ok = (c) => Math.abs(lum(c) - lum(bg)) > 0.28;
    return { color: ok(accent) ? accent : text, cursor: ok(accent2) ? accent2 : text, light: lum(bg) > 0.5, text };
  }

  function effType() {
    let t = st.bgType;
    if (!t || (t === 'balls' && st.bgBalls === false)) t = st.bgBalls === false ? 'off' : 'balls';
    if (t === 'random') { if (!randomPick) randomPick = ['balls', 'ferro', 'topo', 'laser'][Math.floor(Math.random() * 3)]; return randomPick; }
    return t;
  }

  function options(type, c) {
    if (type === 'balls') return { color: c.color, cursorBallColor: c.cursor, motion: st.bgBallsMotion, enableTransparency: true, variant: 'solid',
      ballCount: 14, animationSize: 34, speed: 0.22, gooeyness: 0.55, cursorBallSize: 3.2 };
    if (type === 'ferro') return { colors: [c.light ? '#ffffff' : c.text, c.color, c.cursor], lightMode: c.light, transparent: true, scale: 1.6, speed: 0.4 };
    if (type === 'laser') return { color: c.color, theme: c.light ? 'light' : 'dark', beamPosition: 0.68, surfaceLevel: 0.88, intensity: 1.5, fog: 0.25, dust: 1.2, speed: 1.2 };
    return { color: c.color, lightMode: c.light, lineCount: 22, speed: 0.2, glow: 0.6, fog: 0.4 };
  }
  const CTOR = { balls: 'MetaBalls', ferro: 'Ferrofluid', topo: 'Topography', laser: 'LaserFlow' };

  function apply() {
    host.style.opacity = st.bgBallsOpacity;
    const type = effType();
    if (type === 'off' || !window[CTOR[type]]) { host.hidden = true; if (inst) { inst.destroy(); inst = null; instType = ''; } return; }
    host.hidden = false;
    const o = options(type, colors());
    if (inst && instType !== type) { inst.destroy(); inst = null; }
    if (!inst) {
      try { inst = window[CTOR[type]](host, o); } catch (e) { inst = null; }
      instType = type;
      if (!inst || !inst.ok) { if (inst) inst.destroy(); inst = null; host.hidden = true; return; }
    } else inst.update(o);
  }

  const syncUI = () => {
    if ($('bgType')) $('bgType').value = st.bgType === 'balls' && st.bgBalls === false ? 'off' : st.bgType;
    if ($('bgBallsOpacity')) { $('bgBallsOpacity').value = st.bgBallsOpacity; $('v-bgBallsOpacity').textContent = '(' + Math.round(st.bgBallsOpacity * 100) + '%)'; }
    if ($('bgBallsMotion')) $('bgBallsMotion').value = st.bgBallsMotion;
    const m = $('bgMotionRow'); if (m) m.hidden = !(st.bgType === 'balls' || st.bgType === 'random');
  };
  const save = (k, v) => { st[k] = v; if (k === 'bgType') { st.bgBalls = v !== 'off'; randomPick = ''; try { chrome.storage.local.set({ bgBalls: st.bgBalls }); } catch (e) {} } syncUI(); apply(); try { chrome.storage.local.set({ [k]: v }); } catch (e) {} };

  if ($('bgType')) $('bgType').addEventListener('change', (e) => save('bgType', e.target.value));
  if ($('bgBallsOpacity')) $('bgBallsOpacity').addEventListener('input', (e) => { const v = Number(e.target.value); $('v-bgBallsOpacity').textContent = '(' + Math.round(v * 100) + '%)'; save('bgBallsOpacity', v); });
  if ($('bgBallsMotion')) $('bgBallsMotion').addEventListener('change', (e) => save('bgBallsMotion', e.target.value));

  // warna ikut tema/aksen
  let t = 0;
  new MutationObserver(() => { clearTimeout(t); t = setTimeout(apply, 120); }).observe(document.documentElement, { attributes: true, attributeFilter: ['style', 'data-theme'] });
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', apply);

  try {
    chrome.storage.local.get(KEYS, (r) => { st = Object.assign({}, KEYS, r || {}); syncUI(); apply(); });
    chrome.storage.onChanged.addListener((ch) => { let d = false; for (const k in KEYS) if (ch[k]) { st[k] = ch[k].newValue; d = true; } if (d) { syncUI(); apply(); } });
  } catch (e) { apply(); }
})();
