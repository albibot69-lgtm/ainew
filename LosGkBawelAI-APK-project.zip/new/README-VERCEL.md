# Los Gk Bawel AI — versi web (Vercel)

## Deploy
1. Upload folder ini ke GitHub (atau `vercel deploy` dari folder ini). Framework Preset: **Other**, tanpa build command.
2. Di Vercel: **Settings → Environment Variables**, isi (lihat `vercel-env.txt` yang dikirim terpisah):
   `GROQ_API_KEY`, `OPENROUTER_API_KEY`, `OLLAMA_API_KEY`, `OPENAI_API_KEY`
3. Redeploy. Selesai.

API key hanya ada di server (folder `api/`), tidak pernah dikirim ke browser.

## Panel pratinjau kode
Saat AI menulis blok ```html (atau svg), panel samping terbuka otomatis dan menampilkan hasilnya langsung (live). Blok css dan js terpisah digabung ke html bila perlu. Fitur panel: tab Pratinjau/Kode, ukuran desktop/tablet/ponsel, muat ulang, salin, unduh index.html, buka di tab baru, konsol (error JavaScript muncul di sini), lebar panel bisa digeser. Pratinjau berjalan di iframe terisolasi (sandbox) sehingga kode buatan AI tidak bisa membaca data aplikasi.
Semua blok kode punya sorotan sintaks, tombol Salin dan Unduh.

## Login Google (opsional)
Di Google Cloud Console, pada OAuth Client (Web application), tambahkan:
- Authorized JavaScript origins: `https://DOMAINMU.vercel.app`
- Authorized redirect URIs: `https://DOMAINMU.vercel.app/oauth.html`
Lalu tempel Client ID di layar Akun. Login email (Supabase) langsung jalan.

## Beda dengan extension
Fitur yang butuh akses tab lain disembunyikan: baca/ringkas halaman, jawab soal di halaman, toolbar highlight, Smart Reply, side panel, DevTools, screenshot area.

## v6.7.4 (perbaikan)
- Tampilan rusak setelah redeploy (sidebar tanpa gaya): penyebabnya CSS lama masih di cache browser (max-age 1 jam) sementara HTML sudah baru. Sekarang JS/CSS/HTML selalu divalidasi ulang dan semua file lokal diberi `?v=6.7.4`. Naikkan angka ini saat rilis berikutnya.
- Anti stuck: animasi latar Glass iOS dipindah ke compositor (transform) dan dibatasi ±8 fps, berhenti selama AI menulis; efek kaca kecil diringankan hanya selama jawaban mengalir; pratinjau kode live diperlambat saat streaming.

## Baru di v6.7.5

- **Login/daftar di awal**: pengunjung baru melihat halaman Masuk/Daftar (email+password, Google bila Client ID diisi). Ada tombol "Lanjut tanpa akun" untuk mode tamu.
- **Jatah harian** (zona WIB, dicek di server `api/_lib/guard.js`). Bawaan: tamu 8 chat / 6 suara / 4 pencarian per hari, anggota 80 / 60 / 40. Ubah lewat Environment Variables Vercel:
  `GUEST_DAILY_LIMIT`, `MEMBER_DAILY_LIMIT`, `GUEST_VOICE_LIMIT`, `MEMBER_VOICE_LIMIT`, `GUEST_SEARCH_LIMIT`, `MEMBER_SEARCH_LIMIT`.
- **Penghitung yang andal**: isi `UPSTASH_REDIS_REST_URL` dan `UPSTASH_REDIS_REST_TOKEN` (Upstash Redis gratis). Tanpa itu, hitungan hanya di memori server dan bisa reset saat Vercel menjalankan instance baru.
- **Foto hanya untuk akun yang masuk**: diblok di tampilan dan juga di server (`/api/p`).
- **Cari info terbaru di web** kini lewat server (`/api/search`). Urutan sumber: Ollama web search (`OLLAMA_API_KEY`) → Tavily (`TAVILY_API_KEY`) → Brave (`BRAVE_API_KEY`) → DuckDuckGo → Bing → Wikipedia. Key opsional, tapi sangat disarankan salah satunya agar hasil stabil.
- **Mikrofon** memakai rekaman jernih + Whisper (`whisper-large-v3-turbo` lewat Groq, butuh `GROQ_API_KEY`). Ketuk untuk mulai, ketuk lagi untuk selesai (atau tahan tombol / Alt+V).
- **Nama & pembuat AI**: Los Gk Bawel AI, dibuat oleh Jeremy Ibnu Latif Putra Iman. Prompt inti ada di `defaults.js` (`CORE_PROMPT`).
- Model bawaan Groq naik ke `openai/gpt-oss-120b`; pertanyaan kode/hitungan otomatis memakai nalar lebih dalam.
- Login Google: daftarkan `https://DOMAIN-KAMU/oauth.html` sebagai Authorized redirect URI dan isi Client ID di `DEFAULT_GOOGLE_CLIENT_ID` (defaults.js).

## v6.8.0

**Environment Variables (Vercel → Settings → Environment Variables)**
```
SUPABASE_URL=https://xeeaonhrrmboiowpwxqp.supabase.co
SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
SUPABASE_SECRET_KEY=sb_secret_...        # RAHASIA: hanya di Vercel, jangan di kode / GitHub
OWNER_EMAILS=emailgooglemu@gmail.com     # email yang boleh buka /owner.html (pisahkan koma)
GROQ_API_KEY=...
```
Setelah menambah variabel, **Redeploy**.

**Tanpa Google Cloud**: login email + password sudah cukup dan tidak butuh akun apa pun selain Supabase. Tombol Google/GitHub/Discord di halaman masuk otomatis muncul HANYA kalau provider itu diaktifkan di Supabase (Authentication → Providers). Jangan lupa Site URL = domain Vercelmu dan Redirect URLs berisi `https://DOMAINMU/oauth.html`. Panel owner masuk dengan email + password akun owner (daftar dulu di web, konfirmasi email, lalu isi email itu di `OWNER_EMAILS`).

**Konfirmasi email**: Supabase → Authentication → Sign In / Providers → Email → aktifkan "Confirm email". Tanpa ini email palsu tetap bisa mendaftar. Server juga hanya menghitung akun yang emailnya sudah terkonfirmasi sebagai anggota.

**Panel owner**: ketik `web owner` di chat AI → muncul tombol ke `/owner.html`. Halaman itu tidak ada tombolnya di UI dan hanya bisa dimasuki email di `OWNER_EMAILS` (selain itu tampil 404). Isinya: statistik pemakai, grafik 14 hari, daftar user (cari, ban/unban, hapus, kirim reset password, export CSV), top user, dan pengumuman ke semua pengguna. Password user tidak bisa dilihat (hanya hash).

Tabel `lgb_usage` dan `lgb_announce` sudah dibuat di Supabase (migration `lgb_usage_and_announce`); penghitung limit harian kini memakai database itu, jadi Upstash tidak wajib lagi.


## Cara masuk owner (v6.9.0)
Salah satu cukup (boleh semuanya), lalu Redeploy:
- `OWNER_EMAILS=albibot69@gmail.com` (email harus terkonfirmasi; WAJIB aktifkan "Confirm email" di Supabase)
- `OWNER_DISCORD_IDS=123456789012345678` (Discord User ID, paling aman karena tidak bisa dipalsukan). Cara dapat ID: Discord → Settings → Advanced → Developer Mode ON → klik kanan profilmu → Copy User ID.
- `OWNER_GITHUB=usernamegithubmu`
Kalau belum yakin ID-nya, login saja di /owner.html: halaman 404 akan menampilkan ID Discord/GitHub akunmu untuk disalin.

## v6.9.0

**Peran**: Owner (dari env) → bisa semua. Admin (tabel `lgb_roles`, diberi owner lewat panel) → boleh membuka `/owner.html` tapi hanya MELIHAT (semua aksi ubah ditolak 403 di server). Owner & admin punya centang biru di profil. AI hanya tahu NAMA owner/admin, tidak pernah email.

Env baru (opsional): `OWNER_DISCORD_IDS`, `OWNER_GITHUB`, `GUEST_PROXY_LIMIT`, `MEMBER_PROXY_LIMIT`.

**Fitur baru di web**
- Mode: Chat, Coding, Ringkas, Terjemah (pilih bahasa), Analisis data, Web search, Audio/video → teks (Whisper, ≤25 MB), YouTube → transkrip (`/api/yt`, best-effort: hanya video dengan subtitle).
- Kepercayaan: sitasi `[1]` jadi tautan ke sumber web, label sumber data (pencarian web + waktu / file / gambar / pengetahuan model), disclaimer AI bisa salah, mode "akui saat tidak yakin", tombol Periksa ulang.
- Suara keluar (Listen + baca otomatis + kecepatan), ekspor tiap jawaban: Markdown, TXT, Word, PDF (cetak), PowerPoint, CSV (tabel pertama), PNG.
- Profil → Pengaturan: Memori & instruksi (lihat/ubah/hapus, impor/ekspor), Skill & plugin (skill bawaan + buatan sendiri, plugin HTTP `@nama pertanyaan`), Suara & jawaban, reset password.
- Bahasa: seluruh UI mengikuti bahasa pilihan (kamus + terjemahan AI yang di-cache).

**Tes keamanan**: `node --experimental-default-type=module tests/security.mjs` (63 tes: otorisasi owner/admin/user, SSRF proxy, path traversal, origin, limit).

Catatan: plugin dipanggil langsung dari browser, jadi API-nya harus mengizinkan CORS. Hasil plugin diperlakukan sebagai data, bukan perintah.

## v6.9.1
- Provider baru **Gemini** (urutan ke-2 di dropdown, model `gemini-2.5-flash`, bisa baca gambar). Isi env `GEMINI_API_KEY` di Vercel lalu Redeploy. Key TIDAK ditulis di kode.
- Pemilih mode sekarang dropdown kecil di atas kolom tulis (Chat, Coding, Ringkas, Terjemah, Analisis data + Web search, Audio/video, YouTube).
- Web owner: lencana `OWNER · email` / `ADMIN · email` di header.

## v6.9.2
- Gemini sekarang lewat API Gemini asli (adaptor di `api/_lib/gemini.js`, header `x-goog-api-key`), jadi key baru berawalan `AQ.` jalan. Pesan error jadi jelas (bukan "HTTP 404").
- Perbaikan scroll: chat yang lompat/ter-skip (terutama blok kode) karena `content-visibility` + anchor scroll dimatikan.

## v6.9.3
- Gemini: model bawaan `gemini-3.8-flash`; kalau model dipensiunkan Google (404 "no longer available"), server otomatis memilih Gemini Flash terbaru yang tersedia untuk key-mu lalu mengulang sekali.
- Toolbar saat teks di chat di-blok: Balas (kutip ke kolom tulis), Jelaskan, Ringkas / Perbaiki kode (jika blok kode), Terjemahkan, Salin. Jalan di desktop dan HP.
