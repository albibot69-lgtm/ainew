// Port vanilla JS dari React Bits <LatticeLoader />: kisi titik yang menyala bergelombang + stopwatch.
// LatticeLoader(host, {label, doneLabel, errorLabel, pattern, grid, shape, ...}) -> {el, setStatus, setLabel, destroy}
(function () {
const PATTERNS = {
  arrow: { 3: { cells: [1, 2, 3, 0, 1, 2, 1, 2, 3], loop: 7.2, scale: 1 } },
  dots: { 3: { cells: [0, 1, 2, 0, 1, 2, 0, 1, 2], loop: 3, scale: 2.4 } },
  ripple: { 3: { cells: [2, 1, 2, 1, 0, 1, 2, 1, 2], loop: 4.8, scale: 1.5 } },
  spiral: { 3: { cells: [0, 1, 2, 7, 8, 3, 6, 5, 4], loop: 9, scale: 1.2, lit: 0.35 } },
  orbit: {
    3: { cells: [0, 1, 2, 7, null, 3, 6, 5, 4], loop: 8, scale: 1.2 },
    4: { cells: [0, 1, 2, 3, 11, null, null, 4, 10, null, null, 5, 9, 8, 7, 6], loop: 6, scale: 1.2, lit: 0.45 }
  },
  snake: {
    3: { cells: [0, 1, 2, 5, 4, 3, 6, 7, 8], loop: 9, scale: 1, lit: 0.35 },
    4: { cells: [0, 1, 2, 3, 7, 6, 5, 4, 8, 9, 10, 11, 15, 14, 13, 12], loop: 16, scale: 1, lit: 0.25 }
  },
  sweep: { 4: { cells: [0, 1, 2, 3, 1, 2, 3, 4, 2, 3, 4, 5, 3, 4, 5, 6], loop: 5, scale: 1, lit: 0.45 } },
  spin: { 4: { cells: [0, 0, 1, 1, 0, 0, 1, 1, 3, 3, 2, 2, 3, 3, 2, 2], loop: 4, scale: 1.6, lit: 0.35 } },
  rain: { 4: { cells: [0, 2, 1, 3, 1, 3, 2, 4, 2, 4, 3, 5, 3, 5, 4, 6], loop: 4, scale: 1.2, lit: 0.35 } },
  pulse: { 4: { cells: [2, 1, 1, 2, 1, 0, 0, 1, 1, 0, 0, 1, 2, 1, 1, 2], loop: 2.4, scale: 2.5, lit: 0.45 } }
};
const DEFAULT_PATTERN = { 3: 'orbit', 4: 'sweep' };
const MARKS = {
  3: { done: [2, 3, 5, 7], error: [0, 2, 4, 6, 8] },
  4: { done: [7, 8, 10, 13], error: [0, 3, 5, 6, 9, 10, 12, 15] }
};

const resolvePattern = (pattern, grid) => {
  if (typeof pattern === 'string') {
    const named = PATTERNS[pattern];
    return (named && named[grid]) || PATTERNS[DEFAULT_PATTERN[grid]][grid];
  }
  const cells = Array.from({ length: grid * grid }, (_, i) => (pattern.cells[i] != null ? pattern.cells[i] : null));
  const max = Math.max(0, ...cells.filter(v => v != null));
  return { cells, loop: pattern.loop != null ? pattern.loop : max + 4.2, scale: pattern.scale != null ? pattern.scale : 1, lit: pattern.lit != null ? pattern.lit : 0.62 };
};
const fmt = ds => (ds < 600 ? (ds / 10).toFixed(1) + 's' : Math.floor(ds / 600) + 'm ' + ((ds % 600) / 10).toFixed(1) + 's');

function LatticeLoader(host, o) {
  o = Object.assign({ label: 'Thinking', doneLabel: 'Done in', errorLabel: 'Failed after', status: 'working', pattern: 'orbit', grid: 3, shape: 'round',
    color: 'currentColor', doneColor: '#22c55e', errorColor: '#ef4444', cellSize: 6, gap: 2, fontSize: 14, step: 90, idleOpacity: 0.15,
    glow: false, glowColor: '', showTimer: true }, o || {});
  const n = o.grid === 4 ? 4 : 3;
  const pat = resolvePattern(o.pattern, n);
  const marks = MARKS[n];
  const d = o.step * pat.scale;
  const cycle = Math.round(pat.loop * d);
  const mk = (tag, cls, attrs) => { const e = document.createElement(tag); if (cls) e.className = cls; if (attrs) for (const k in attrs) e.setAttribute(k, attrs[k]); return e; };

  const el = mk('span', 'lattice-loader', { role: 'status' });
  el.dataset.shape = o.shape;
  if (o.glow) el.setAttribute('data-glow', '');
  const sv = (k, v) => el.style.setProperty(k, v);
  sv('--ll-n', n); sv('--ll-cell', o.cellSize + 'px'); sv('--ll-gap', o.gap + 'px'); sv('--ll-font', o.fontSize + 'px');
  sv('--ll-color', o.color); sv('--ll-idle', o.idleOpacity); sv('--ll-glow', o.glowColor || o.color); sv('--ll-cycle', cycle + 'ms');
  sv('--ll-mark', o.doneColor); sv('--ll-mark-glow', o.glowColor || o.doneColor);

  const grid = mk('span', 'lattice-loader__grid', { 'aria-hidden': 'true' });
  const run = mk('span', 'lattice-loader__layer lattice-loader__run');
  pat.cells.forEach(unit => {
    const c = mk('span', 'lattice-loader__cell');
    if (unit == null) c.setAttribute('data-hole', '');
    else c.style.animationDelay = Math.round(unit * d) + 'ms';
    if (pat.lit && pat.lit !== 0.62) c.setAttribute('data-lit', Math.round(pat.lit * 100));
    run.appendChild(c);
  });
  const markLayer = mk('span', 'lattice-loader__layer lattice-loader__mark');
  const markCells = pat.cells.map(() => { const c = mk('span', 'lattice-loader__cell'); markLayer.appendChild(c); return c; });
  grid.append(run, markLayer);

  const labelBox = mk('span', 'lattice-loader__label', { 'aria-hidden': 'true' });
  const tWork = mk('span', 'lattice-loader__text'), tDone = mk('span', 'lattice-loader__text'), tErr = mk('span', 'lattice-loader__text');
  tWork.textContent = o.label; tDone.textContent = o.doneLabel; tErr.textContent = o.errorLabel;
  labelBox.append(tWork, tDone, tErr);
  const timer = o.showTimer ? mk('span', 'lattice-loader__timer', { 'aria-hidden': 'true' }) : null;
  if (timer) timer.textContent = '0.0s';
  const sr = mk('span', 'lattice-loader__sr');
  el.append(grid, labelBox);
  if (timer) el.appendChild(timer);
  el.appendChild(sr);
  host.appendChild(el);

  let ds = 0, started = performance.now(), iv = 0, lastMark = 'done';
  const paint = v => { ds = v; if (timer) timer.textContent = fmt(v); };
  const stop = () => { clearInterval(iv); iv = 0; };
  function setStatus(s) {
    el.dataset.status = s;
    if (s === 'working') { started = performance.now(); paint(0); stop(); iv = setInterval(() => { if (!el.isConnected) return stop(); paint(Math.floor((performance.now() - started) / 100)); }, 100); }
    else { stop(); lastMark = s; }
    const key = s === 'working' ? lastMark : s;
    sv('--ll-mark', s === 'error' ? o.errorColor : o.doneColor);
    sv('--ll-mark-glow', o.glowColor || (s === 'error' ? o.errorColor : o.doneColor));
    markCells.forEach((c, i) => (marks[key].includes(i) ? c.setAttribute('data-on', '') : c.removeAttribute('data-on')));
    tWork.toggleAttribute('data-active', s === 'working');
    tDone.toggleAttribute('data-active', s === 'done');
    tErr.toggleAttribute('data-active', s === 'error');
    sr.textContent = s === 'working' ? o.label + ', in progress' : (s === 'done' ? o.doneLabel : o.errorLabel) + (timer ? ' ' + fmt(ds) : '');
  }
  setStatus(o.status);
  return { el, setStatus, setLabel(t) { tWork.textContent = t; }, destroy() { stop(); el.remove(); } };
}
window.LatticeLoader = LatticeLoader;
})();
