// Port vanilla JS dari komponen SlideCommit (React Bits): geser kapsul sampai ujung untuk konfirmasi.
// Pegas & tween ditulis sendiri (tanpa library motion).
function SlideCommit(host, o) {
  o = o || {};
  const PAD = 4, SQUASH_MAX = 0.08, SQUASH_DIV = 110, SWELL = 1.03, MIN_PENDING = 300;
  const width = o.width || 280, height = o.height || 56, holdMs = o.holdMs ?? 1500;
  const landingDip = o.landingDip ?? 0.026, returnBounce = o.returnBounce ?? 0.38;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const GRIP = height - PAD * 2, INNER = width - PAD * 2, TRAVEL = Math.max(1, INNER - GRIP);
  const r = clamp(o.radius ?? 28, 0, height / 2), gripR = Math.max(0, r - PAD);
  const kk = 260 + (clamp(o.speed ?? 50, 0, 100) / 100) * 640, mass = 0.9, critical = 2 * Math.sqrt(kk * mass);
  const commitSpring = { k: kk, c: critical, m: mass };
  const homeSpring = { k: kk, c: critical * (1 - clamp(returnBounce, 0, 0.5)), m: mass };
  const ease = (p) => 1 - Math.pow(1 - p, 4);

  // nilai yang dianimasikan
  const val = { x: 0, anchor: 0, shown: 1, spin: 0, pulse: 1, shake: 0 };
  let phase = 'idle', held = false, hot = false, grip = null, runId = 0, timerA = 0, timerB = 0, unwatch = null;
  const anim = {};
  const stopAnim = (n) => { if (anim[n]) { cancelAnimationFrame(anim[n]); anim[n] = 0; } };
  function spring(n, to, cfg, v0) {
    stopAnim(n);
    let v = v0 || 0, last = performance.now();
    const step = (now) => {
      const dt = Math.min(0.032, (now - last) / 1000); last = now;
      const c = Math.max(1, Math.ceil(dt / 0.004)), h = dt / c;
      for (let i = 0; i < c; i++) { v += ((-cfg.k * (val[n] - to) - cfg.c * v) / cfg.m) * h; val[n] += v * h; }
      paint();
      if (Math.abs(val[n] - to) < 0.02 && Math.abs(v) < 0.5) { val[n] = to; paint(); anim[n] = 0; return; }
      anim[n] = requestAnimationFrame(step);
    };
    anim[n] = requestAnimationFrame(step);
  }
  function tween(n, keys, dur, delay) {   // keys: [nilai...] dibagi rata; delay dalam detik
    stopAnim(n);
    const from = val[n], seq = Array.isArray(keys) ? [from, ...keys] : [from, keys];
    const t0 = performance.now() + (delay || 0) * 1000;
    const step = (now) => {
      const p = clamp((now - t0) / (dur * 1000), 0, 1);
      if (now >= t0) {
        const segs = seq.length - 1, f = p * segs, i = Math.min(segs - 1, Math.floor(f));
        val[n] = seq[i] + (seq[i + 1] - seq[i]) * ease(f - i);
        paint();
      }
      if (p < 1) anim[n] = requestAnimationFrame(step); else { val[n] = seq[seq.length - 1]; paint(); anim[n] = 0; }
    };
    anim[n] = requestAnimationFrame(step);
  }

  // DOM
  const root = document.createElement('div');
  root.className = 'slide-commit'; root.style.width = width + 'px'; root.style.height = height + 'px';
  root.style.setProperty('--sc-radius', r + 'px'); root.style.setProperty('--sc-grip-r', gripR + 'px'); root.style.setProperty('--sc-pad', PAD + 'px');
  root.style.setProperty('--sc-font', clamp(Math.round(height * 0.25), 13, 17) + 'px');
  [['track', '--sc-track'], ['handleColor', '--sc-ink'], ['successColor', '--sc-ok'], ['dangerColor', '--sc-no']].forEach(([k, v]) => { if (o[k === 'track' ? 'trackColor' : k]) root.style.setProperty(v, o[k === 'track' ? 'trackColor' : k]); });
  const iconSize = Math.round(GRIP * 0.42);
  root.innerHTML =
    '<div class="slide-commit__track"><span class="slide-commit__label" aria-hidden="true"><span class="slide-commit__text slide-commit__text--plain"></span><span class="slide-commit__text slide-commit__text--error"></span></span>' +
    '<div class="slide-commit__capsule" role="slider" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="slide-commit__content">' +
    '<span class="slide-commit__arrow" aria-hidden="true">' + (o.icon || '<svg width="' + iconSize + '" height="' + iconSize + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>') + '</span>' +
    '<span class="slide-commit__spin" aria-hidden="true"><svg class="slide-commit__spinner" width="' + iconSize + '" height="' + iconSize + '" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2.4" stroke-opacity=".25"/><path d="M12 3a9 9 0 0 1 9 9" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg></span>' +
    '<span class="slide-commit__done" aria-hidden="true"><svg width="' + Math.round(GRIP * 0.38) + '" height="' + Math.round(GRIP * 0.38) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 14L8.5 17.5L19 6.5"/></svg><b></b></span>' +
    '</div></div><span class="slide-commit__sr" aria-live="polite"></span></div>';
  host.appendChild(root);
  const q = (s) => root.querySelector(s);
  const track = q('.slide-commit__track'), capsule = q('.slide-commit__capsule'), content = q('.slide-commit__content'),
    arrow = q('.slide-commit__arrow'), spinEl = q('.slide-commit__spin'), label = q('.slide-commit__label'), sr = q('.slide-commit__sr');
  q('.slide-commit__text--plain').textContent = o.label || 'Geser untuk konfirmasi';
  q('.slide-commit__text--error').textContent = o.errorLabel || 'Gagal';
  q('.slide-commit__done b').textContent = o.doneLabel || 'Selesai';
  const labelText = o.label || 'Geser untuk konfirmasi';
  capsule.setAttribute('aria-label', labelText);
  capsule.tabIndex = o.disabled ? -1 : 0;
  root.toggleAttribute('data-disabled', !!o.disabled);

  let lastPercent = -1;
  function paint() {
    const seen = clamp(val.x, 0, TRAVEL);
    const edge = seen + GRIP + clamp(val.anchor - seen, 0, TRAVEL);
    capsule.style.clipPath = 'inset(0 ' + (INNER - edge) + 'px 0 0 round ' + gripR + 'px)';
    content.style.transform = 'translateX(' + ((seen + edge) / 2 - INNER / 2) + 'px)';
    const sw = hot && !held && phase === 'idle' && !reduce ? SWELL : 1;
    const sq = 1 - Math.min(SQUASH_MAX, Math.max(0, -val.x) / SQUASH_DIV);
    capsule.style.transform = 'scale(' + sq * sw + ',' + sw / sq + ')';
    capsule.style.transformOrigin = seen + 'px 50%';
    label.style.opacity = clamp(1 - seen / (TRAVEL * 0.55), 0, 1);
    arrow.style.opacity = val.shown * clamp(1 - (seen - TRAVEL * 0.55) / (TRAVEL * 0.4), 0, 1);
    spinEl.style.opacity = val.spin;
    track.style.transform = 'translateX(' + val.shake + 'px) scale(' + val.pulse + ')';
    const pct = Math.round((seen / TRAVEL) * 100);
    if (pct !== lastPercent) { lastPercent = pct; capsule.setAttribute('aria-valuenow', String(pct)); capsule.setAttribute('aria-valuetext', labelText + ', ' + pct + '%'); }
  }
  function setPhase(p) {
    phase = p; root.dataset.phase = p;
    sr.textContent = p === 'pending' ? 'Memproses' : p === 'done' ? (o.doneLabel || '') : p === 'error' ? (o.errorLabel || '') : '';
  }
  const goHome = (vel) => { if (reduce) tween('x', 0, 0.2); else spring('x', 0, homeSpring, Math.min(0, vel)); };
  function settle() {
    setPhase('idle'); tween('shown', 1, 0.2, 0.12);
    if (reduce) { val.anchor = 0; paint(); } else spring('anchor', 0, { k: 600, c: 2 * Math.sqrt(600), m: 1 });
  }
  function resolve(viaKey) {
    setPhase('done'); val.anchor = val.x; tween('spin', 0, 0.12);
    if (reduce) { val.x = 0; paint(); }
    else {
      spring('x', 0, commitSpring);
      if (!viaKey && landingDip > 0) tween('pulse', [1 - landingDip, 1], 0.46, 0.1);
    }
    o.onDone && o.onDone();
    if (holdMs > 0) timerA = setTimeout(settle, holdMs);
  }
  function reject(reason) {
    setPhase('error'); o.onError && o.onError(reason);
    tween('spin', 0, 0.12); tween('shown', 1, 0.2, 0.12);
    if (reduce) goHome(0);
    else {
      tween('shake', [-5, 5, -3, 3, -1, 0], 0.45);
      timerB = setTimeout(() => { if (!grip) goHome(0); }, 300);
    }
    timerA = setTimeout(() => setPhase('idle'), Math.max(holdMs, 1500));
  }
  function commit(viaKey) {
    clearTimeout(timerA);
    const id = ++runId;
    stopAnim('x'); val.x = TRAVEL; paint();
    let out;
    try { out = o.onConfirm && o.onConfirm(); } catch (e) { reject(e); return; }
    const pending = out && typeof out.then === 'function' ? out : null;
    if (!pending) { tween('shown', 0, 0.12); resolve(viaKey); return; }
    setPhase('pending'); tween('shown', 0, 0.2); tween('spin', 1, 0.2);
    const t0 = performance.now();
    const later = (fn) => setTimeout(() => { if (id === runId) fn(); }, Math.max(0, MIN_PENDING - (performance.now() - t0)));
    pending.then(() => later(() => resolve(viaKey)), (e) => later(() => reject(e)));
  }

  const local = (cx) => { const rc = track.getBoundingClientRect(); return (cx - rc.left) / (rc.width / width || 1); };
  const velocityOf = (h) => { if (h.length < 2) return 0; const [t0, x0] = h[0], [t1, x1] = h[h.length - 1]; return ((x1 - x0) / Math.max(1, t1 - t0)) * 1000; };
  function onMove(e) {
    if (!grip || grip.id !== e.pointerId) return;
    const at = local(e.clientX);
    if (grip.grab === null) { grip.grab = at - val.x; return; }
    const next = clamp(at - grip.grab, 0, TRAVEL);
    if (Math.abs(next - val.x) > 0.5) grip.moved = true;
    grip.hist.push([e.timeStamp, next]); if (grip.hist.length > 4) grip.hist.shift();
    val.x = next; paint();
  }
  function onUp(e) {
    if (!grip || grip.id !== e.pointerId) return;
    const g = grip; grip = null;
    unwatch && unwatch();
    try { track.releasePointerCapture(e.pointerId); } catch { /* sudah lepas */ }
    held = false; paint();
    if (val.x >= TRAVEL) commit(false); else if (g.moved) goHome(velocityOf(g.hist));
  }
  track.addEventListener('pointerdown', (e) => {
    if (root.hasAttribute('data-disabled') || grip || phase === 'pending' || phase === 'done' || e.button !== 0) return;
    stopAnim('x');
    grip = { id: e.pointerId, grab: null, moved: false, hist: [] };
    held = true; root.setAttribute('data-held', '');
    try { track.setPointerCapture(e.pointerId); } catch { /* abaikan */ }
    unwatch && unwatch();
    const mv = (ev) => ev.isTrusted && onMove(ev), up = (ev) => { if (ev.isTrusted) { root.removeAttribute('data-held'); onUp(ev); } };
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up); window.addEventListener('pointercancel', up);
    unwatch = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); window.removeEventListener('pointercancel', up); unwatch = null; };
  });
  capsule.addEventListener('pointerenter', (e) => { if (e.pointerType === 'mouse') { hot = true; paint(); } });
  capsule.addEventListener('pointerleave', () => { hot = false; paint(); });
  capsule.addEventListener('keydown', (e) => {
    if (root.hasAttribute('data-disabled') || phase === 'pending' || phase === 'done') return;
    const step = TRAVEL / 10;
    if (e.key === 'End') { e.preventDefault(); commit(true); }
    else if (e.key === 'ArrowRight' || e.key === 'ArrowUp') { e.preventDefault(); val.x = Math.min(TRAVEL, val.x + step); paint(); if (val.x >= TRAVEL) commit(true); }
    else if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') { e.preventDefault(); val.x = Math.max(0, val.x - step); paint(); }
    else if (e.key === 'Home') { e.preventDefault(); val.x = 0; paint(); }
  });
  setPhase('idle'); paint();
  return {
    el: root,
    setDisabled(b) { root.toggleAttribute('data-disabled', !!b); capsule.tabIndex = b ? -1 : 0; if (b && phase === 'idle') { val.x = 0; paint(); } },
    get phase() { return phase; }
  };
}
