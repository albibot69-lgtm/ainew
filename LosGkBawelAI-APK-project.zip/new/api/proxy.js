// Proxy generik untuk situs yang tidak mengizinkan CORS (pencarian web, Notion, provider buatan sendiri).
import { gate, deny } from './_lib/guard.js';
export const config = { runtime: 'edge' };

const BAD = /^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|0\.|169\.254\.|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.|192\.0\.0\.|198\.1[89]\.|\[|.*\.(local|localhost|internal|lan|home|corp|intranet)$)/i;
const NUMERIC = /^(0x[0-9a-f]+|\d+)(\.(0x[0-9a-f]+|\d+))*$/i; // IP desimal/heksa/oktal terselubung
const PASS = ['content-type', 'authorization', 'accept', 'x-api-key', 'anthropic-version', 'anthropic-dangerous-direct-browser-access', 'notion-version', 'openai-organization'];

export default async function handler(req) {
  const url = new URL(req.url);
  const origin = req.headers.get('origin');
  if (!origin && req.method !== 'GET') return new Response('Forbidden', { status: 403 });
  if (origin) { try { if (new URL(origin).host !== url.host) return new Response('Forbidden', { status: 403 }); } catch { return new Response('Forbidden', { status: 403 }); } }
  let t;
  try { t = new URL(url.searchParams.get('u') || ''); } catch { return new Response('URL tidak valid', { status: 400 }); }
  if (t.protocol !== 'https:' || BAD.test(t.hostname) || NUMERIC.test(t.hostname) || t.username || t.password) return new Response('Tujuan tidak diizinkan', { status: 400 });
  if (t.host === url.host) return new Response('Loop', { status: 400 });

  const gr = await gate(req, 'proxy', 1);
  if (gr.res) return gr.res;

  const h = new Headers();
  PASS.forEach((k) => { const v = req.headers.get(k); if (v) h.set(k, v); });
  h.set('user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36');
  const init = { method: req.method, headers: h, signal: req.signal, redirect: 'manual' };
  if (req.method !== 'GET' && req.method !== 'HEAD') init.body = await req.arrayBuffer();
  let r;
  try { r = await fetch(t.href, init); } catch (e) { return new Response(JSON.stringify({ error: { message: 'Gagal: ' + e.message } }), { status: 502, headers: { 'content-type': 'application/json' } }); }
  // redirect diikuti manual agar tidak bisa dibelokkan ke alamat internal
  if (r.status >= 300 && r.status < 400) { const loc = r.headers.get('location'); try { const n = new URL(loc, t); if (n.protocol !== 'https:' || BAD.test(n.hostname) || NUMERIC.test(n.hostname)) return new Response('Tujuan tidak diizinkan', { status: 400 }); init.redirect = 'follow'; r = await fetch(n.href, init); } catch (e) { return new Response('Redirect tidak valid', { status: 400 }); } }
  const out = new Headers();
  ['content-type', 'retry-after'].forEach((k) => { const v = r.headers.get(k); if (v) out.set(k, v); });
  out.set('cache-control', 'no-store');
  return new Response(r.body, { status: r.status, headers: out });
}
