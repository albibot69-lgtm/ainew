// Daftar nama owner & admin (hanya NAMA, tanpa email) supaya AI dan tampilan tahu siapa mereka.
import { OWNER_NAME, adminRows } from './_lib/guard.js';
export const config = { runtime: 'edge' };
export default async function handler() {
  const rows = await adminRows();
  const admins = rows.filter((x) => x.role === 'admin' && x.display_name).map((x) => x.display_name);
  return new Response(JSON.stringify({ owner: OWNER_NAME, admins }), { headers: { 'content-type': 'application/json', 'cache-control': 'public, max-age=60' } });
}
