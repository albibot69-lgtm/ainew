// Pengumuman dari pemilik untuk semua pengguna (publik, hanya baca).
import { SB_URLX } from './_lib/guard.js';
export const config = { runtime: 'edge' };
export default async function handler() {
  const key = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_KEY || 'sb_publishable_h-mBhZM6j96qwSBzrHN4xQ_UlddLtnc';
  let items = [];
  try {
    const r = await fetch(SB_URLX + '/rest/v1/lgb_announce?select=id,title,body,created_at&active=eq.true&order=id.desc&limit=5', { headers: { apikey: key }, signal: AbortSignal.timeout(5000) });
    if (r.ok) items = await r.json();
  } catch (e) { /* abaikan */ }
  return new Response(JSON.stringify({ items }), { headers: { 'content-type': 'application/json', 'cache-control': 'public, max-age=60' } });
}
