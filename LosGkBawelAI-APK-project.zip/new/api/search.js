// Pencarian web di sisi server. Urutan sumber: Ollama web search -> Tavily -> Brave (jika key tersedia)
// lalu DuckDuckGo -> Bing -> Wikipedia (tanpa key). Hasil teratas diperkaya dengan cuplikan isi halaman.
import { gate, deny } from './_lib/guard.js';
export const config = { runtime: 'edge' };

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36';
const T = (ms) => AbortSignal.timeout(ms);
const ent = (s) => s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#x27;|&#39;/g, "'").replace(/&nbsp;/g, ' ').replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n));
const txt = (s) => ent(String(s || '').replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
const clip = (s, n) => (s.length > n ? s.slice(0, n - 1) + '…' : s);

async function viaOllama(q) {
  const k = process.env.OLLAMA_API_KEY; if (!k) return [];
  const r = await fetch('https://ollama.com/api/web_search', { method: 'POST', headers: { Authorization: 'Bearer ' + k, 'content-type': 'application/json' }, body: JSON.stringify({ query: q, max_results: 6 }), signal: T(9000) });
  if (!r.ok) throw new Error('ollama ' + r.status);
  const j = await r.json();
  return (j.results || []).map((x) => ({ title: x.title, url: x.url, snippet: clip(txt(x.content), 1500), rich: true }));
}
async function viaTavily(q) {
  const k = process.env.TAVILY_API_KEY; if (!k) return [];
  const r = await fetch('https://api.tavily.com/search', { method: 'POST', headers: { Authorization: 'Bearer ' + k, 'content-type': 'application/json' }, body: JSON.stringify({ query: q, max_results: 6, search_depth: 'basic' }), signal: T(9000) });
  if (!r.ok) throw new Error('tavily ' + r.status);
  const j = await r.json();
  return (j.results || []).map((x) => ({ title: x.title, url: x.url, snippet: clip(txt(x.content), 1500), rich: true }));
}
async function viaBrave(q) {
  const k = process.env.BRAVE_API_KEY; if (!k) return [];
  const r = await fetch('https://api.search.brave.com/res/v1/web/search?count=6&q=' + encodeURIComponent(q), { headers: { 'X-Subscription-Token': k, Accept: 'application/json' }, signal: T(8000) });
  if (!r.ok) throw new Error('brave ' + r.status);
  const j = await r.json();
  return ((j.web && j.web.results) || []).map((x) => ({ title: txt(x.title), url: x.url, snippet: txt(x.description) }));
}
async function viaDDG(q) {
  const r = await fetch('https://html.duckduckgo.com/html/', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded', 'user-agent': UA, accept: 'text/html', 'accept-language': 'id,en;q=0.8' }, body: 'q=' + encodeURIComponent(q) + '&kl=id-id', signal: T(8000) });
  if (!r.ok) throw new Error('ddg ' + r.status);
  const html = await r.text();
  const out = [];
  html.split(/<div class="result[ "]/).slice(1).forEach((b) => {
    if (/result--ad/.test(b.slice(0, 80))) return;
    const a = b.match(/<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/); if (!a) return;
    let href = ent(a[1]); const m = href.match(/[?&]uddg=([^&]+)/); if (m) href = decodeURIComponent(m[1]); if (href.startsWith('//')) href = 'https:' + href;
    const s = b.match(/class="result__snippet"[^>]*>([\s\S]*?)<\/a>/);
    out.push({ title: txt(a[2]), url: href, snippet: s ? txt(s[1]) : '' });
  });
  return out.slice(0, 6);
}
function bingUrl(h) {
  try { const u = new URL(h); if (/bing\.com$/.test(u.hostname) && u.pathname.startsWith('/ck/')) { let v = u.searchParams.get('u') || ''; if (v.startsWith('a1')) { v = v.slice(2).replace(/-/g, '+').replace(/_/g, '/'); return atob(v + '==='.slice((v.length + 3) % 4)); } } } catch (e) { /* abaikan */ }
  return h;
}
async function viaBing(q) {
  const r = await fetch('https://www.bing.com/search?setlang=id&cc=ID&q=' + encodeURIComponent(q), { headers: { 'user-agent': UA, accept: 'text/html', 'accept-language': 'id,en;q=0.8' }, signal: T(8000) });
  if (!r.ok) throw new Error('bing ' + r.status);
  const html = await r.text(), out = [];
  html.split(/<li class="b_algo"/).slice(1).forEach((b) => {
    const a = b.match(/<h2[^>]*><a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/); if (!a) return;
    const s = b.match(/<p[^>]*>([\s\S]*?)<\/p>/);
    out.push({ title: txt(a[2]), url: bingUrl(ent(a[1])), snippet: s ? txt(s[1]) : '' });
  });
  return out.slice(0, 6);
}
async function viaWiki(q) {
  const out = [];
  for (const lang of ['id', 'en']) {
    try {
      const r = await fetch('https://' + lang + '.wikipedia.org/w/api.php?action=query&list=search&srlimit=3&format=json&srsearch=' + encodeURIComponent(q), { signal: T(6000) });
      const j = await r.json();
      (j.query && j.query.search || []).forEach((x) => out.push({ title: x.title + ' (Wikipedia)', url: 'https://' + lang + '.wikipedia.org/wiki/' + encodeURIComponent(x.title.replace(/ /g, '_')), snippet: txt(x.snippet) }));
    } catch (e) { /* abaikan */ }
    if (out.length >= 3) break;
  }
  return out;
}
async function pageText(u) {
  try {
    const r = await fetch(u, { headers: { 'user-agent': UA, accept: 'text/html' }, signal: T(4500), redirect: 'follow' });
    if (!r.ok || !/text\/html/.test(r.headers.get('content-type') || '')) return '';
    let h = (await r.text()).slice(0, 400000);
    h = h.replace(/<(script|style|noscript|svg|nav|footer|header|aside)[\s\S]*?<\/\1>/gi, ' ');
    const main = h.match(/<(article|main)[\s\S]*?<\/\1>/i);
    return clip(txt(main ? main[0] : h), 1800);
  } catch (e) { return ''; }
}

export default async function handler(req) {
  const url = new URL(req.url);
  const origin = req.headers.get('origin');
  if (origin) { try { if (new URL(origin).host !== url.host) return deny(403, 'Forbidden'); } catch { return deny(403, 'Forbidden'); } }
  const q = (url.searchParams.get('q') || '').replace(/\s+/g, ' ').trim().slice(0, 300);
  if (!q) return deny(400, 'Kata kunci kosong.');
  const g = await gate(req, 'search', 1);
  if (g.res) return g.res;

  const tried = [];
  let results = [], source = '';
  for (const [name, fn] of [['ollama', viaOllama], ['tavily', viaTavily], ['brave', viaBrave], ['duckduckgo', viaDDG], ['bing', viaBing], ['wikipedia', viaWiki]]) {
    try { const r = (await fn(q)).filter((x) => x.url && /^https?:/.test(x.url)); if (r.length) { results = r; source = name; break; } tried.push(name + ': kosong'); }
    catch (e) { tried.push(name + ': ' + (e.message || 'gagal')); }
  }
  // perkaya 2 hasil teratas yang cuplikannya pendek
  if (results.length && !results[0].rich) {
    await Promise.all(results.slice(0, 2).map(async (x) => { if (/wikipedia\.org/.test(x.url) && x.snippet.length > 60) return; const t = await pageText(x.url); if (t && t.length > x.snippet.length) x.snippet = t; }));
  }
  return new Response(JSON.stringify({ source, results: results.slice(0, 6).map(({ title, url: u, snippet }) => ({ title, url: u, snippet })), tried }), { headers: Object.assign({ 'content-type': 'application/json', 'cache-control': 'no-store' }, g.headers) });
}
