// Proxy AI: API key disimpan di Environment Variables Vercel, tidak pernah dikirim ke browser.
import { gate, who, deny } from './_lib/guard.js';
import { geminiChat, geminiModels } from './_lib/gemini.js';

export const config = { runtime: 'edge' };

const UP = {
  groq: { base: 'https://api.groq.com/openai/v1', env: 'GROQ_API_KEY' },
  openrouter: { base: 'https://openrouter.ai/api/v1', env: 'OPENROUTER_API_KEY' },
  ollama: { base: 'https://ollama.com/v1', env: 'OLLAMA_API_KEY' },
  openai: { base: 'https://api.openai.com/v1', env: 'OPENAI_API_KEY' },
  gemini: { base: 'https://generativelanguage.googleapis.com/v1beta/openai', env: 'GEMINI_API_KEY' }
};

export default async function handler(req) {
  const url = new URL(req.url);
  const origin = req.headers.get('origin');
  if (origin) { try { if (new URL(origin).host !== url.host) return new Response('Forbidden', { status: 403 }); } catch { return new Response('Forbidden', { status: 403 }); } }
  const id = url.searchParams.get('id') || '';
  const up = UP[id];
  if (!up) return deny(404, 'Provider tidak dikenal: ' + id.slice(0, 20));
  const path = (url.searchParams.get('path') || '').replace(/^\/+/, '');
  if (path.includes('..')) return new Response('Bad path', { status: 400 });
  const q = new URLSearchParams(url.searchParams); q.delete('id'); q.delete('path');
  const target = up.base + '/' + path + (q.toString() ? '?' + q.toString() : '');

  const h = new Headers();
  const ct = req.headers.get('content-type'); if (ct) h.set('content-type', ct);
  h.set('accept', req.headers.get('accept') || '*/*');
  const incoming = req.headers.get('authorization') || '';
  const key = process.env[up.env];
  // "Bearer server" = pakai key milik server; selain itu (key buatan pengguna di Pengaturan) diteruskan apa adanya
  if (/^Bearer\s+server$/i.test(incoming) || !incoming) {
    if (!key) return new Response(JSON.stringify({ error: { message: 'API key ' + up.env + ' belum diisi di Vercel (Settings → Environment Variables).' } }), { status: 500, headers: { 'content-type': 'application/json' } });
    h.set('authorization', 'Bearer ' + key);
  } else h.set('authorization', incoming);
  if (id === 'openrouter') { h.set('http-referer', url.origin); h.set('x-title', 'Los Gk Bawel AI'); }

  const init = { method: req.method, headers: h, signal: req.signal };
  if (req.method !== 'GET' && req.method !== 'HEAD') init.body = await req.arrayBuffer();

  // Batas pemakaian hanya untuk key milik server (bukan key buatan pengguna)
  let extra = {};
  if (h.get('authorization') === 'Bearer ' + key && req.method === 'POST') {
    let kind = null, cost = 1;
    if (/(^|\/)chat\/completions$/.test(path)) kind = 'chat';
    else if (/(^|\/)images\/generations$/.test(path)) { kind = 'chat'; cost = 3; }
    else if (/(^|\/)audio\/transcriptions$/.test(path)) kind = 'voice';
    // terjemahan UI otomatis: bucket sendiri, hanya model kecil & ukuran dibatasi (bukan celah chat gratis)
    if (kind === 'chat' && req.headers.get('x-lgb-i18n') === '1') {
      let j = null; try { j = JSON.parse(new TextDecoder().decode(init.body)); } catch (e) { /* tolak di bawah */ }
      const okBody = j && j.model === 'llama-3.1-8b-instant' && !j.stream && (j.max_tokens || 0) <= 3500 && Array.isArray(j.messages) && j.messages.length <= 2 && JSON.stringify(j.messages).length < 24000;
      if (!okBody) return deny(400, 'Permintaan terjemahan tidak valid.', 'lgb_i18n_bad');
      kind = 'i18n';
    }
    if (kind) {
      // tamu tidak boleh mengirim foto (dicek di server, bukan hanya di tampilan)
      if (kind === 'chat' && init.body && init.body.byteLength > 0) {
        const txt = new TextDecoder().decode(init.body.byteLength > 4e6 ? init.body.slice(0, 4e6) : init.body);
        if (txt.includes('"image_url"') && !(await who(req))) return deny(423, 'Kirim foto hanya untuk akun yang sudah masuk. Masuk atau daftar gratis dulu.', 'lgb_guest_image');
      }
      const g = await gate(req, kind, cost);
      if (g.res) return g.res;
      extra = g.headers;
    }
  }
  if (id === 'gemini') {
    const inc = (h.get('authorization') || '').replace(/^Bearer\s+/i, '');
    if (req.method === 'POST' && /(^|\/)chat\/completions$/.test(path)) return geminiChat(init.body || new ArrayBuffer(0), inc, req.signal, extra);
    if (req.method === 'GET' && /^models\/?$/.test(path)) return geminiModels(inc, extra);
    return deny(404, 'Endpoint Gemini tidak didukung: ' + path.slice(0, 40));
  }
  let r;
  try { r = await fetch(target, init); } catch (e) { return new Response(JSON.stringify({ error: { message: 'Gagal menghubungi ' + id + ': ' + e.message } }), { status: 502, headers: { 'content-type': 'application/json' } }); }
  const out = new Headers();
  ['content-type', 'retry-after', 'x-ratelimit-remaining-requests', 'x-ratelimit-reset-requests'].forEach((k) => { const v = r.headers.get(k); if (v) out.set(k, v); });
  out.set('cache-control', 'no-store'); out.set('x-accel-buffering', 'no');
  Object.keys(extra).forEach((k) => out.set(k, extra[k]));
  return new Response(r.body, { status: r.status, headers: out });
}
