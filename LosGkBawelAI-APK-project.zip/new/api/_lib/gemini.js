// Adaptor: format OpenAI (chat/completions) <-> API Gemini asli (generateContent).
// Dipakai karena key Gemini baru berawalan "AQ." sering ditolak endpoint "OpenAI compatibility", tapi jalan di endpoint asli.
const BASE = 'https://generativelanguage.googleapis.com/v1beta';
const J = (o, status = 200, h = {}) => new Response(JSON.stringify(o), { status, headers: Object.assign({ 'content-type': 'application/json', 'cache-control': 'no-store' }, h) });
const err = (status, message, h) => J({ error: { message, code: 'gemini_' + status } }, status, h);

function toParts(c) {
  if (typeof c === 'string') return c ? [{ text: c }] : [];
  const out = [];
  (Array.isArray(c) ? c : []).forEach((p) => {
    if (!p) return;
    if (p.type === 'text' && p.text) out.push({ text: String(p.text) });
    else if (p.type === 'image_url') {
      const u = String((p.image_url && p.image_url.url) || p.image_url || '');
      const m = u.match(/^data:(image\/[a-z0-9.+-]+);base64,([A-Za-z0-9+/=]+)$/i);
      if (m) out.push({ inlineData: { mimeType: m[1], data: m[2] } });
    }
  });
  return out;
}
export function convert(body) {
  const sys = [], contents = [];
  (body.messages || []).forEach((m) => {
    const parts = toParts(m.content); if (!parts.length) return;
    if (m.role === 'system') { parts.forEach((p) => p.text && sys.push(p.text)); return; }
    const role = m.role === 'assistant' ? 'model' : 'user';
    const last = contents[contents.length - 1];
    if (last && last.role === role) last.parts.push(...parts); else contents.push({ role, parts });
  });
  if (!contents.length) contents.push({ role: 'user', parts: [{ text: '.' }] });
  if (contents[0].role !== 'user') contents.unshift({ role: 'user', parts: [{ text: '.' }] });
  const model = /^[A-Za-z0-9._-]{3,60}$/.test(String(body.model || '').replace(/^models\//, '')) ? String(body.model).replace(/^models\//, '') : 'gemini-3.8-flash';
  const gc = {};
  if (typeof body.temperature === 'number') gc.temperature = Math.max(0, Math.min(2, body.temperature));
  const mt = body.max_tokens || body.max_completion_tokens; if (mt) gc.maxOutputTokens = Math.min(+mt || 4096, 32000);
  if (body.response_format && body.response_format.type === 'json_object') gc.responseMimeType = 'application/json';
  if (/^gemini-2\.5-flash$/.test(model)) gc.thinkingConfig = { thinkingBudget: 1024 };
  const req = { contents, generationConfig: gc };
  if (sys.length) req.systemInstruction = { parts: [{ text: sys.join('\n\n').slice(0, 60000) }] };
  return { model, req };
}
const FIN = { STOP: 'stop', MAX_TOKENS: 'length', SAFETY: 'content_filter', RECITATION: 'content_filter' };
const textOf = (j) => ((j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || []).filter((p) => p.text && !p.thought).map((p) => p.text).join('');
const chunk = (o) => 'data: ' + JSON.stringify(o) + '\n\n';

const verOf = (id) => (String(id).match(/gemini-(\d+(?:\.\d+)?)-flash$/) || [0, 0])[1] * 1;
async function bestFlash(key, bad) {
  try {
    const r = await fetch(BASE + '/models?pageSize=100', { headers: { 'x-goog-api-key': key } });
    if (!r.ok) return '';
    const ids = ((await r.json()).models || []).filter((m) => (m.supportedGenerationMethods || []).includes('generateContent')).map((m) => String(m.name).replace(/^models\//, '')).filter((id) => /^gemini-\d+(\.\d+)?-flash$/.test(id) && id !== bad);
    return ids.sort((a, b) => verOf(b) - verOf(a))[0] || '';
  } catch { return ''; }
}
async function callGemini(model, req, stream, key, signal) {
  return fetch(BASE + '/models/' + model + (stream ? ':streamGenerateContent?alt=sse' : ':generateContent'), { method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': key }, body: JSON.stringify(req), signal });
}
export async function geminiChat(bodyBuf, key, signal, extra) {
  let body; try { body = JSON.parse(new TextDecoder().decode(bodyBuf)); } catch { return err(400, 'Body tidak valid.', extra); }
  const { model, req } = convert(body);
  const stream = !!body.stream;
  let r, used = model;
  try {
    r = await callGemini(model, req, stream, key, signal);
    // model sudah dipensiunkan / tidak tersedia: pilih sendiri flash terbaru yang tersedia lalu ulangi sekali
    if (r.status === 404) {
      const alt = await bestFlash(key, model);
      if (alt) { const rc = JSON.parse(JSON.stringify(req)); if (!/^gemini-2\.5-flash$/.test(alt)) delete rc.generationConfig.thinkingConfig; const r2 = await callGemini(alt, rc, stream, key, signal); if (r2.ok) { r = r2; used = alt; } }
    }
  } catch (e) { return err(502, 'Gagal menghubungi Gemini: ' + e.message, extra); }
  if (!r.ok) {
    let m = ''; try { const j = await r.json(); m = (j.error && j.error.message) || ''; } catch { /* abaikan */ }
    const hint = r.status === 404 ? ' (model "' + model + '" tidak ditemukan untuk key ini)' : r.status === 401 || r.status === 403 ? ' (cek GEMINI_API_KEY di Vercel)' : '';
    return err(r.status === 404 ? 502 : r.status, 'Gemini ' + r.status + ': ' + (m || r.statusText) + hint, extra);
  }
  if (!stream) {
    const j = await r.json(); const c = j.candidates && j.candidates[0];
    if (!c) return err(502, 'Gemini menolak permintaan: ' + ((j.promptFeedback && j.promptFeedback.blockReason) || 'tidak ada jawaban'), extra);
    return J({ id: 'gem', object: 'chat.completion', model: used, choices: [{ index: 0, message: { role: 'assistant', content: textOf(j) }, finish_reason: FIN[c.finishReason] || 'stop' }] }, 200, extra);
  }
  const dec = new TextDecoder(), enc = new TextEncoder(); let buf = '', done = false;
  const out = new ReadableStream({
    async start(ctl) {
      const rd = r.body.getReader();
      const push = (o) => ctl.enqueue(enc.encode(chunk(o)));
      try {
        for (;;) {
          const { value, done: d } = await rd.read(); if (d) break;
          buf += dec.decode(value, { stream: true });
          let i; while ((i = buf.indexOf('\n')) >= 0) {
            const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
            if (!line.startsWith('data:')) continue;
            let j; try { j = JSON.parse(line.slice(5)); } catch { continue; }
            const t = textOf(j), c = j.candidates && j.candidates[0];
            if (t) push({ choices: [{ index: 0, delta: { content: t } }] });
            if (c && c.finishReason) { push({ choices: [{ index: 0, delta: {}, finish_reason: FIN[c.finishReason] || 'stop' }] }); done = true; }
            if (!c && j.promptFeedback && j.promptFeedback.blockReason) push({ error: { message: 'Gemini menolak permintaan: ' + j.promptFeedback.blockReason } });
          }
        }
      } catch (e) { push({ error: { message: 'Aliran terputus: ' + e.message } }); }
      if (!done) push({ choices: [{ index: 0, delta: {}, finish_reason: 'stop' }] });
      ctl.enqueue(enc.encode('data: [DONE]\n\n')); ctl.close();
    }
  });
  return new Response(out, { status: 200, headers: Object.assign({ 'content-type': 'text/event-stream; charset=utf-8', 'cache-control': 'no-store', 'x-accel-buffering': 'no' }, extra) });
}
export async function geminiModels(key, extra) {
  try {
    const r = await fetch(BASE + '/models?pageSize=100', { headers: { 'x-goog-api-key': key } });
    if (!r.ok) return err(r.status, 'Gemini ' + r.status, extra);
    const j = await r.json();
    return J({ data: (j.models || []).filter((m) => (m.supportedGenerationMethods || []).includes('generateContent')).map((m) => ({ id: String(m.name).replace(/^models\//, '') })) }, 200, extra);
  } catch (e) { return err(502, e.message, extra); }
}
