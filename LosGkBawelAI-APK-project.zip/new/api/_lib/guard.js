// Verifikasi login + batas pemakaian harian (tamu lebih kecil dari anggota).
const SB_URL = process.env.SUPABASE_URL || 'https://xeeaonhrrmboiowpwxqp.supabase.co';
export const SB_URLX = SB_URL;
const SB_KEY = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_KEY || 'sb_publishable_h-mBhZM6j96qwSBzrHN4xQ_UlddLtnc';
export const SB_SECRET = () => process.env.SUPABASE_SECRET_KEY || '';
const num = (v, d) => { const n = parseInt(v, 10); return Number.isFinite(n) && n > 0 ? n : d; };
export const OWNER_NAME = 'Jeremy Ibnu Latif Putra Iman';
export const LIMITS = {
  i18n: { guest: 15, member: 80 },
  proxy: { guest: +process.env.GUEST_PROXY_LIMIT || 20, member: +process.env.MEMBER_PROXY_LIMIT || 300 },
  // batas per hari (zona WIB). Ubah lewat Environment Variables di Vercel.
  chat: { guest: num(process.env.GUEST_DAILY_LIMIT, 8), member: num(process.env.MEMBER_DAILY_LIMIT, 80) },
  voice: { guest: num(process.env.GUEST_VOICE_LIMIT, 6), member: num(process.env.MEMBER_VOICE_LIMIT, 60) },
  search: { guest: num(process.env.GUEST_SEARCH_LIMIT, 4), member: num(process.env.MEMBER_SEARCH_LIMIT, 40) }
};

const vcache = new Map();
export async function who(req) {
  const h = req.headers.get('x-lgb-auth') || '';
  const i = h.indexOf('.');
  if (i < 1) return null;
  const kind = h.slice(0, i), tok = h.slice(i + 1);
  if (!tok || tok.length > 4096) return null;
  const ck = kind + '.' + tok, hit = vcache.get(ck);
  if (hit && hit.exp > Date.now()) return hit.v;
  let id = null, email = '', discord = [], github = [], emailOk = false;
  try {
    if (kind === 'sb') {
      const r = await fetch(SB_URL + '/auth/v1/user', { headers: { apikey: SB_KEY, Authorization: 'Bearer ' + tok } });
      // email wajib sudah dikonfirmasi (lewat link di email) supaya email palsu tidak dihitung sebagai anggota
      if (r.ok) {
        const j = await r.json();
        const idn = Array.isArray(j && j.identities) ? j.identities : [];
        // identitas login sosial (tidak bisa dipalsukan): Discord User ID & username GitHub
        discord = idn.filter((x) => x.provider === 'discord').map((x) => String((x.identity_data && (x.identity_data.provider_id || x.identity_data.sub)) || x.id || '')).filter(Boolean);
        github = idn.filter((x) => x.provider === 'github').map((x) => String((x.identity_data && x.identity_data.user_name) || '').toLowerCase()).filter(Boolean);
        // email dianggap terverifikasi hanya bila identitas email-nya benar-benar sudah dikonfirmasi
        const eid = idn.filter((x) => x.provider === 'email');
        emailOk = !!(j.email_confirmed_at || j.confirmed_at) && (!eid.length || eid.some((x) => !x.identity_data || x.identity_data.email_verified === true || x.identity_data.email_verified === undefined && j.email_confirmed_at)) ;
        if (j && j.id && (j.email_confirmed_at || j.confirmed_at || discord.length || github.length)) { id = 'sb:' + j.id; email = String(j.email || '').toLowerCase(); }
      }
    } else if (kind === 'g') {
      const r = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', { headers: { Authorization: 'Bearer ' + tok } });
      if (r.ok) { const j = await r.json(); if (j && j.sub && j.email_verified !== false) { id = 'g:' + j.sub; email = String(j.email || '').toLowerCase(); } }
    }
  } catch (e) { id = null; }
  const v = id ? { id, email, discord, github, emailOk } : null;
  if (vcache.size > 500) vcache.clear();
  vcache.set(ck, { v, exp: Date.now() + (id ? 60000 : 15000) });
  return v;
}

const mem = new Map();
async function bump(key, cost) {
  const day = new Date(Date.now() + 7 * 3600e3).toISOString().slice(0, 10);
  const k = 'lgb:' + key + ':' + day;
  const SK = SB_SECRET();
  if (SK) {
    try {
      const i = key.indexOf(':'), kind = key.slice(0, i), subject = key.slice(i + 1);
      const r = await fetch(SB_URL + '/rest/v1/rpc/lgb_bump', { method: 'POST', headers: { apikey: SK, 'content-type': 'application/json' }, body: JSON.stringify({ p_day: day, p_subject: subject, p_kind: kind, p_cost: cost }), signal: AbortSignal.timeout(2500) });
      if (r.ok) { const n = await r.json(); if (typeof n === 'number') return n; }
    } catch (e) { /* jatuh ke cadangan */ }
  }
  const U = process.env.UPSTASH_REDIS_REST_URL, T = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (U && T) {
    try {
      const r = await fetch(U.replace(/\/$/, '') + '/pipeline', { method: 'POST', headers: { Authorization: 'Bearer ' + T }, body: JSON.stringify([['INCRBY', k, cost], ['EXPIRE', k, 172800]]) });
      const j = await r.json();
      if (j && j[0] && typeof j[0].result === 'number') return j[0].result;
    } catch (e) { /* jatuh ke memori */ }
  }
  if (mem.size > 5000) mem.clear();
  const used = (mem.get(k) || 0) + cost; mem.set(k, used); return used;
}

const ipOf = (req) => (req.headers.get('x-real-ip') || (req.headers.get('x-forwarded-for') || '').split(',')[0] || 'unknown').trim();

// Kembalikan { res } bila ditolak, atau { tier, used, limit } bila boleh lanjut.
export async function gate(req, bucket, cost = 1) {
  const u = await who(req);
  const tier = u ? 'member' : 'guest';
  const limit = LIMITS[bucket][tier];
  const used = await bump(bucket + ':' + (u ? u.id : 'ip:' + ipOf(req)), cost);
  if (used > limit) {
    const msg = tier === 'guest'
      ? 'Jatah harian mode tamu habis (' + limit + ' per hari). Masuk atau daftar gratis untuk jatah lebih besar.'
      : 'Jatah harian akunmu habis (' + limit + ' per hari). Coba lagi besok.';
    return { res: new Response(JSON.stringify({ error: { message: msg, code: 'lgb_daily', tier } }), { status: 423, headers: { 'content-type': 'application/json', 'x-lgb-tier': tier, 'x-lgb-used': String(limit), 'x-lgb-limit': String(limit) } }) };
  }
  return { tier, used, limit, headers: { 'x-lgb-tier': tier, 'x-lgb-used': String(used), 'x-lgb-limit': String(limit) } };
}
export const deny = (status, message, code) => new Response(JSON.stringify({ error: { message, code } }), { status, headers: { 'content-type': 'application/json' } });

// ---------- peran: owner (dari env) / admin (tabel lgb_roles) / user ----------
const envList = (n) => String(process.env[n] || '').toLowerCase().replace(/["'<>]/g, '').split(/[\s,;]+/).filter(Boolean);
export const isOwner = (me) => !!me && ((me.emailOk && me.email && envList('OWNER_EMAILS').concat(envList('OWNER_EMAIL')).includes(me.email)) || (me.discord || []).some((d) => envList('OWNER_DISCORD_IDS').includes(d)) || (me.github || []).some((x) => envList('OWNER_GITHUB').includes(x)));
let adminCache = { t: 0, rows: [] };
export async function adminRows() {
  const SK = SB_SECRET(); if (!SK) return [];
  if (Date.now() - adminCache.t < 30000) return adminCache.rows;
  try {
    const r = await fetch(SB_URL + '/rest/v1/lgb_roles?select=user_id,email,display_name,role', { headers: { apikey: SK }, signal: AbortSignal.timeout(4000) });
    if (r.ok) adminCache = { t: Date.now(), rows: await r.json() };
  } catch (e) { /* pakai cache lama */ }
  return adminCache.rows;
}
export const clearRoleCache = () => { adminCache.t = 0; };
export async function roleOf(me) {
  if (!me) return { role: 'user', name: '' };
  if (isOwner(me)) return { role: 'owner', name: OWNER_NAME };
  const uid = me.id.startsWith('sb:') ? me.id.slice(3) : '';
  const row = uid && (await adminRows()).find((x) => x.user_id === uid && x.role === 'admin');
  return row ? { role: 'admin', name: row.display_name || 'Admin' } : { role: 'user', name: '' };
}
