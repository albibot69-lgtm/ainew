// Peran pengguna yang sedang masuk (untuk lencana centang biru & info profil).
import { who, roleOf } from './_lib/guard.js';
export const config = { runtime: 'edge' };
export default async function handler(req) {
  const me = await who(req);
  const r = await roleOf(me);
  return new Response(JSON.stringify({ role: r.role, name: r.name, signedIn: !!me }), { headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });
}
