// Transkrip YouTube (best-effort, memakai caption publik). Bisa gagal jika video tanpa subtitle atau YouTube memblokir.
import { gate, deny } from './_lib/guard.js';
export const config = { runtime: 'edge' };
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36';
const ent = (s) => s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n));
export function videoId(u) {
  try {
    const x = new URL(u);
    if (!/^https?:$/.test(x.protocol)) return '';
    const h = x.hostname.replace(/^www\.|^m\./, '');
    let id = '';
    if (h === 'youtu.be') id = x.pathname.slice(1);
    else if (h === 'youtube.com') id = x.searchParams.get('v') || (x.pathname.match(/^\/(?:shorts|embed|live)\/([^/?]+)/) || [])[1] || '';
    return /^[A-Za-z0-9_-]{11}$/.test(id) ? id : '';
  } catch { return ''; }
}
export default async function handler(req) {
  const url = new URL(req.url);
  const origin = req.headers.get('origin');
  if (origin) { try { if (new URL(origin).host !== url.host) return deny(403, 'Forbidden'); } catch { return deny(403, 'Forbidden'); } }
  const id = videoId(url.searchParams.get('u') || '');
  if (!id) return deny(400, 'Link YouTube tidak valid.');
  const g = await gate(req, 'search', 1);
  if (g.res) return g.res;
  try {
    const r = await fetch('https://www.youtube.com/watch?v=' + id + '&hl=en', { headers: { 'user-agent': UA, 'accept-language': 'en' }, signal: AbortSignal.timeout(9000) });
    const html = await r.text();
    const title = ((html.match(/<title>([^<]*)<\/title>/) || [])[1] || '').replace(/ - YouTube$/, '');
    const m = html.match(/"captionTracks":(\[.*?\])/);
    if (!m) return deny(404, 'Video ini tidak punya subtitle yang bisa diambil.');
    const tracks = JSON.parse(m[1]);
    const t = tracks.find((x) => /^(id|en)/.test(x.languageCode || '')) || tracks[0];
    const base = String(t.baseUrl || '').replace(/\\u0026/g, '&');
    if (!/^https:\/\/www\.youtube\.com\/api\/timedtext/.test(base)) return deny(502, 'Format subtitle tidak dikenali.');
    const x = await (await fetch(base, { signal: AbortSignal.timeout(9000) })).text();
    const text = [...x.matchAll(/<text[^>]*>([\s\S]*?)<\/text>/g)].map((a) => ent(a[1].replace(/<[^>]+>/g, ''))).join(' ').replace(/\s+/g, ' ').trim().slice(0, 30000);
    if (!text) return deny(404, 'Subtitle kosong.');
    return new Response(JSON.stringify({ title, lang: t.languageCode, text }), { headers: Object.assign({ 'content-type': 'application/json', 'cache-control': 'no-store' }, g.headers) });
  } catch (e) { return deny(502, 'Gagal mengambil transkrip.'); }
}
