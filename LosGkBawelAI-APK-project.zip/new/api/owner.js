// API khusus pemilik. Hanya email di OWNER_EMAILS (sudah terverifikasi lewat login) yang boleh masuk.
// Password pengguna TIDAK bisa dilihat: Supabase hanya menyimpan hash satu arah. Yang tersedia: kirim email reset password.
import { who, deny, SB_URLX, SB_SECRET, roleOf, clearRoleCache, adminRows } from './_lib/guard.js';
export const config = { runtime: 'edge' };

const J = (o, st = 200) => new Response(JSON.stringify(o), { status: st, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });
const owners = () => String(process.env.OWNER_EMAILS || process.env.OWNER_EMAIL || '').toLowerCase().replace(/["'<>]/g, '').split(/[\s,;]+/).filter(Boolean);
const list2 = (n) => String(process.env[n] || '').toLowerCase().replace(/["'<>]/g, '').split(/[\s,;]+/).filter(Boolean);
const nf = (why, ids) => new Response(JSON.stringify({ error: 'Not found' }), { status: 404, headers: { 'content-type': 'application/json', 'x-lgb-why': why, 'x-lgb-ids': ids || '', 'cache-control': 'no-store' } });
const sb = (path, init = {}) => {
  const k = SB_SECRET();
  return fetch(SB_URLX + path, Object.assign({}, init, { headers: Object.assign({ apikey: k, 'content-type': 'application/json' }, init.headers || {}), signal: AbortSignal.timeout(9000) }));
};
const wib = (off = 0) => new Date(Date.now() + 7 * 3600e3 - off * 86400e3).toISOString().slice(0, 10);

async function allUsers() {
  const out = [];
  for (let p = 1; p <= 10; p++) {
    const r = await sb('/auth/v1/admin/users?page=' + p + '&per_page=200');
    if (!r.ok) throw new Error('admin users ' + r.status);
    const j = await r.json(); const a = j.users || [];
    out.push(...a); if (a.length < 200) break;
  }
  return out;
}

export default async function handler(req) {
  const url = new URL(req.url);
  const origin = req.headers.get('origin');
  if (origin) { try { if (new URL(origin).host !== url.host) return deny(403, 'Forbidden'); } catch { return deny(403, 'Forbidden'); } }
  const me = await who(req);
  const list = owners();
  // jawaban sengaja seragam supaya orang lain tidak tahu halaman ini ada
  if (!me) return nf('noauth');
  const rl = await roleOf(me);
  if (rl.role === 'user') {
    const any = list.length || list2('OWNER_DISCORD_IDS').length || list2('OWNER_GITHUB').length;
    return nf(any ? 'notowner' : 'noenv', [me.discord.length ? 'discord:' + me.discord.join('/') : '', me.github.length ? 'github:' + me.github.join('/') : ''].filter(Boolean).join(','));
  }
  if (!SB_SECRET()) return J({ error: 'SUPABASE_SECRET_KEY belum diisi di Vercel.' }, 500);
  const a = url.searchParams.get('a') || 'stats';
  // admin hanya boleh MELIHAT; semua perubahan khusus owner
  if (req.method === 'POST' && rl.role !== 'owner') return J({ error: 'Read-only: only the owner can change things.' }, 403);
  try {
    if (a === 'whoami') return J({ role: rl.role, name: rl.name, email: me.email || '' });
    if (a === 'roles') { const rows = await adminRows(); return J({ admins: rows }); }
    if (a === 'stats' || a === 'users') {
      const users = await allUsers();
      const since = wib(13);
      const r = await sb('/rest/v1/lgb_usage?select=day,subject,kind,n&day=gte.' + since + '&limit=50000');
      const rows = r.ok ? await r.json() : [];
      const today = wib(0);
      const byDay = {}; for (let i = 13; i >= 0; i--) byDay[wib(i)] = { chat: 0, voice: 0, search: 0, members: new Set(), guests: new Set() };
      const todayBy = {};
      rows.forEach((x) => {
        const d = byDay[x.day]; if (!d) return;
        d[x.kind] = (d[x.kind] || 0) + x.n;
        (x.subject.startsWith('ip:') ? d.guests : d.members).add(x.subject);
        if (x.day === today) { const t = (todayBy[x.subject] = todayBy[x.subject] || {}); t[x.kind] = x.n; }
      });
      const days = Object.keys(byDay).map((k) => ({ day: k, chat: byDay[k].chat, voice: byDay[k].voice, search: byDay[k].search, members: byDay[k].members.size, guests: byDay[k].guests.size }));
      if (a === 'stats') {
        const total7 = days.slice(-7).reduce((s, d) => s + d.chat, 0);
        const week = Date.now() - 7 * 86400e3;
        const top = {}; rows.forEach((x) => { if (x.kind === 'chat' && !x.subject.startsWith('ip:')) top[x.subject] = (top[x.subject] || 0) + x.n; });
        const mail = {}; users.forEach((u) => { mail['sb:' + u.id] = u.email; mail['g:' + u.id] = u.email; });
        const topUsers = Object.entries(top).sort((p, q) => q[1] - p[1]).slice(0, 8).map(([k, n]) => ({ who: mail[k] || k, n }));
        const prov = {}; users.forEach((u) => { const p = (u.app_metadata && u.app_metadata.provider) || 'email'; prov[p] = (prov[p] || 0) + 1; });
        return J({
          totalUsers: users.length, confirmed: users.filter((u) => u.email_confirmed_at).length,
          new7: users.filter((u) => Date.parse(u.created_at) > week).length,
          active7: users.filter((u) => u.last_sign_in_at && Date.parse(u.last_sign_in_at) > week).length,
          chat7: total7, today: days[days.length - 1], days, topUsers, providers: prov
        });
      }
      return J({
        users: users.map((u) => ({
          id: u.id, email: u.email, provider: (u.app_metadata && u.app_metadata.provider) || 'email', name: (u.user_metadata && (u.user_metadata.full_name || u.user_metadata.name)) || '',
          created: u.created_at, last: u.last_sign_in_at, confirmed: !!u.email_confirmed_at, banned: !!(u.banned_until && Date.parse(u.banned_until) > Date.now()),
          today: todayBy['sb:' + u.id] || todayBy['g:' + u.id] || {}
        })).sort((p, q) => Date.parse(q.created) - Date.parse(p.created))
      });
    }
    if (req.method === 'POST') {
      const b = await req.json().catch(() => ({}));
      if (a === 'ban' || a === 'unban') {
        if (!b.id || b.id === (me.id || '').slice(3) || owners().includes(String(b.email || '').toLowerCase())) return J({ error: 'Tidak bisa.' }, 400);
        const r = await sb('/auth/v1/admin/users/' + encodeURIComponent(b.id), { method: 'PUT', body: JSON.stringify({ ban_duration: a === 'ban' ? '876000h' : 'none' }) });
        return J({ ok: r.ok }, r.ok ? 200 : 502);
      }
      if (a === 'delete') {
        if (!b.id || owners().includes(String(b.email || '').toLowerCase())) return J({ error: 'Tidak bisa.' }, 400);
        const r = await sb('/auth/v1/admin/users/' + encodeURIComponent(b.id), { method: 'DELETE' });
        return J({ ok: r.ok }, r.ok ? 200 : 502);
      }
      if (a === 'reset') {
        const r = await fetch(SB_URLX + '/auth/v1/recover', { method: 'POST', headers: { apikey: process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_KEY || 'sb_publishable_h-mBhZM6j96qwSBzrHN4xQ_UlddLtnc', 'content-type': 'application/json' }, body: JSON.stringify({ email: b.email }) });
        return J({ ok: r.ok }, r.ok ? 200 : 502);
      }
      if (a === 'announce') {
        const t = String(b.title || '').slice(0, 120).trim(), body = String(b.body || '').slice(0, 600).trim();
        if (!t) return J({ error: 'Judul kosong.' }, 400);
        const r = await sb('/rest/v1/lgb_announce', { method: 'POST', headers: { Prefer: 'return=representation' }, body: JSON.stringify({ title: t, body }) });
        return J({ ok: r.ok }, r.ok ? 200 : 502);
      }
      if (a === 'unannounce') {
        const r = await sb('/rest/v1/lgb_announce?id=eq.' + encodeURIComponent(b.id), { method: 'PATCH', body: JSON.stringify({ active: false }) });
        return J({ ok: r.ok }, r.ok ? 200 : 502);
      }
      if (a === 'grant') {
      const em = String(b.email || '').trim().toLowerCase(), nm = String(b.name || '').replace(/[\r\n<>]/g, ' ').trim().slice(0, 60);
      if (!em || !nm) return J({ error: 'Email and name required.' }, 400);
      const u = (await allUsers()).find((x) => String(x.email || '').toLowerCase() === em);
      if (!u) return J({ error: 'No user with that email. They must sign up first.' }, 404);
      const r = await sb('/rest/v1/lgb_roles?on_conflict=user_id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates' }, body: JSON.stringify({ user_id: u.id, email: em, role: 'admin', display_name: nm }) });
      clearRoleCache(); return J({ ok: r.ok }, r.ok ? 200 : 502);
    }
      if (a === 'revoke') {
      const r = await sb('/rest/v1/lgb_roles?user_id=eq.' + encodeURIComponent(String(b.id || '')), { method: 'DELETE' });
      clearRoleCache(); return J({ ok: r.ok }, r.ok ? 200 : 502);
    }
    }
    if (a === 'announcements') { const r = await sb('/rest/v1/lgb_announce?select=*&order=id.desc&limit=30'); return J({ items: r.ok ? await r.json() : [] }); }
    return J({ error: 'Aksi tidak dikenal.' }, 400);
  } catch (e) { return J({ error: String((e && e.message) || e) }, 502); }
}
