// Panduan fitur (bahasa sederhana) & riwayat perubahan. Dipakai tombol "Fitur AI" dan "Yang baru" di popup.
window.LGB_FEATURES = [
  { g: 'Tanya & belajar', items: [
    ['message', 'Tanya apa saja', 'Ketik pertanyaan di kotak bawah, AI menjawab langsung. Jawabannya terus muncul walau popup kamu tutup.'],
    ['file-text', 'Baca halaman web', 'Nyalakan "Izinkan AI membaca halaman ini", lalu minta ringkasan atau tanya isinya. Bagian sumber di halaman ikut di-stabilo dan layar langsung scroll ke sana.'],
    ['graduation-cap', 'Jawab soal di halaman', 'Ada kuis pilihan ganda? Klik tombolnya, AI membaca semua soal lalu menjawab satu per satu.'],
    ['highlighter', 'Highlight teks → toolbar', 'Blok teks di halaman, muncul toolbar kecil: Jelaskan, Ringkas, Terjemahkan, dan lainnya. Klik area kosong untuk menutupnya.'],
    ['clapperboard', 'Ringkas YouTube & PDF', 'Di video YouTube atau PDF, AI bisa meringkas dan bikin poin penting atau soal latihan.']
  ] },
  { g: 'Bantu menulis & kerja', items: [
    ['sparkles', 'Smart Reply (Balas otomatis)', 'Di Gmail, WhatsApp Web, dan kolom komentar sosmed, klik kolom balasan lalu tekan Balas. AI baca obrolannya dan menulis draf. Kamu bisa edit dulu sebelum dikirim.'],
    ['bar-chart', 'Ekstrak data ke JSON / CSV', 'Minta AI mengambil daftar harga, tabel, atau kontak dari halaman, lalu unduh rapi sebagai JSON atau CSV.'],
    ['paperclip', 'Lampirkan file', 'Seret foto, PDF, atau file teks ke popup. Dokumen panjang? AI mengambil bagian yang paling nyambung dengan pertanyaanmu.'],
    ['globe', 'Cari di web dulu', 'Nyalakan tombol Web supaya AI mencari info terbaru di internet sebelum menjawab, lengkap dengan sumbernya.'],
    ['calculator', 'Buat gambar & hitung', 'Minta "buatkan gambar …" atau soal hitungan, AI mengerjakannya.']
  ] },
  { g: 'Ngobrol lebih enak', items: [
    ['mic', 'Bicara, bukan ngetik', 'Tahan Alt+V (atau tombol mikrofon), bicara, lepas. Pertanyaanmu langsung terkirim.'],
    ['pin', 'Side panel', 'Mau AI tetap terbuka walau kamu klik halaman? Buka sebagai side panel dari Ctrl+K atau centang di Tampilan & privasi cepat.'],
    ['history', 'Riwayat chat', 'Tombol jam di atas: buka lagi percakapan lama. Klik kanan untuk Pin, Ganti nama, atau Hapus.'],
    ['search', 'Ctrl+K (palette)', 'Kotak pencarian cepat untuk semua perintah dan riwayat. Ketik sebagian nama, tekan Enter.']
  ] },
  { g: 'Simpan & bagikan', items: [
    ['download', 'Ekspor', 'Tombol Ekspor di tiap jawaban: unduh .md, salin Markdown, kirim ke Google Docs atau Notion.'],
    ['cloud', 'Akun & sinkron', 'Masuk dengan Google, email, atau GitHub supaya riwayat dan memori ikut ke perangkat lain. API key tidak pernah dikirim.'],
    ['lightbulb', 'Memori & persona', 'Beri tahu AI preferensimu (mis. "panggil aku Bro") dan pilih gaya bicaranya di Pengaturan.']
  ] },
  { g: 'Untuk developer', items: [
    ['wrench', 'Error Explainer di DevTools', 'Buka DevTools (F12) → tab "Los Gk Bawel AI". Error merah dan request gagal muncul di sana, klik Explain & Fix untuk penjelasan dan solusinya.']
  ] },
  { g: 'Tampilan & performa', items: [
    ['palette', 'Tema & efek', 'Ganti warna, kaca, dan efek di Tampilan & privasi cepat atau halaman Pengaturan (ada beberapa latar animasi).'],
    ['zap', 'Mode anti lag', 'Popup terasa berat? Nyalakan untuk menghilangkan semua efek. Ada juga "Samarkan" supaya popup tampil sebagai "Catatan".']
  ] }
];

// Kategori: add = ditambah, fix = diperbaiki / ditingkatkan, change = diubah, remove = dihilangkan
window.LGB_CHANGELOG = [
  { v: '6.7.3', t: 'Lebih ringan', fix: ['Riwayat chat disimpan digabung (tidak menulis ulang seluruh riwayat tiap perubahan)', 'Render jawaban panjang saat streaming lebih hemat', 'Pesan lama di luar layar tidak ikut dihitung tampilannya'], add: ['Versi web (Vercel) dengan fitur chat, gambar, PDF, akun, ekspor yang sama'] },
  { v: '6.7.2', t: 'Ikon, bukan emoji', change: ['Semua emoji di popup, toolbar Smart Reply, panel DevTools, dan daftar fitur diganti ikon bergaya Lucide yang seragam dan ikut warna tema'] },
  { v: '6.7.1', t: 'Panduan', add: ['Tombol "Fitur AI": penjelasan semua fitur dengan bahasa sederhana', 'Tombol "Yang baru": riwayat perubahan (ditambah, diperbaiki, diubah, dihilangkan)', 'Dua tombol itu ada di layar awal, di Tampilan & privasi cepat, dan di Ctrl+K'], fix: [], change: [], remove: [] },
  { v: '6.7.0', t: 'Fitur besar', add: ['Smart Reply di Gmail, WhatsApp Web & sosmed', 'Ekstrak data → JSON / CSV', 'Side panel', 'Bicara → prompt (Alt+V)', 'Ekspor ke .md, Google Docs, Notion', 'Cari di web (tombol Web) & RAG untuk dokumen panjang', 'Tab Error Explainer di DevTools', 'Server akun bawaan'], fix: ['Hasil pencarian & dokumen panjang lebih nyambung dengan pertanyaan'], change: [], remove: [] },
  { v: '6.6.x', t: 'Akun', add: ['Login Google dengan pilih akun (disimpan di Drive-mu)', 'Login email + password, kode email, GitHub, Discord, Microsoft', 'Sinkron riwayat, memori, persona, perintah kustom'], fix: ['Warna teks tombol saat di-hover tetap terbaca'], change: ['Login Google tidak lagi lewat server, langsung ke Google'], remove: [] },
  { v: '6.5.x', t: 'Riwayat & performa', add: ['Riwayat chat dengan daftar animasi (AnimatedList)', 'Menu klik kanan: Buka, Pin, Ganti nama, Salin judul, Hapus'], fix: ['Popup jauh lebih ringan: border listrik 30 fps & turun resolusi otomatis di perangkat lambat', 'Jawaban panjang tidak lagi tersendat', 'PDF reader dimuat hanya saat dibutuhkan'], change: ['Target cursor sekarang mati secara bawaan'], remove: [] },
  { v: '6.4.0', t: 'Jawaban di latar belakang', add: ['AI tetap menjawab walau popup ditutup'], fix: [], change: [], remove: ['Pesan "Popup tertutup sebelum jawaban selesai"'] },
  { v: '6.3.x', t: 'Toolbar & mode senyap', add: ['Toolbar highlight efek kaca, teks putih lalu gradient saat di-hover', 'Mode anti lag & Samarkan nama/ikon', 'Latar animasi baru di Pengaturan: Ferrofluid, Topography, LaserFlow', 'Loader kisi saat AI berpikir'], fix: ['Klik area kosong menutup toolbar, menu & kartu jawaban', 'Toolbar bisa dipakai di dalam kolom isian'], change: ['Izin situs untuk toolbar kini tampil jujur di popup'], remove: [] },
  { v: '6.2.x', t: 'Tampilan baru', add: ['Bar prompt besar dengan border listrik', 'Tombol spekular dengan efek naik saat di-hover', 'Latar MetaBalls di Pengaturan', 'Layar awal dengan centang pegas & geser untuk mulai', 'Menu Pengaturan bercabang'], fix: ['Header & bar bawah tidak lagi bertabrakan di popup kecil'], change: ['Warna bawaan jadi hitam + tema gelap', 'Emoji di Pengaturan diganti ikon'], remove: [] }
];
