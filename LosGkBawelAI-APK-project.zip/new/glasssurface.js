// Port vanilla JS dari React Bits <GlassSurface /> (jalur SVG-filter untuk Chromium + cadangan "frosted").
// GlassSurface(el, opts) memasang kaca pembias di belakang elemen yang sudah ada tanpa mengubah isinya.
(function () {
'use strict';
let uid = 0;
const DEFAULTS = { borderWidth: 0.07, brightness: 50, opacity: 0.93, blur: 11, displace: 0, backgroundOpacity: 0, saturation: 1,
  distortionScale: -180, redOffset: 0, greenOffset: 10, blueOffset: 20, xChannel: 'R', yChannel: 'G', mixBlendMode: 'difference', refraction: true };
const NS = 'http://www.w3.org/2000/svg';

function supportsSVGFilters(id) {
  const ua = navigator.userAgent;
  if ((/Safari/.test(ua) && !/Chrome/.test(ua)) || /Firefox/.test(ua)) return false;
  const div = document.createElement('div');
  div.style.backdropFilter = 'url(#' + id + ')';
  return div.style.backdropFilter !== '';
}

function GlassSurface(el, opts) {
  const o = Object.assign({}, DEFAULTS, opts || {});
  const id = 'glass-filter-' + (++uid);
  const redGrad = 'red-grad-' + uid, blueGrad = 'blue-grad-' + uid, soft = 'soft-' + uid;
  const supported = o.refraction && supportsSVGFilters(id);
  el.classList.add('gs', supported ? 'gs--svg' : 'gs--fallback');
  if (getComputedStyle(el).position === 'static') el.style.position = 'relative';
  el.style.setProperty('--glass-frost', o.backgroundOpacity);
  el.style.setProperty('--glass-saturation', o.saturation);
  if (!supported) return { ok: false, update() {}, destroy() { el.classList.remove('gs', 'gs--fallback'); } };
  el.style.setProperty('--filter-id', 'url(#' + id + ')');

  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('class', 'gs__filter');
  svg.setAttribute('aria-hidden', 'true');
  svg.innerHTML =
    '<defs><filter id="' + id + '" color-interpolation-filters="sRGB" x="0%" y="0%" width="100%" height="100%">' +
    '<feImage x="0" y="0" width="100%" height="100%" preserveAspectRatio="none" result="map"/>' +
    '<feDisplacementMap in="SourceGraphic" in2="map" result="dispRed"/>' +
    '<feColorMatrix in="dispRed" type="matrix" values="1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0" result="red"/>' +
    '<feDisplacementMap in="SourceGraphic" in2="map" result="dispGreen"/>' +
    '<feColorMatrix in="dispGreen" type="matrix" values="0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 1 0" result="green"/>' +
    '<feDisplacementMap in="SourceGraphic" in2="map" result="dispBlue"/>' +
    '<feColorMatrix in="dispBlue" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 1 0" result="blue"/>' +
    '<feBlend in="red" in2="green" mode="screen" result="rg"/>' +
    '<feBlend in="rg" in2="blue" mode="screen" result="output"/>' +
    '<feGaussianBlur in="output" stdDeviation="0.7"/></filter></defs>';
  el.insertBefore(svg, el.firstChild);
  const feImage = svg.querySelector('feImage');
  const disp = svg.querySelectorAll('feDisplacementMap');
  const gauss = svg.querySelector('feGaussianBlur');

  function build() {
    const r = el.getBoundingClientRect();
    const w = r.width || 400, h = r.height || 200;
    const radius = parseFloat(getComputedStyle(el).borderTopLeftRadius) || 0;
    const edge = Math.min(w, h) * (o.borderWidth * 0.5);
    const s =
      '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" xmlns="http://www.w3.org/2000/svg"><defs>' +
      '<linearGradient id="' + redGrad + '" x1="100%" y1="0%" x2="0%" y2="0%"><stop offset="0%" stop-color="#0000"/><stop offset="100%" stop-color="red"/></linearGradient>' +
      '<linearGradient id="' + blueGrad + '" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" stop-color="#0000"/><stop offset="100%" stop-color="blue"/></linearGradient>' +
      '<filter id="' + soft + '" filterUnits="userSpaceOnUse" x="0" y="0" width="' + w + '" height="' + h + '" color-interpolation-filters="sRGB"><feGaussianBlur stdDeviation="' + o.blur + '"/></filter></defs>' +
      '<rect x="0" y="0" width="' + w + '" height="' + h + '" fill="black"></rect>' +
      '<rect x="0" y="0" width="' + w + '" height="' + h + '" rx="' + radius + '" fill="url(#' + redGrad + ')"/>' +
      '<rect x="0" y="0" width="' + w + '" height="' + h + '" rx="' + radius + '" fill="url(#' + blueGrad + ')" style="mix-blend-mode: ' + o.mixBlendMode + '"/>' +
      '<rect x="' + edge + '" y="' + edge + '" width="' + (w - edge * 2) + '" height="' + (h - edge * 2) + '" rx="' + radius + '" fill="hsl(0 0% ' + o.brightness + '% / ' + o.opacity + ')" filter="url(#' + soft + ')"/></svg>';
    feImage.setAttribute('href', 'data:image/svg+xml,' + encodeURIComponent(s));
    [o.redOffset, o.greenOffset, o.blueOffset].forEach((off, i) => {
      disp[i].setAttribute('scale', String(o.distortionScale + off));
      disp[i].setAttribute('xChannelSelector', o.xChannel);
      disp[i].setAttribute('yChannelSelector', o.yChannel);
    });
    gauss.setAttribute('stdDeviation', String(o.displace));
  }
  let t = 0;
  const ro = new ResizeObserver(() => { clearTimeout(t); t = setTimeout(build, 60); });
  ro.observe(el);
  build();
  return {
    ok: true,
    update(n) { Object.assign(o, n || {}); el.style.setProperty('--glass-frost', o.backgroundOpacity); build(); },
    destroy() { ro.disconnect(); svg.remove(); el.classList.remove('gs', 'gs--svg'); el.style.removeProperty('--filter-id'); }
  };
}
window.GlassSurface = GlassSurface;
})();
