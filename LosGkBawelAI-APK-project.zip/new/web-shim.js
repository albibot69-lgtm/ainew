// Pengganti API extension Chrome supaya kode popup yang sama bisa jalan sebagai website biasa.
(function () {
  if (window.chrome && chrome.runtime && chrome.runtime.id) return; // sedang jalan sebagai extension
  window.LGB_WEB = true;
  window.LGB_REDIRECT = location.origin + '/oauth.html';
  document.documentElement.classList.add('web');
  try { if (!(navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia)) document.documentElement.classList.add('no-capture'); } catch (e) { /* abaikan */ }

  const clone = (v) => { try { return v === undefined ? v : structuredClone(v); } catch (e) { return JSON.parse(JSON.stringify(v)); } };
  const ev = () => { const L = []; return { addListener: (f) => L.push(f), removeListener: (f) => { const i = L.indexOf(f); if (i >= 0) L.splice(i, 1); }, hasListener: (f) => L.includes(f), _L: L }; };

  // ---------- storage (IndexedDB + cache memori) ----------
  let mem = {};
  const openDB = () => new Promise((res) => {
    try { const r = indexedDB.open('lgb-web', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => { window.LGB_DBERR = String(r.error); res(null); }; r.onblocked = () => { window.LGB_DBERR = 'blocked'; res(null); }; } catch (e) { res(null); }
  });
  const loaded = (async () => {
    const db = await openDB(); if (!db) return null;
    await new Promise((res) => {
      try {
        const rq = db.transaction('kv').objectStore('kv').openCursor();
        rq.onsuccess = () => { const c = rq.result; if (c) { mem[c.key] = c.value; c.continue(); } else res(); };
        rq.onerror = () => res();
      } catch (e) { res(); }
    });
    return db;
  })();
  let dirty = new Map(), flushT = 0;
  const scheduleFlush = () => { if (!flushT) flushT = setTimeout(flush, 120); };
  async function flush() {
    flushT = 0; const batch = dirty; dirty = new Map();
    const db = await loaded; if (!db || !batch.size) return;
    try {
      const os = db.transaction('kv', 'readwrite').objectStore('kv');
      batch.forEach((v, k) => { if (v === undefined) os.delete(k); else os.put(v, k); });
      os.transaction.onabort = os.transaction.onerror = () => { window.LGB_DBERR = 'tx:' + (os.transaction.error || ''); };
    } catch (e) { window.LGB_DBERR = 'flush:' + e; }
  }
  window.addEventListener('pagehide', flush);
  document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); });
  const changed = ev();
  const emit = (ch) => { if (Object.keys(ch).length) queueMicrotask(() => changed._L.slice().forEach((f) => { try { f(ch, 'local'); } catch (e) { console.error(e); } })); };
  const pick = (keys) => {
    if (keys == null) return clone(mem);
    if (typeof keys === 'string') keys = [keys];
    const o = {};
    if (Array.isArray(keys)) { keys.forEach((k) => { if (k in mem) o[k] = clone(mem[k]); }); return o; }
    Object.keys(keys).forEach((k) => { o[k] = k in mem ? clone(mem[k]) : keys[k]; });
    return o;
  };
  const wrapCb = (p, cb) => { if (typeof cb === 'function') { p.then((r) => cb(r)); return undefined; } return p; };
  const local = {
    get: (keys, cb) => wrapCb(loaded.then(() => pick(typeof keys === 'function' ? null : keys)), typeof keys === 'function' ? keys : cb),
    set: (items, cb) => wrapCb(loaded.then(() => {
      const ch = {};
      Object.keys(items).forEach((k) => { const nv = clone(items[k]); ch[k] = { oldValue: mem[k], newValue: nv }; mem[k] = nv; dirty.set(k, nv); });
      scheduleFlush(); emit(ch);
    }), cb),
    remove: (keys, cb) => wrapCb(loaded.then(() => {
      const ch = {};
      [].concat(keys).forEach((k) => { if (k in mem) { ch[k] = { oldValue: mem[k] }; delete mem[k]; dirty.set(k, undefined); } });
      scheduleFlush(); emit(ch);
    }), cb),
    clear: (cb) => wrapCb(loaded.then(() => { const ch = {}; Object.keys(mem).forEach((k) => { ch[k] = { oldValue: mem[k] }; dirty.set(k, undefined); }); mem = {}; scheduleFlush(); emit(ch); }), cb)
  };

  // ---------- jembatan AI (pengganti background.js) ----------
  let curCtrl = null;
  function askPort() {
    const L = [], D = []; let ctrl = null, closed = false;
    const emitMsg = (o) => { if (!closed) L.slice().forEach((f) => { try { f(o); } catch (e) { console.error(e); } }); };
    async function run(m) {
      ctrl = new AbortController(); curCtrl = ctrl;
      try {
        const r = await askAI(m.messages, {
          signal: ctrl.signal, system: m.system, deep: !!m.deep, maxTokens: m.maxTokens || 2048,
          onProvider: (p) => emitMsg({ type: 'provider', name: p.name }),
          onDelta: (t) => emitMsg({ type: 'delta', text: t }),
          onSwitch: (f, t, why) => emitMsg({ type: 'switch', from: f.name, to: t.name, why: why && why.message }),
          onShrink: (p) => emitMsg({ type: 'shrink', name: p.name }),
          onActiveChanged: () => emitMsg({ type: 'active' })
        });
        emitMsg({ type: 'done', text: r.text, truncated: !!r.truncated });
      } catch (e) {
        if (e && e.name === 'AbortError') emitMsg({ type: 'stopped' }); else emitMsg({ type: 'error', message: (e && e.message) || String(e) });
      } finally { if (curCtrl === ctrl) curCtrl = null; }
    }
    return {
      name: 'ask',
      onMessage: { addListener: (f) => L.push(f) }, onDisconnect: { addListener: (f) => D.push(f) },
      postMessage(m) { if (m.cmd === 'stop') { if (ctrl) ctrl.abort(); } else if (m.cmd === 'ask') run(m); },
      disconnect() { closed = true; if (ctrl) ctrl.abort(); }
    };
  }

  // ---------- login lewat popup / iframe (pengganti identity.launchWebAuthFlow) ----------
  function launchWebAuthFlow({ url, interactive }) {
    return new Promise((resolve, reject) => {
      let w = null, fr = null, done = false, poll = 0, to = 0;
      const end = (fn, v) => { if (done) return; done = true; window.removeEventListener('message', on); clearInterval(poll); clearTimeout(to); try { w && w.close(); } catch (e) { /* abaikan */ } if (fr) fr.remove(); fn(v); };
      const on = (e) => { if (e.origin === location.origin && e.data && e.data.lgbAuth) end(resolve, e.data.lgbAuth); };
      window.addEventListener('message', on);
      if (interactive) {
        const W = 500, H = 650, l = Math.max(0, (screen.width - W) / 2), t = Math.max(0, (screen.height - H) / 2);
        w = window.open(url, 'lgbauth', 'width=' + W + ',height=' + H + ',left=' + l + ',top=' + t);
        if (!w) return end(reject, new Error('Popup diblokir. Izinkan popup untuk situs ini.'));
        poll = setInterval(() => { if (w.closed) end(reject, new Error('Dibatalkan')); }, 500);
      } else {
        fr = document.createElement('iframe'); fr.style.display = 'none'; fr.src = url; document.body.appendChild(fr);
        to = setTimeout(() => end(reject, new Error('Timeout')), 9000);
      }
    });
  }

  // ---------- tangkap layar via getDisplayMedia ----------
  async function capture() {
    const st = await navigator.mediaDevices.getDisplayMedia({ video: true, preferCurrentTab: true });
    try {
      const v = document.createElement('video'); v.srcObject = st; v.muted = true; await v.play(); await new Promise((r) => setTimeout(r, 350));
      const c = document.createElement('canvas'); c.width = v.videoWidth; c.height = v.videoHeight; c.getContext('2d').drawImage(v, 0, 0);
      return c.toDataURL('image/png');
    } finally { st.getTracks().forEach((t) => t.stop()); }
  }

  const noPage = () => Promise.reject(new Error('Fitur ini hanya ada di extension Chrome (butuh akses ke tab lain).'));
  window.chrome = {
    storage: { local, onChanged: changed },
    runtime: {
      id: 'web', lastError: undefined,
      getManifest: () => ({ version: (window.LGB_WEB_VERSION || ''), oauth2: { client_id: (window.LGB_GOOGLE_CLIENT_ID || '') } }),
      getURL: (p) => p, connect: () => askPort(),
      sendMessage: (m) => { if (m && m.cmd === 'bgStop' && curCtrl) curCtrl.abort(); return Promise.resolve(null); },
      onMessage: ev(), onConnect: ev(), onInstalled: ev(), onStartup: ev(),
      openOptionsPage: () => { location.href = 'options.html'; return Promise.resolve(); }
    },
    permissions: { contains: () => Promise.resolve(true), request: () => Promise.resolve(true), remove: () => Promise.resolve(true), onAdded: ev(), onRemoved: ev() },
    tabs: { query: () => Promise.resolve([]), create: (o) => { window.open(o.url, '_blank', 'noopener'); return Promise.resolve({}); }, captureVisibleTab: capture, sendMessage: noPage },
    windows: { getCurrent: () => Promise.resolve({ id: 1 }) },
    scripting: { executeScript: noPage },
    sidePanel: { open: noPage },
    commands: { getAll: () => Promise.resolve([]) },
    action: { setBadgeText: () => Promise.resolve(), setTitle: () => Promise.resolve(), setBadgeBackgroundColor: () => Promise.resolve() },
    identity: { launchWebAuthFlow }
  };

  // ---------- fetch: lewat /api/proxy kalau situs tujuan tidak mengizinkan CORS ----------
  const _fetch = window.fetch.bind(window);
  const NEED_PROXY = /(^|\.)(duckduckgo\.com|api\.notion\.com|ollama\.com)$/i;
  const PRIVATE = /^(localhost|127\.|10\.|192\.168\.|0\.|169\.254\.|\[)/i;
  const viaProxy = (u, init) => _fetch('/api/proxy?u=' + encodeURIComponent(u.href), init);
  // Panggilan ke server sendiri: sisipkan token login (kalau ada) & umumkan sisa kuota / penolakan limit
  async function apiFetch(input, init) {
    init = Object.assign({}, init || {});
    try {
      const t = window.lgbAuthHeader ? await window.lgbAuthHeader() : '';
      if (t) { const h = new Headers(init.headers || {}); h.set('x-lgb-auth', t); init.headers = h; }
    } catch (e) { /* abaikan */ }
    const r = await _fetch(input, init);
    try {
      const tier = r.headers.get('x-lgb-tier');
      if (tier) window.dispatchEvent(new CustomEvent('lgb-quota', { detail: { tier, used: +r.headers.get('x-lgb-used') || 0, limit: +r.headers.get('x-lgb-limit') || 0 } }));
      if (r.status === 423) r.clone().json().then((j) => window.dispatchEvent(new CustomEvent('lgb-denied', { detail: j && (j.error || j) }))).catch(() => {});
    } catch (e) { /* abaikan */ }
    return r;
  }
  window.fetch = async function (input, init) {
    let u;
    try { u = new URL(typeof input === 'string' ? input : input.url, location.href); } catch (e) { return _fetch(input, init); }
    if (u.origin === location.origin && /^\/api\/(p\/|search|owner|me)/.test(u.pathname) && typeof input === 'string') return apiFetch(input, init);
    if (u.origin === location.origin || !/^https?:$/.test(u.protocol) || typeof input !== 'string') return _fetch(input, init);
    if (NEED_PROXY.test(u.hostname)) return viaProxy(u, init);
    try { return await _fetch(input, init); }
    catch (e) {
      if (!(e instanceof TypeError) || (init && init.signal && init.signal.aborted) || PRIVATE.test(u.hostname)) throw e;
      return viaProxy(u, init);
    }
  };
})();
