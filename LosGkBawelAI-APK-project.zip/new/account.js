// Akun & sinkronisasi (Supabase): login email+password, kode email (OTP), Google, GitHub.
// Yang disinkronkan: riwayat chat, catatan memori, persona, perintah kustom. API key TIDAK pernah dikirim.
(function () {
  const K = { url: 'acctUrl', key: 'acctKey', sess: 'acctSession', del: 'chatDel', last: 'acctLastSync' };
  const get = (o) => chrome.storage.local.get(o);
  const set = (o) => chrome.storage.local.set(o);
  const clean = (u) => String(u || '').trim().replace(/\/+$/, '');
  const msgOf = (j, st) => (j && (j.msg || j.error_description || j.message || j.error)) || ('Kesalahan ' + st);
  const friendly = (m) => {
    m = String(m || '');
    if (/invalid login credentials/i.test(m)) return 'Email atau password salah.';
    if (/already registered|already been registered/i.test(m)) return 'Email sudah terdaftar. Silakan masuk.';
    if (/email not confirmed/i.test(m)) return 'Email belum dikonfirmasi. Cek kotak masukmu.';
    if (/password should be at least/i.test(m)) return 'Password minimal 6 karakter.';
    if (/rate limit|too many/i.test(m)) return 'Terlalu sering mencoba. Tunggu sebentar.';
    if (/token has expired|invalid/i.test(m) && /otp|token/i.test(m)) return 'Kode salah atau kedaluwarsa.';
    if (/failed to fetch|networkerror/i.test(m)) return 'Tidak bisa terhubung ke server akun. Cek URL & koneksi.';
    return m;
  };

  // Server akun bawaan (kunci "publishable" memang publik; keamanan data dijaga RLS di tabel)
  const DEFAULT_SB = { url: 'https://xeeaonhrrmboiowpwxqp.supabase.co', key: 'sb_publishable_h-mBhZM6j96qwSBzrHN4xQ_UlddLtnc' };
  async function cfg() {
    const s = await get({ [K.url]: '', [K.key]: '' });
    return { url: clean(s[K.url]) || DEFAULT_SB.url, key: String(s[K.key] || '').trim() || DEFAULT_SB.key };
  }
  async function raw(path, { method = 'GET', body, token, headers } = {}) {
    const c = await cfg();
    if (!c.url || !c.key) throw new Error('Isi URL & anon key server akun dulu.');
    let res;
    try {
      res = await fetch(c.url + path, {
        method, headers: Object.assign({ apikey: c.key, 'Content-Type': 'application/json' }, token ? { Authorization: 'Bearer ' + token } : {}, headers || {}),
        body: body === undefined ? undefined : JSON.stringify(body)
      });
    } catch (e) { throw new Error(friendly(e.message)); }
    let j = null; const t = await res.text(); try { j = t ? JSON.parse(t) : null; } catch (e) { j = { message: t.slice(0, 200) }; }
    if (!res.ok) throw new Error(friendly(msgOf(j, res.status)));
    return j;
  }
  async function saveSession(j) {
    if (!j || !j.access_token) throw new Error('Respons login tidak lengkap.');
    const s = { access_token: j.access_token, refresh_token: j.refresh_token, expires_at: j.expires_at || Math.floor(Date.now() / 1000) + (j.expires_in || 3600), user: { id: j.user && j.user.id, email: j.user && j.user.email } };
    await set({ [K.sess]: s });
    return s;
  }
  async function session() {
    const s = (await get({ [K.sess]: null }))[K.sess];
    if (!s) return null;
    if (s.kind === 'google') return s; // token diperbarui saat dipakai (gtoken)
    if (s.expires_at - 60 > Date.now() / 1000) return s;
    try { return await saveSession(Object.assign({}, await raw('/auth/v1/token?grant_type=refresh_token', { method: 'POST', body: { refresh_token: s.refresh_token } }))); }
    catch (e) { await set({ [K.sess]: null }); return null; }
  }


  // ---- Google langsung (tanpa server): pilih akun Google, simpan di Drive (folder app tersembunyi) ----
  const G = { cid: 'acctGoogleCid' };
  const okCid = (v) => /^[0-9]+-[a-z0-9]+\.apps\.googleusercontent\.com$/i.test(String(v || '').trim());
  // Client ID bawaan: manifest.json -> oauth2.client_id (atau DEFAULT_GOOGLE_CLIENT_ID di defaults.js)
  const GOOGLE_CID_DEFAULT = (() => {
    try { const v = chrome.runtime.getManifest().oauth2.client_id; if (okCid(v)) return v.trim(); } catch (e) { /* abaikan */ }
    return typeof DEFAULT_GOOGLE_CLIENT_ID === 'string' && okCid(DEFAULT_GOOGLE_CLIENT_ID) ? DEFAULT_GOOGLE_CLIENT_ID : '';
  })();
  const redirectUrl = () => (window.LGB_REDIRECT || ('https://' + chrome.runtime.id + '.chromiumapp.org/'));
  async function googleCid() { const s = await get({ [G.cid]: '' }); return String(s[G.cid] || '').trim() || GOOGLE_CID_DEFAULT; }
  async function googleAuth(interactive, hint) {
    const cid = await googleCid();
    if (!cid) throw new Error('NEED_CID');
    if (interactive) {
      const ok = await chrome.permissions.request({ permissions: ['identity'] }).catch(() => false);
      if (!ok) throw new Error('Izin "identity" diperlukan untuk login Google.');
    }
    const u = 'https://accounts.google.com/o/oauth2/v2/auth?' + new URLSearchParams({
      client_id: cid, response_type: 'token', redirect_uri: redirectUrl(),
      scope: 'openid email https://www.googleapis.com/auth/drive.appdata https://www.googleapis.com/auth/drive.file',
      prompt: interactive ? 'select_account' : 'none', include_granted_scopes: 'true', login_hint: hint || ''
    }).toString();
    let back;
    try { back = await chrome.identity.launchWebAuthFlow({ url: u, interactive }); }
    catch (e) { throw new Error(interactive ? 'Login Google dibatalkan atau ditolak. Cek Client ID & Authorized redirect URI (' + redirectUrl() + ').' : 'SESSION_EXPIRED'); }
    const q = new URLSearchParams((back || '').split('#')[1] || '');
    if (q.get('error')) throw new Error(interactive ? 'Google: ' + q.get('error') : 'SESSION_EXPIRED');
    const at = q.get('access_token'); if (!at) throw new Error('Google tidak mengembalikan token.');
    return { at, exp: Math.floor(Date.now() / 1000) + (+q.get('expires_in') || 3600) };
  }
  async function googleSignIn() {
    const { at, exp } = await googleAuth(true);
    const r = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', { headers: { Authorization: 'Bearer ' + at } });
    if (!r.ok) throw new Error('Gagal membaca profil Google.');
    const u = await r.json();
    await set({ [K.sess]: { kind: 'google', access_token: at, expires_at: exp, user: { id: u.sub, email: u.email, name: u.name || '', picture: u.picture || '' } } });
  }
  async function gtoken(s) {
    if (s.expires_at - 60 > Date.now() / 1000) return s.access_token;
    try {
      const { at, exp } = await googleAuth(false, s.user.email);
      await set({ [K.sess]: Object.assign({}, s, { access_token: at, expires_at: exp }) });
      return at;
    } catch (e) { await set({ [K.sess]: null }); throw new Error('Sesi Google habis. Masuk lagi.'); }
  }
  const DRIVE = 'https://www.googleapis.com/';
  async function gfetch(url, token, opt) {
    const r = await fetch(url, Object.assign({}, opt, { headers: Object.assign({ Authorization: 'Bearer ' + token }, (opt && opt.headers) || {}) }));
    if (!r.ok) { let m = ''; try { m = (await r.json()).error.message; } catch (e) { /* abaikan */ } throw new Error(r.status === 403 ? 'Google Drive API belum diaktifkan / izin ditolak. ' + m : 'Drive ' + r.status + ' ' + m); }
    return r;
  }
  async function driveFind(token) {
    const r = await gfetch(DRIVE + "drive/v3/files?spaces=appDataFolder&fields=files(id)&q=" + encodeURIComponent("name='lgb-sync.json'"), token);
    const j = await r.json(); return j.files && j.files[0] && j.files[0].id;
  }
  async function drivePull(token) {
    const id = await driveFind(token); if (!id) return { id: null, data: {} };
    const r = await gfetch(DRIVE + 'drive/v3/files/' + id + '?alt=media', token);
    let d = {}; try { d = await r.json(); } catch (e) { /* kosong */ }
    return { id, data: d };
  }
  async function drivePush(token, id, data) {
    if (id) { await gfetch(DRIVE + 'upload/drive/v3/files/' + id + '?uploadType=media', token, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }); return; }
    const b = '-----lgb' + Date.now();
    const body = '--' + b + '\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n' + JSON.stringify({ name: 'lgb-sync.json', parents: ['appDataFolder'] }) +
      '\r\n--' + b + '\r\nContent-Type: application/json\r\n\r\n' + JSON.stringify(data) + '\r\n--' + b + '--';
    await gfetch(DRIVE + 'upload/drive/v3/files?uploadType=multipart', token, { method: 'POST', headers: { 'Content-Type': 'multipart/related; boundary=' + b }, body });
  }

  const Acct = {
    cfg, session, friendly, googleCid, redirectUrl,
    async setGoogleCid(v) { await set({ [G.cid]: String(v || '').trim() }); },
    googleSignIn,
    async googleToken() { const s = await session(); if (!s || s.kind !== 'google') throw new Error('Masuk dengan Google dulu (Riwayat → Akun).'); return gtoken(s); },
    async googleDocCreate(title, html) {
      const tk = await Acct.googleToken();
      const b = '-----lgbdoc' + Date.now();
      const body = '--' + b + '\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n' + JSON.stringify({ name: title, mimeType: 'application/vnd.google-apps.document' }) + '\r\n--' + b + '\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n' + html + '\r\n--' + b + '--';
      const r = await fetch(DRIVE + 'upload/drive/v3/files?uploadType=multipart&fields=id,webViewLink', { method: 'POST', headers: { Authorization: 'Bearer ' + tk, 'Content-Type': 'multipart/related; boundary=' + b }, body });
      if (!r.ok) throw new Error(r.status === 403 || r.status === 401 ? 'Izin Google Docs belum diberikan. Keluar lalu masuk Google lagi (akan diminta izin baru).' : 'Google Docs ' + r.status);
      return r.json();
    },
    async googleReady() { return !!(await googleCid()); },
    async configured() { const c = await cfg(); return !!(c.url && c.key); },
    async saveConfig(url, key) { await set({ [K.url]: clean(url), [K.key]: String(key || '').trim() }); },
    async user() { const s = await session(); return s ? s.user : null; },
    async signUp(email, password) {
      const j = await raw('/auth/v1/signup', { method: 'POST', body: { email, password } });
      if (j && j.access_token) { await saveSession(j); return { signedIn: true }; }
      return { signedIn: false, needConfirm: true };
    },
    async signIn(email, password) { await saveSession(await raw('/auth/v1/token?grant_type=password', { method: 'POST', body: { email, password } })); },
    async sendCode(email) { await raw('/auth/v1/otp', { method: 'POST', body: { email, create_user: true } }); },
    async verifyCode(email, token) { await saveSession(await raw('/auth/v1/verify', { method: 'POST', body: { type: 'email', email, token: String(token).trim() } })); },
    async oauth(provider) {
      const c = await cfg();
      if (!c.url || !c.key) throw new Error('Isi URL & anon key server akun dulu.');
      const granted = await chrome.permissions.request({ permissions: ['identity'] }).catch(() => false);
      if (!granted) throw new Error('Izin "identity" diperlukan untuk login ' + provider + '.');
      const redirect = (window.LGB_REDIRECT || ('https://' + chrome.runtime.id + '.chromiumapp.org/'));
      const url = c.url + '/auth/v1/authorize?provider=' + encodeURIComponent(provider) + '&redirect_to=' + encodeURIComponent(redirect);
      let back;
      try { back = await chrome.identity.launchWebAuthFlow({ url, interactive: true }); }
      catch (e) { throw new Error('Login dibatalkan atau ditolak. Pastikan provider ' + provider + ' aktif di server akun & redirect URL ' + redirect + ' sudah didaftarkan.'); }
      const q = new URLSearchParams((back || '').split('#')[1] || (back || '').split('?')[1] || '');
      if (q.get('error_description')) throw new Error(friendly(q.get('error_description')));
      const at = q.get('access_token');
      if (!at) throw new Error('Login ' + provider + ' tidak mengembalikan token.');
      const u = await raw('/auth/v1/user', { token: at });
      await saveSession({ access_token: at, refresh_token: q.get('refresh_token'), expires_in: +q.get('expires_in') || 3600, user: u });
    },
    async signOut() {
      const s = (await get({ [K.sess]: null }))[K.sess];
      if (s && s.kind !== 'google') { try { await raw('/auth/v1/logout', { method: 'POST', token: s.access_token }); } catch (e) { /* abaikan */ } }
      await set({ [K.sess]: null, [K.last]: 0 });
    },

    // ---- sinkronisasi ----
    // tombstone: catat penghapusan supaya percakapan yang dihapus tidak "hidup lagi" dari perangkat lain
    async tombstone(ids) {
      const d = (await get({ [K.del]: {} }))[K.del] || {}; const t = Date.now();
      [].concat(ids).forEach((id) => { d[id] = t; });
      const keys = Object.keys(d); if (keys.length > 200) keys.sort((a, b) => d[a] - d[b]).slice(0, keys.length - 200).forEach((k) => delete d[k]);
      await set({ [K.del]: d });
      Acct.syncSoon();
    },
    merge(local, remote) {
      const del = Object.assign({}, remote.del || {}, local.del || {});
      Object.keys(remote.del || {}).forEach((k) => { del[k] = Math.max((remote.del || {})[k] || 0, (local.del || {})[k] || 0); });
      const byId = new Map();
      [].concat(remote.chats || [], local.chats || []).forEach((c) => {
        const o = byId.get(c.id);
        if (!o || (c.mt || c.ts || 0) >= (o.mt || o.ts || 0)) byId.set(c.id, c);
      });
      const chats = [...byId.values()].filter((c) => !(del[c.id] && del[c.id] >= (c.mt || c.ts || 0)))
        .sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || (b.ts || 0) - (a.ts || 0)).slice(0, 40);
      return {
        chats, del,
        memoryNotes: local.memoryNotes || remote.memoryNotes || '',
        persona: local.persona && local.persona !== 'default' ? local.persona : (remote.persona || local.persona || 'default'),
        customCmds: (local.customCmds && local.customCmds.length) ? local.customCmds : (remote.customCmds || [])
      };
    },
    async localData() {
      const s = await get({ chats: [], [K.del]: {}, memoryNotes: '', persona: 'default', customCmds: [] });
      return { chats: s.chats, del: s[K.del], memoryNotes: s.memoryNotes, persona: s.persona, customCmds: s.customCmds };
    },
    async sync() {
      const s = await session(); if (!s) throw new Error('Belum masuk.');
      if (s.kind === 'google') {
        const tk = await gtoken(s);
        const { id, data } = await drivePull(tk);
        const merged = Acct.merge(await Acct.localData(), data || {});
        await set({ chats: merged.chats, [K.del]: merged.del, memoryNotes: merged.memoryNotes, persona: merged.persona, customCmds: merged.customCmds, [K.last]: Date.now() });
        await drivePush(tk, id, merged);
        return merged;
      }
      const rows = await raw('/rest/v1/lgb_sync?select=data&user_id=eq.' + s.user.id, { token: s.access_token });
      const remote = (rows && rows[0] && rows[0].data) || {};
      const merged = Acct.merge(await Acct.localData(), remote);
      await set({ chats: merged.chats, [K.del]: merged.del, memoryNotes: merged.memoryNotes, persona: merged.persona, customCmds: merged.customCmds, [K.last]: Date.now() });
      await raw('/rest/v1/lgb_sync?on_conflict=user_id', {
        method: 'POST', token: s.access_token, headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
        body: { user_id: s.user.id, data: merged, updated_at: new Date().toISOString() }
      });
      return merged;
    },
    _timer: 0,
    syncSoon() {
      clearTimeout(Acct._timer);
      Acct._timer = setTimeout(async () => { try { if (await Acct.user()) { await Acct.sync(); window.dispatchEvent(new CustomEvent('lgb-synced')); } } catch (e) { /* diam-diam */ } }, 3000);
    },
    SQL: "create table if not exists public.lgb_sync (\n  user_id uuid primary key references auth.users(id) on delete cascade,\n  data jsonb not null default '{}'::jsonb,\n  updated_at timestamptz not null default now()\n);\nalter table public.lgb_sync enable row level security;\ncreate policy \"own row select\" on public.lgb_sync for select using (auth.uid() = user_id);\ncreate policy \"own row insert\" on public.lgb_sync for insert with check (auth.uid() = user_id);\ncreate policy \"own row update\" on public.lgb_sync for update using (auth.uid() = user_id);\ncreate policy \"own row delete\" on public.lgb_sync for delete using (auth.uid() = user_id);"
  };
  window.Acct = Acct;
})();
