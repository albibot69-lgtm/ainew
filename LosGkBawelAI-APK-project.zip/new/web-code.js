// Blok kode yang rapi (sorotan sintaks, salin, unduh) + panel samping pratinjau kode langsung.
(function () {
  if (!window.LGB_WEB) return;
  const $ = (id) => document.getElementById(id);
  const root = document.documentElement;
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const ALIAS = { js: 'javascript', mjs: 'javascript', jsx: 'javascript', ts: 'typescript', tsx: 'typescript', py: 'python', sh: 'bash', shell: 'bash', zsh: 'bash', yml: 'yaml', cs: 'csharp', luau: 'lua', 'c++': 'cpp', htm: 'html', vue: 'xml', ps1: 'powershell', plaintext: 'text', txt: 'text' };
  const EXT = { javascript: 'js', typescript: 'ts', python: 'py', html: 'html', css: 'css', json: 'json', bash: 'sh', lua: 'lua', java: 'java', cpp: 'cpp', c: 'c', csharp: 'cs', go: 'go', rust: 'rs', php: 'php', sql: 'sql', yaml: 'yml', markdown: 'md', svg: 'svg', kotlin: 'kt', swift: 'swift', xml: 'xml', powershell: 'ps1', dockerfile: 'Dockerfile', text: 'txt' };
  const NAME = { javascript: 'JavaScript', typescript: 'TypeScript', python: 'Python', html: 'HTML', css: 'CSS', json: 'JSON', bash: 'Bash', lua: 'Lua', java: 'Java', cpp: 'C++', c: 'C', csharp: 'C#', go: 'Go', rust: 'Rust', php: 'PHP', sql: 'SQL', yaml: 'YAML', markdown: 'Markdown', svg: 'SVG', kotlin: 'Kotlin', swift: 'Swift', xml: 'XML', powershell: 'PowerShell', text: 'Teks' };

  // ---------- sorotan sintaks (dengan cache supaya streaming tetap ringan) ----------
  const cache = new Map();
  function hl(text, lang) {
    const key = lang + '\u0000' + text; if (cache.has(key)) return cache.get(key);
    let out;
    try {
      if (!window.hljs || lang === 'text') out = esc(text);
      else if (lang && hljs.getLanguage(lang)) out = hljs.highlight(text, { language: lang, ignoreIllegals: true }).value;
      else if (!lang && text.length < 4000) out = hljs.highlightAuto(text).value;
      else out = esc(text);
    } catch (e) { out = esc(text); }
    cache.set(key, out); if (cache.size > 160) cache.delete(cache.keys().next().value);
    return out;
  }
  const langOf = (code, text) => {
    const m = (code.className || '').match(/language-([^\s]+)/);
    let l = (m ? m[1] : '').toLowerCase(); l = ALIAS[l] || l;
    if (!l && /^\s*(<!doctype html|<html)/i.test(text)) l = 'html';
    if (l === 'xml' && /^\s*<svg/i.test(text)) l = 'svg';
    return l;
  };

  // ---------- susun dokumen pratinjau ----------
  function inject(d, tag, where) {
    if (where === 'head') { if (/<\/head>/i.test(d)) return d.replace(/<\/head>/i, () => tag + '</head>'); if (/<head[^>]*>/i.test(d)) return d.replace(/<head[^>]*>/i, (m) => m + tag); return tag + d; }
    if (/<\/body>/i.test(d)) return d.replace(/<\/body>/i, () => tag + '</body>');
    return d + tag;
  }
  function buildDoc(blocks) {
    const html = blocks.filter((b) => b.lang === 'html').pop();
    if (html) {
      let d = html.text;
      const css = blocks.filter((b) => b.lang === 'css').map((b) => b.text).join('\n');
      const js = blocks.filter((b) => b.lang === 'javascript').map((b) => b.text).join('\n;\n');
      if (css && !/<style|rel=["']?stylesheet/i.test(d)) d = inject(d, '<style>' + css + '</style>', 'head');
      if (js && !/<script/i.test(d)) d = inject(d, '<script>' + js + '<\/script>', 'body');
      return d;
    }
    const svg = blocks.find((b) => b.lang === 'svg');
    if (svg) return '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><body style="margin:0;min-height:100vh;display:grid;place-items:center;background:#fff">' + svg.text;
    return null;
  }
  const SHIM = '<script>(function(){var p=function(t,a){try{parent.postMessage({lgbCon:1,t:t,m:Array.prototype.map.call(a,function(x){try{return typeof x==="string"?x:JSON.stringify(x)}catch(e){return String(x)}}).join(" ")},"*")}catch(e){}};["log","info","warn","error"].forEach(function(k){var o=console[k];console[k]=function(){p(k,arguments);o.apply(console,arguments)}});addEventListener("error",function(e){p("error",[e.message+(e.lineno?" (baris "+e.lineno+")":"")])});addEventListener("unhandledrejection",function(e){p("error",["Promise ditolak: "+(e.reason&&e.reason.message||e.reason)])})})();<\/script>';
  function withShim(d) {
    if (/<head[^>]*>/i.test(d)) return d.replace(/<head[^>]*>/i, (m) => m + SHIM);
    if (/<html[^>]*>/i.test(d)) return d.replace(/<html[^>]*>/i, (m) => m + '<head>' + SHIM + '</head>');
    if (/^\s*<!doctype[^>]*>/i.test(d)) return d.replace(/^\s*<!doctype[^>]*>/i, (m) => m + SHIM);
    return SHIM + d;
  }

  // ---------- panel ----------
  const P = { row: null, doc: '', tab: 'preview', dev: 'desktop', timer: 0, lastAt: 0, shown: '' };
  const panel = $('cpanel'), frame = $('cpFrame');
  const icoSet = (id, n, s) => { const e = $(id); if (e) e.innerHTML = ic(n, s || 16); };
  icoSet('cpReload', 'refresh-cw'); icoSet('cpCopy', 'copy'); icoSet('cpDl', 'download'); icoSet('cpOpen', 'external-link'); icoSet('cpClose', 'x', 17);
  icoSet('cpDevD', 'monitor'); icoSet('cpDevT', 'tablet'); icoSet('cpDevP', 'smartphone');
  $('cpTabP').innerHTML = ic('eye', 14) + ' Pratinjau'; $('cpTabC').innerHTML = ic('code', 14) + ' Kode';
  $('cpConT').innerHTML = ic('terminal', 14) + ' Konsol <b id="cpConN">0</b>';
  let cons = [];
  const drawCons = () => {
    const errs = cons.filter((c) => c.t === 'error').length;
    $('cpConN').textContent = cons.length; $('cpConN').className = errs ? 'err' : '';
    $('cpConL').innerHTML = cons.length ? cons.slice(-200).map((c) => '<div class="' + c.t + '">' + esc(c.m) + '</div>').join('') : '<div class="mut">Belum ada keluaran console.</div>';
    $('cpConL').scrollTop = 1e9;
  };
  window.addEventListener('message', (e) => {
    if (frame && e.source === frame.contentWindow && e.data && e.data.lgbCon) {
      cons.push({ t: e.data.t, m: String(e.data.m).slice(0, 600) }); if (cons.length > 300) cons.shift(); drawCons();
      if (e.data.t === 'error') panel.classList.add('con-open');
    } else if (e.data && e.data.lgbPrevReady && P.doc) e.source.postMessage({ doc: P.doc, title: 'Pratinjau' }, location.origin);
  });

  function paint(force) {
    if (!P.row) return;
    const doc = buildDoc(P.row._lgbBlocks || []);
    if (doc == null) return;
    P.doc = doc;
    if (P.tab === 'code') { $('cpCode').innerHTML = hl(doc, 'html'); }
    if (force || doc !== P.shown) { P.shown = doc; cons = []; drawCons(); frame.srcdoc = withShim(doc); }
  }
  function schedule(streaming) {
    const wait = streaming ? 1800 : 0, now = Date.now();
    clearTimeout(P.timer);
    if (!streaming) return paint(false);
    P.timer = setTimeout(() => { P.lastAt = Date.now(); paint(false); }, Math.max(0, wait - (now - P.lastAt)));
  }
  function setTab(t) {
    P.tab = t; panel.dataset.tab = t;
    $('cpTabP').classList.toggle('on', t === 'preview'); $('cpTabC').classList.toggle('on', t === 'code');
    $('cpCode').hidden = t !== 'code'; $('cpStage').hidden = t !== 'preview';
    if (t === 'code') $('cpCode').innerHTML = hl(P.doc || '', 'html');
  }
  function setDev(d) {
    P.dev = d; panel.dataset.dev = d;
    [['cpDevD', 'desktop'], ['cpDevT', 'tablet'], ['cpDevP', 'phone']].forEach(([id, k]) => $(id).classList.toggle('on', k === d));
  }
  function open(row, manual) {
    P.row = row; panel.hidden = false; root.classList.add('cp-open');
    if (innerWidth < 1500) root.classList.remove('side-open');
    if (manual) { setTab('preview'); row._lgbClosed = false; }
    paint(true);
  }
  function close() {
    if (P.row) P.row._lgbClosed = true;
    panel.hidden = true; root.classList.remove('cp-open'); clearTimeout(P.timer);
    frame.srcdoc = ''; P.shown = '';
  }
  $('cpClose').onclick = close;
  $('cpTabP').onclick = () => setTab('preview'); $('cpTabC').onclick = () => setTab('code');
  $('cpDevD').onclick = () => setDev('desktop'); $('cpDevT').onclick = () => setDev('tablet'); $('cpDevP').onclick = () => setDev('phone');
  $('cpReload').onclick = () => paint(true);
  $('cpConT').onclick = () => panel.classList.toggle('con-open');
  const flash = (b, html) => { const o = b.innerHTML; b.innerHTML = html; setTimeout(() => { b.innerHTML = o; }, 1200); };
  const copy = async (text, b, label) => { try { await navigator.clipboard.writeText(text); } catch (e) { const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch (e2) { /* abaikan */ } ta.remove(); } flash(b, ic('check-circle', 14) + (label ? ' Tersalin' : '')); };
  const save = (name, text) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' })); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); };
  $('cpCopy').onclick = () => copy(P.doc, $('cpCopy'));
  $('cpDl').onclick = () => save('index.html', P.doc);
  $('cpOpen').onclick = () => { if (P.doc) window.open('preview.html', '_blank'); };
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !panel.hidden && !document.querySelector('.sheet.on') && document.activeElement === document.body) close(); });

  // geser lebar panel
  const drag = $('cpDrag');
  drag.addEventListener('pointerdown', (e) => {
    e.preventDefault(); drag.setPointerCapture(e.pointerId); panel.classList.add('dragging');
    const mv = (ev) => { const w = Math.max(360, Math.min(innerWidth * 0.72, innerWidth - ev.clientX)); panel.style.setProperty('--cp-w', w + 'px'); };
    const up = () => { panel.classList.remove('dragging'); drag.removeEventListener('pointermove', mv); drag.removeEventListener('pointerup', up); try { localStorage.setItem('lgbCpW', panel.style.getPropertyValue('--cp-w')); } catch (x) { /* abaikan */ } };
    drag.addEventListener('pointermove', mv); drag.addEventListener('pointerup', up);
  });
  try { const w = localStorage.getItem('lgbCpW'); if (w) panel.style.setProperty('--cp-w', w); } catch (e) { /* abaikan */ }
  setDev('desktop'); setTab('preview'); drawCons();

  // ---------- percantik blok kode di pesan AI ----------
  window.LGB_CODE = {
    enhance(msg, row, streaming, fresh) {
      const pres = [...msg.querySelectorAll('pre')], blocks = [];
      pres.forEach((pre, i) => {
        const code = pre.querySelector('code'); if (!code) return;
        const text = code.textContent.replace(/\n$/, '');
        const lang = langOf(code, text);
        blocks.push({ lang, text });
        const last = i === pres.length - 1;
        code.innerHTML = (streaming && last && text.length > 6000) ? esc(text) : hl(text, lang);
        code.classList.add('hljs');
        const prev = lang === 'html' || lang === 'svg';
        const w = document.createElement('div'); w.className = 'cb'; w.dataset.i = String(blocks.length - 1);
        w.innerHTML = '<div class="cb-h"><span class="cb-l">' + esc(NAME[lang] || lang || 'Kode') + '</span><span class="cb-s"></span>' +
          (prev ? '<button type="button" data-act="preview">' + ic('eye', 14) + ' Pratinjau</button>' : '') +
          '<button type="button" data-act="dl" title="Unduh">' + ic('download', 14) + '</button>' +
          '<button type="button" data-act="copy">' + ic('copy', 14) + ' Salin</button></div>';
        pre.querySelectorAll('.copy').forEach((n) => n.remove());
        pre.replaceWith(w); w.appendChild(pre);
      });
      row._lgbBlocks = blocks;
      if (streaming) row._lgbSeen = true;
      const live = streaming || row._lgbSeen || !!fresh;
      if (!blocks.length) return;
      const doc = buildDoc(blocks);
      if (doc == null) return;
      if (panel.hidden) { if (live && !row._lgbClosed && doc.length > 120) open(row, false); }
      else if (P.row === row) schedule(streaming);
      else if (live && !row._lgbClosed && doc.length > 120) open(row, false);
    }
  };
  const chat = $('chat');
  chat.addEventListener('click', (e) => {
    const b = e.target.closest('.cb [data-act]'); if (!b) return;
    const row = b.closest('.row'), w = b.closest('.cb'), blk = row && row._lgbBlocks && row._lgbBlocks[+w.dataset.i]; if (!blk) return;
    const act = b.dataset.act;
    if (act === 'copy') copy(blk.text, b, true);
    else if (act === 'dl') save('kode.' + (EXT[blk.lang] || 'txt'), blk.text);
    else if (act === 'preview') open(row, true);
  });
})();
