// Port vanilla JS dari komponen SpringCheck (React Bits): kotak centang dengan pegas,
// isian membengkak dari tengah, centang tergambar, dan coretan pada teks.
// Pegas dihitung sendiri (tanpa library motion).
function SpringCheck(host, o) {
  o = o || {};
  const boxSize = o.boxSize || 28, boxRadius = o.boxRadius ?? 9, fontSize = o.fontSize || 18;
  const bounce = o.bounce ?? 0.2, strikeLag = o.strikeLag ?? 0.12, doneOpacity = o.doneOpacity ?? 0.42, strike = o.strike || 'left';
  const SWELL = 0.35, RULE_END = 0.84, VISUAL = 0.2;
  const TICK = 'M5 14L8.5 17.5L19 6.5';
  const ORIGIN = { left: 'left center', center: 'center', right: 'right center', none: 'left center' };
  const clamp01 = (v) => Math.min(1, Math.max(0, v));
  const zeta = bounce <= 0 ? 1 : -Math.log(bounce) / Math.sqrt(Math.PI ** 2 + Math.log(bounce) ** 2);
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  let on = !!o.defaultChecked, t = on ? 1 : 0, v = 0, raf = 0, viaPointer = false;
  const ring = boxSize >= 24 ? 2 : 1.5;
  const gap = Math.min(16, Math.max(8, Math.round(boxSize * 0.43)));
  const ruleH = Math.max(1.5, Math.round(fontSize / 6) / 2);

  const btn = document.createElement('button');
  btn.type = 'button'; btn.setAttribute('role', 'checkbox'); btn.className = 'spring-check' + (o.wrap ? ' spring-check--wrap' : '');
  if (o.ariaLabel) btn.setAttribute('aria-label', o.ariaLabel);
  const st = btn.style;
  st.setProperty('--sc-box', boxSize + 'px'); st.setProperty('--sc-radius', boxRadius + 'px'); st.setProperty('--sc-font', fontSize + 'px');
  st.setProperty('--sc-ring', ring + 'px'); st.setProperty('--sc-gap', gap + 'px'); st.setProperty('--sc-row', Math.max(44, boxSize + 16) + 'px');
  st.setProperty('--sc-rule', ruleH + 'px'); st.setProperty('--sc-origin', ORIGIN[strike] || ORIGIN.left);
  if (o.color) st.setProperty('--sc-ink', o.color);
  if (o.fillColor) st.setProperty('--sc-fill', o.fillColor);
  if (o.checkColor) st.setProperty('--sc-check', o.checkColor);

  btn.innerHTML = '<span class="spring-check__press"><span class="spring-check__box"><span class="spring-check__ring"></span>' +
    '<span class="spring-check__fill"></span><svg class="spring-check__tick" viewBox="0 0 24 24" aria-hidden="true"><path d="' + TICK + '" pathLength="1" stroke-dasharray="1"/></svg></span></span>' +
    '<span class="spring-check__label"><span class="spring-check__word"></span>' + (strike !== 'none' ? '<span class="spring-check__rule" aria-hidden="true"></span>' : '') + '</span>';
  btn.querySelector('.spring-check__word').textContent = o.label || '';
  host.appendChild(btn);
  const box = btn.querySelector('.spring-check__box'), fill = btn.querySelector('.spring-check__fill'),
    tick = btn.querySelector('path'), word = btn.querySelector('.spring-check__word'), rule = btn.querySelector('.spring-check__rule');

  function write(x) {
    const held = clamp01(x);
    fill.style.transform = 'scale(' + Math.max(x, 0) + ')';
    box.style.transform = 'scale(' + (1 + SWELL * Math.max(0, x - 1)) + ')';
    tick.style.strokeDashoffset = 1 - held;
    word.style.opacity = 1 - (1 - doneOpacity) * held;
    if (rule) rule.style.transform = 'scaleX(' + clamp01((held - strikeLag) / (RULE_END - strikeLag)) + ')';
  }
  function go(target, instant) {
    cancelAnimationFrame(raf);
    if (reduce || instant) { t = target; v = 0; write(t); return; }
    const w = (2 * Math.PI) / VISUAL, k = w * w, c = 2 * zeta * w;
    let last = performance.now();
    const step = (now) => {
      const dt = Math.min(0.032, (now - last) / 1000); last = now;
      const n = Math.max(1, Math.ceil(dt / 0.004)), h = dt / n;
      for (let i = 0; i < n; i++) { v += (-k * (t - target) - c * v) * h; t += v * h; }
      write(t);
      if (Math.abs(t - target) < 0.0005 && Math.abs(v) < 0.01) { t = target; write(t); return; }
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
  }
  function apply(instant) { btn.setAttribute('aria-checked', String(on)); go(on ? 1 : 0, instant); }

  btn.addEventListener('pointerdown', (e) => { if (e.button !== 0 || btn.disabled) return; viaPointer = true; if (!reduce) btn.dataset.pressed = ''; });
  const unpress = () => { delete btn.dataset.pressed; };
  btn.addEventListener('pointerup', unpress);
  btn.addEventListener('pointercancel', () => { viaPointer = false; unpress(); });
  btn.addEventListener('pointerleave', () => { viaPointer = false; unpress(); });
  btn.addEventListener('click', () => {
    if (btn.disabled) return;
    const instant = !viaPointer; viaPointer = false;
    on = !on; apply(instant);
    o.onChange && o.onChange(on);
  });
  write(t); btn.setAttribute('aria-checked', String(on));
  return { el: btn, get checked() { return on; }, set(v2) { on = !!v2; apply(false); } };
}
