// Memasang Target Cursor di halaman extension (popup, pengaturan, dashboard) sesuai pengaturan pengguna.
(function () {
  const KEYS = {
    cursorOn: false, cursorColor: '#ffffff', cursorColorOnTarget: '', cursorSpin: 2, cursorHover: 0.2, cursorParallax: true,
    cursorSize: 36, cursorCorner: 12, cursorThickness: 3, cursorPadding: 6, cursorMatchRadius: true, cursorDot: 4,
    cursorBlend: 'difference', cursorLabel: true, cursorClick: true, cursorHide: true
  };
  const SELECTOR = '.cursor-target, button, a[href], select, textarea, summary, [role="button"], label.switch, .tabrow, .sw, ' +
    'input:not([type="hidden"]):not([type="range"]):not([type="color"]):not([type="checkbox"]):not([type="file"])';
  let tc = null;
  const num = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);

  function toOpts(s) {
    return {
      targetSelector: SELECTOR,
      cursorColor: s.cursorColor || '#ffffff',
      cursorColorOnTarget: s.cursorColorOnTarget || undefined,
      spinDuration: num(s.cursorSpin, 2),
      hoverDuration: num(s.cursorHover, 0.2),
      parallaxOn: !!s.cursorParallax,
      hideDefaultCursor: !!s.cursorHide,
      size: num(s.cursorSize, 36),
      cornerSize: num(s.cursorCorner, 12),
      thickness: num(s.cursorThickness, 3),
      padding: num(s.cursorPadding, 6),
      matchRadius: !!s.cursorMatchRadius,
      dotSize: num(s.cursorDot, 4),
      blendMode: s.cursorBlend || 'difference',
      showLabel: !!s.cursorLabel,
      clickEffect: !!s.cursorClick,
      labelFromTitle: true
    };
  }

  function apply(s) {
    if (!s.cursorOn || window.LGB_LITE || (window.matchMedia && matchMedia('(pointer: coarse)').matches)) { if (tc) { tc.destroy(); tc = null; } return; }
    if (!tc) tc = window.TargetCursor(toOpts(s));
    else tc.update(toOpts(s));
  }

  async function load() { return chrome.storage.local.get(KEYS); }
  load().then(apply);
  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== 'local' || !Object.keys(KEYS).some((k) => k in c)) return;
    load().then(apply);
  });
  window.LGB_CURSOR_KEYS = KEYS;
})();
