// Saklar mode anti lag / mode senyap di halaman pengaturan (efeknya hanya di popup).
(function () {
  const lite = document.getElementById('lite'), disguise = document.getElementById('disguise');
  if (!lite || !disguise) return;
  const load = () => chrome.storage.local.get({ lite: false, disguise: false }).then((s) => { lite.checked = !!s.lite; disguise.checked = !!s.disguise; });
  load();
  lite.addEventListener('change', () => chrome.storage.local.set({ lite: lite.checked }));
  disguise.addEventListener('change', () => chrome.storage.local.set({ disguise: disguise.checked }));
  chrome.storage.onChanged.addListener((c) => { if (c.lite || c.disguise) load(); });
})();
