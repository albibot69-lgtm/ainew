// Memasang GlassSurface pada permukaan yang cocok. Dijalankan di popup (header) dan halaman pengaturan (sidebar, kartu).
(function () {
  if (typeof GlassSurface !== 'function' || window.LGB_LITE) return;
  const isOptions = !!document.querySelector('.app');
  const targets = isOptions ? ['.side', '.card'] : ['header'];
  const opts = isOptions
    ? { distortionScale: -70, displace: 0.4, backgroundOpacity: 0.1, saturation: 1.25, borderWidth: 0.05, blur: 9, brightness: 50, opacity: 0.93 }
    : { distortionScale: -60, displace: 0.3, backgroundOpacity: 0.06, saturation: 1.2, borderWidth: 0.12, blur: 7, brightness: 50, opacity: 0.93 };
  const apply = () => {
    targets.forEach((sel) => document.querySelectorAll(sel).forEach((el) => {
      if (el.classList.contains('gs')) return;
      try {
        const bf = getComputedStyle(el).backdropFilter;
        if (bf && bf !== 'none') return; // sudah punya kaca (mode glass/iOS)
        GlassSurface(el, opts);
      } catch (e) {}
    }));
  };
  apply();
})();
