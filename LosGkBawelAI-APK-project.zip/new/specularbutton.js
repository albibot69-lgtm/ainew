// Port vanilla JS dari React Bits <SpecularButton />: cahaya spekular di tepi tombol yang mengikuti kursor.
// Satu konteks WebGL2 dipakai bersama untuk semua tombol (hasilnya disalin ke canvas 2D tiap tombol),
// jadi aman untuk puluhan tombol. Latar/gradien tombol TIDAK diubah; hanya ditambah lapisan cahaya.
(function () {
'use strict';
const PAD = 24, TAU = Math.PI * 2;
const VERTEX = `#version 300 es
in vec2 aPosition;
void main() { gl_Position = vec4(aPosition, 0.0, 1.0); }`;
const FRAGMENT = `#version 300 es
precision highp float;
uniform vec2 uCenter; uniform vec2 uHalf; uniform float uRadius; uniform float uPx; uniform float uSpot;
uniform vec2 uEntry; uniform vec3 uLineColor; uniform float uIntensity; uniform vec2 uWindow;
uniform float uThickness; uniform float uGlow;
out vec4 outColor;
float roundedBox(vec2 p, vec2 b, float r) { vec2 q = abs(p) - b + r; return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r; }
float loopPosition(vec2 p, vec2 b, float r) {
  vec2 inner = b - r; float arc = 1.5707963 * r; float quarter = inner.x + inner.y + arc;
  vec2 a = abs(p); vec2 q = a - inner;
  float s = q.x > 0.0 && q.y > 0.0 ? inner.y + atan(q.y, q.x) * r : (q.x > q.y ? min(a.y, inner.y) : inner.y + arc + inner.x - min(a.x, inner.x));
  if (p.x < 0.0) s = p.y >= 0.0 ? 2.0 * quarter - s : 2.0 * quarter + s;
  else if (p.y < 0.0) s = 4.0 * quarter - s;
  return s / max(4.0 * quarter, 0.0001);
}
float lobe(float position, float center) { float gap = abs(fract(position - center + 0.5) - 0.5); return 1.0 - smoothstep(uWindow.x, uWindow.x + uWindow.y, gap); }
void main() {
  vec2 p = gl_FragCoord.xy - uCenter;
  float d = roundedBox(p, uHalf, uRadius);
  float position = loopPosition(p, uHalf, uRadius);
  float key = lobe(position, uSpot);
  float back = lobe(position, uSpot + 0.5);
  float streak = key + back * 0.45;
  float width = max(uThickness * uPx * mix(1.0, max(key, back), 0.6), 0.35);
  float band = smoothstep(-width - 0.6, -width + 0.6, d) * (1.0 - smoothstep(-0.6, 0.6, d));
  float inside = 1.0 - smoothstep(-0.6, 0.6, d);
  vec2 pool = (p - uEntry) / (uHalf.y * vec2(1.6, 1.1));
  float glow = streak * 0.2 * exp(-abs(d + width * 0.5) / (5.0 * uPx)) + inside * 0.08 * exp(-dot(pool, pool));
  float light = clamp((band * streak + glow * uGlow) * uIntensity, 0.0, 1.0);
  outColor = vec4(uLineColor, 1.0) * light;
}`;
const UNIFORMS = ['uCenter','uHalf','uRadius','uPx','uSpot','uEntry','uLineColor','uIntensity','uWindow','uThickness','uGlow'];
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const wrap = v => v - Math.floor(v);

const loopPosition = (x, y, halfX, halfY, r) => {
  const innerX = halfX - r, innerY = halfY - r, arc = (Math.PI / 2) * r, quarter = innerX + innerY + arc;
  const ax = Math.abs(x), ay = Math.abs(y), qx = ax - innerX, qy = ay - innerY;
  let s;
  if (qx > 0 && qy > 0) s = innerY + Math.atan2(qy, qx) * r;
  else if (qx > qy) s = Math.min(ay, innerY);
  else s = innerY + arc + innerX - Math.min(ax, innerX);
  if (x < 0) s = y >= 0 ? 2 * quarter - s : 2 * quarter + s;
  else if (y < 0) s = 4 * quarter - s;
  return wrap(s / Math.max(4 * quarter, 0.0001));
};
const rimPoint = (position, halfX, halfY, r) => {
  const innerX = halfX - r, innerY = halfY - r, arc = (Math.PI / 2) * r, quarter = innerX + innerY + arc;
  let s = wrap(position) * 4 * quarter, signX = 1, signY = 1;
  if (s > 3 * quarter) { s = 4 * quarter - s; signY = -1; }
  else if (s > 2 * quarter) { s -= 2 * quarter; signX = -1; signY = -1; }
  else if (s > quarter) { s = 2 * quarter - s; signX = -1; }
  let x = innerX - (s - innerY - arc), y = halfY;
  if (s <= innerY) { x = halfX; y = s; }
  else if (s <= innerY + arc) { const a = (s - innerY) / Math.max(r, 0.0001); x = innerX + Math.cos(a) * r; y = innerY + Math.sin(a) * r; }
  return [x * signX, y * signY];
};

// ---- GL bersama ----
let GL = null, glFailed = false;
function getGL() {
  if (GL || glFailed) return GL;
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2', { alpha: true, premultipliedAlpha: true, antialias: false, depth: false, stencil: false, preserveDrawingBuffer: true });
    if (!gl) throw 0;
    const mk = (t, src) => { const s = gl.createShader(t); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
    const prog = gl.createProgram();
    gl.attachShader(prog, mk(gl.VERTEX_SHADER, VERTEX));
    gl.attachShader(prog, mk(gl.FRAGMENT_SHADER, FRAGMENT));
    gl.bindAttribLocation(prog, 0, 'aPosition');
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
    const u = {};
    UNIFORMS.forEach(n => (u[n] = gl.getUniformLocation(prog, n)));
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);
    canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); GL = null; glFailed = true; });
    GL = { canvas, gl, prog, u, vao };
  } catch (e) { glFailed = true; GL = null; }
  return GL;
}

const probe = document.createElement('canvas').getContext('2d', { willReadFrequently: true });
const colorCache = new Map();
function toRgb(v) {
  if (colorCache.has(v)) return colorCache.get(v);
  let rgb = [1, 1, 1];
  if (probe) { probe.clearRect(0, 0, 1, 1); probe.fillStyle = '#000'; probe.fillStyle = v; probe.fillRect(0, 0, 1, 1); const d = probe.getImageData(0, 0, 1, 1).data; rgb = [d[0] / 255, d[1] / 255, d[2] / 255]; }
  colorCache.set(v, rgb); return rgb;
}

const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const DEF = { intensity: 1, idleIntensity: 0.35, shineSize: 10, shineFade: 34, thickness: 1.2, glow: 1, proximity: 220 };
const entries = new Map();   // button -> state
const pointer = { x: 0, y: 0, known: false };
let raf = 0, last = 0;

function radiusOf(b, st) {
  const cs = getComputedStyle(b);
  let r = cs.borderTopLeftRadius || '0';
  r = r.endsWith('%') ? parseFloat(r) / 100 * Math.min(st.w, st.h) : parseFloat(r) || 0;
  return Math.min(r, st.w / 2, st.h / 2);
}
function restSpot(st) {
  const r = st.r, inset = r * (1 - Math.SQRT1_2);
  return loopPosition(inset - st.w / 2, st.h / 2 - inset, st.w / 2, st.h / 2, r);
}
function aim(b, st) {
  if (!pointer.known || b.disabled) return null;
  const rect = b.getBoundingClientRect();
  if (!rect.width) return null;
  const scale = rect.width / st.w || 1, halfX = st.w / 2, halfY = st.h / 2;
  const x = (pointer.x - rect.left - rect.width / 2) / scale;
  const y = (rect.top + rect.height / 2 - pointer.y) / scale;
  const dist = Math.hypot(Math.max(Math.abs(x) - halfX, 0), Math.max(Math.abs(y) - halfY, 0));
  const t = clamp(1 - dist / DEF.proximity, 0, 1);
  const near = t * t * (3 - 2 * t);
  const nearest = loopPosition(x, y, halfX, halfY, st.r);
  if (dist > 0) return { spot: nearest, near };
  const depth = clamp(Math.min(halfX - Math.abs(x), halfY - Math.abs(y)) / (halfY * 0.8), 0, 1);
  const sway = restSpot(st) - (x / halfX) * 0.06 - (y / halfY) * 0.02;
  const off = sway - nearest - Math.round(sway - nearest);
  return { spot: wrap(nearest + off * depth * depth * (3 - 2 * depth)), near };
}

function draw(b, st) {
  const g = getGL(); if (!g) return;
  const { gl, canvas, u } = g;
  const w = st.w, h = st.h, ratio = st.ratio;
  const cw = Math.max(1, Math.round((w + PAD * 2) * ratio)), ch = Math.max(1, Math.round((h + PAD * 2) * ratio));
  if (st.cv.width !== cw || st.cv.height !== ch) { st.cv.width = cw; st.cv.height = ch; }
  if (canvas.width !== cw || canvas.height !== ch) { canvas.width = cw; canvas.height = ch; }
  const sx = cw / (w + PAD * 2), sy = ch / (h + PAD * 2);
  gl.viewport(0, 0, cw, ch);
  gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
  gl.useProgram(g.prog);
  gl.uniform2f(u.uCenter, (PAD + w / 2) * sx, (PAD + h / 2) * sy);
  gl.uniform2f(u.uHalf, (w / 2) * sx, (h / 2) * sy);
  gl.uniform1f(u.uRadius, st.r * sx);
  gl.uniform1f(u.uPx, ratio);
  const [rx, ry] = rimPoint(st.spot, w / 2, h / 2, st.r);
  const len = Math.hypot(rx, ry);
  const pull = 1 - Math.min(0.35 * (h / 2), len) / Math.max(len, 0.0001);
  gl.uniform1f(u.uSpot, st.spot);
  gl.uniform2f(u.uEntry, rx * pull * sx, ry * pull * sy);
  gl.uniform3fv(u.uLineColor, toRgb(getComputedStyle(b).color));
  gl.uniform1f(u.uIntensity, DEF.intensity * (st.level + st.press * 0.8));
  gl.uniform2f(u.uWindow, DEF.shineSize / 360 + st.press * 0.06, DEF.shineFade / 360 + 0.0001);
  gl.uniform1f(u.uThickness, DEF.thickness);
  gl.uniform1f(u.uGlow, DEF.glow);
  gl.bindVertexArray(g.vao);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  gl.bindVertexArray(null);
  st.ctx.clearRect(0, 0, cw, ch);
  st.ctx.drawImage(canvas, 0, 0);
}

function wake() { if (!raf) { last = 0; raf = requestAnimationFrame(frame); } }

function frame(now) {
  raf = 0;
  const dt = last ? Math.min(0.05, (now - last) / 1000) : 1 / 60;
  last = now;
  let again = false;
  entries.forEach((st, b) => {
    if (!st.visible || st.w < 4 || !b.isConnected) return;
    const target = aim(b, st);
    if (!st.ready) { st.r = radiusOf(b, st); st.spot = restSpot(st); st.level = DEF.idleIntensity; st.ready = true; st.dirty = true; }
    const steering = !!target && target.near > 0;
    const goal = steering ? target.spot : restSpot(st);
    let diff = goal - st.spot; diff -= Math.round(diff);
    st.spot = wrap(st.spot + diff * (1 - Math.exp(-dt * 8)));
    const level = DEF.idleIntensity + (1 - DEF.idleIntensity) * (target ? target.near : 0);
    st.level += (level - st.level) * (1 - Math.exp(-dt * 7));
    st.press *= Math.exp(-dt * 5);
    const settling = Math.abs(diff) > 0.0002 || Math.abs(level - st.level) > 0.001 || st.press > 0.002;
    if (settling || st.dirty) { draw(b, st); st.dirty = false; }
    if (settling) again = true;
  });
  if (again) raf = requestAnimationFrame(frame); else last = 0;
}

let ro, io;
function setup() {
  if (ro) return;
  ro = new ResizeObserver(list => {
    for (const en of list) {
      const st = entries.get(en.target); if (!st) continue;
      const box = en.borderBoxSize && en.borderBoxSize[0];
      st.w = Math.max(1, box ? box.inlineSize : en.target.offsetWidth);
      st.h = Math.max(1, box ? box.blockSize : en.target.offsetHeight);
      st.ratio = Math.min(devicePixelRatio || 1, 3);
      st.r = radiusOf(en.target, st);
      st.dirty = true;
    }
    wake();
  });
  io = new IntersectionObserver(list => { for (const en of list) { const st = entries.get(en.target); if (st) { st.visible = en.isIntersecting; st.dirty = true; } } wake(); });
  addEventListener('pointermove', e => { pointer.x = e.clientX; pointer.y = e.clientY; pointer.known = true; wake(); }, { passive: true });
  addEventListener('pointerdown', e => {
    pointer.x = e.clientX; pointer.y = e.clientY; pointer.known = true;
    const t = e.target && e.target.closest && e.target.closest('.sb');
    const st = t && entries.get(t);
    if (st && !t.disabled) st.press = 1;
    wake();
  }, { passive: true });
  document.documentElement.addEventListener('pointerleave', () => { pointer.known = false; wake(); });
  document.addEventListener('pointerup', e => { if (e.pointerType !== 'mouse') { pointer.known = false; wake(); } }, { passive: true });
}

function attach(b) {
  if (entries.has(b) || b.classList.contains('sb') || b.dataset.nospec != null) return;
  if (!getGL()) return;
  setup();
  const cv = document.createElement('canvas');
  cv.className = 'sb__light';
  cv.setAttribute('aria-hidden', 'true');
  b.classList.add('sb');
  if (getComputedStyle(b).position === 'static') b.style.position = 'relative';
  b.appendChild(cv);
  entries.set(b, { cv, ctx: cv.getContext('2d'), w: b.offsetWidth || 1, h: b.offsetHeight || 1, ratio: Math.min(devicePixelRatio || 1, 3), r: 0, spot: 0, level: 0, press: 0, ready: false, visible: true, dirty: true });
  ro.observe(b); io.observe(b);
}
function detachGone() { entries.forEach((st, b) => { if (!b.isConnected) { entries.delete(b); ro.unobserve(b); io.unobserve(b); } }); }

// Pasang otomatis ke semua elemen yang cocok (termasuk yang dibuat belakangan)
function SpecularButtons(selector, root) {
  root = root || document;
  const scan = node => {
    if (node.nodeType !== 1) return;
    if (node.matches && node.matches(selector)) attach(node);
    node.querySelectorAll && node.querySelectorAll(selector).forEach(attach);
  };
  scan(root.body || root.documentElement || root);
  new MutationObserver(ms => {
      ms.forEach(m => { m.addedNodes.forEach(scan); const st = entries.get(m.target); if (st && !st.cv.isConnected) { m.target.appendChild(st.cv); st.dirty = true; wake(); } });
      if (ms.length) detachGone();
    })
    .observe(root.body || root.documentElement, { childList: true, subtree: true });
}
window.SpecularButtons = SpecularButtons;
})();
