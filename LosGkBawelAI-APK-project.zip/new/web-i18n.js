// Bahasa antarmuka. Bawaan: English. Pilihan disimpan di storage 'uiLang'.
(function () {
  if (!window.LGB_WEB && !(window.chrome && chrome.runtime)) return;
  const LANGS = [['en', 'English'], ['id', 'Bahasa Indonesia'], ['es', 'Español'], ['fr', 'Français'], ['de', 'Deutsch'], ['pt', 'Português'], ['ru', 'Русский'], ['ar', 'العربية'], ['zh', '中文'], ['ja', '日本語'], ['ko', '한국어'], ['hi', 'हिन्दी'], ['tr', 'Türkçe']];
  const AI_NAME = { en: 'English', id: 'Indonesian', es: 'Spanish', fr: 'French', de: 'German', pt: 'Portuguese', ru: 'Russian', ar: 'Arabic', zh: 'Chinese', ja: 'Japanese', ko: 'Korean', hi: 'Hindi', tr: 'Turkish' };
  // urutan nilai tiap baris: en id es fr de pt ru ar zh ja ko hi tr
  const O = ['en', 'id', 'es', 'fr', 'de', 'pt', 'ru', 'ar', 'zh', 'ja', 'ko', 'hi', 'tr'];
  const R = {
    gSub: ['Sign in or sign up to start using the AI.', 'Masuk atau daftar dulu untuk mulai pakai AI.', 'Inicia sesión o regístrate para usar la IA.', 'Connectez-vous ou inscrivez-vous pour utiliser l\'IA.', 'Melde dich an oder registriere dich, um die KI zu nutzen.', 'Entre ou cadastre-se para usar a IA.', 'Войдите или зарегистрируйтесь, чтобы пользоваться ИИ.', 'سجّل الدخول أو أنشئ حسابًا لبدء استخدام الذكاء الاصطناعي.', '登录或注册后即可使用 AI。', 'ログインまたは登録してAIを使いましょう。', '로그인하거나 가입하고 AI를 사용하세요.', 'AI इस्तेमाल करने के लिए साइन इन या साइन अप करें।', 'Yapay zekayı kullanmak için giriş yapın veya kaydolun.'],
    tIn: ['Sign in', 'Masuk', 'Iniciar sesión', 'Connexion', 'Anmelden', 'Entrar', 'Вход', 'دخول', '登录', 'ログイン', '로그인', 'साइन इन', 'Giriş'],
    tUp: ['Sign up', 'Daftar', 'Registrarse', 'Inscription', 'Registrieren', 'Cadastrar', 'Регистрация', 'حساب جديد', '注册', '新規登録', '가입', 'साइन अप', 'Kayıt'],
    email: ['Email', 'Email', 'Correo', 'E-mail', 'E-Mail', 'E-mail', 'Эл. почта', 'البريد الإلكتروني', '邮箱', 'メール', '이메일', 'ईमेल', 'E-posta'],
    pass: ['Password', 'Password', 'Contraseña', 'Mot de passe', 'Passwort', 'Senha', 'Пароль', 'كلمة المرور', '密码', 'パスワード', '비밀번호', 'पासवर्ड', 'Şifre'],
    passPh: ['At least 8 characters', 'Minimal 8 karakter', 'Mínimo 8 caracteres', '8 caractères minimum', 'Mindestens 8 Zeichen', 'Mínimo de 8 caracteres', 'Минимум 8 символов', '8 أحرف على الأقل', '至少 8 个字符', '8文字以上', '8자 이상', 'कम से कम 8 अक्षर', 'En az 8 karakter'],
    bIn: ['Sign in', 'Masuk', 'Se connecter', 'Se connecter', 'Anmelden', 'Entrar', 'Войти', 'دخول', '登录', 'ログイン', '로그인', 'साइन इन', 'Giriş yap'],
    bUp: ['Create account', 'Buat akun', 'Crear cuenta', 'Créer un compte', 'Konto erstellen', 'Criar conta', 'Создать аккаунт', 'إنشاء حساب', '创建账号', 'アカウント作成', '계정 만들기', 'खाता बनाएं', 'Hesap oluştur'],
    wait: ['Please wait…', 'Tunggu…', 'Espera…', 'Patientez…', 'Bitte warten…', 'Aguarde…', 'Подождите…', 'يرجى الانتظار…', '请稍候…', 'お待ちください…', '잠시만요…', 'कृपया प्रतीक्षा करें…', 'Bekleyin…'],
    or: ['or', 'atau', 'o', 'ou', 'oder', 'ou', 'или', 'أو', '或', 'または', '또는', 'या', 'veya'],
    google: ['Continue with Google', 'Lanjutkan dengan Google', 'Continuar con Google', 'Continuer avec Google', 'Weiter mit Google', 'Continuar com o Google', 'Продолжить с Google', 'المتابعة عبر Google', '使用 Google 继续', 'Googleで続ける', 'Google로 계속', 'Google से जारी रखें', 'Google ile devam et'],
    guest: ['Continue without an account', 'Lanjut tanpa akun', 'Continuar sin cuenta', 'Continuer sans compte', 'Ohne Konto fortfahren', 'Continuar sem conta', 'Продолжить без аккаунта', 'المتابعة بدون حساب', '不登录继续', 'アカウントなしで続ける', '계정 없이 계속', 'बिना खाते के जारी रखें', 'Hesapsız devam et'],
    guestSub: ['(smaller limits, no photo upload)', '(jatah lebih kecil, tanpa kirim foto)', '(límite menor, sin fotos)', '(limite réduite, sans photos)', '(kleineres Limit, keine Fotos)', '(limite menor, sem fotos)', '(лимит меньше, без фото)', '(حد أقل، بدون صور)', '（额度较小，不能发图片）', '（上限が小さく、写真は送れません）', '(한도 낮음, 사진 불가)', '(कम सीमा, फ़ोटो नहीं)', '(düşük limit, fotoğraf yok)'],
    eEmail: ['Enter a valid email.', 'Isi email yang benar.', 'Introduce un correo válido.', 'Saisissez un e-mail valide.', 'Gültige E-Mail eingeben.', 'Informe um e-mail válido.', 'Введите корректный email.', 'أدخل بريدًا إلكترونيًا صحيحًا.', '请输入有效邮箱。', '有効なメールを入力してください。', '올바른 이메일을 입력하세요.', 'सही ईमेल दर्ज करें।', 'Geçerli bir e-posta girin.'],
    ePass: ['Password must be at least 8 characters.', 'Password minimal 8 karakter.', 'La contraseña debe tener al menos 8 caracteres.', 'Le mot de passe doit contenir au moins 8 caractères.', 'Das Passwort braucht mindestens 8 Zeichen.', 'A senha deve ter pelo menos 8 caracteres.', 'Пароль должен содержать минимум 8 символов.', 'يجب ألا تقل كلمة المرور عن 8 أحرف.', '密码至少 8 个字符。', 'パスワードは8文字以上です。', '비밀번호는 8자 이상이어야 합니다.', 'पासवर्ड कम से कम 8 अक्षर का हो।', 'Şifre en az 8 karakter olmalı.'],
    eWeak: ['Password is too weak. Use a longer one with letters, numbers and symbols.', 'Password terlalu lemah. Pakai yang lebih panjang dengan huruf, angka, dan simbol.', 'Contraseña demasiado débil. Usa una más larga con letras, números y símbolos.', 'Mot de passe trop faible. Utilisez-en un plus long avec lettres, chiffres et symboles.', 'Passwort zu schwach. Nimm ein längeres mit Buchstaben, Zahlen und Symbolen.', 'Senha fraca demais. Use uma mais longa com letras, números e símbolos.', 'Слишком слабый пароль. Используйте длиннее, с буквами, цифрами и символами.', 'كلمة المرور ضعيفة جدًا. استخدم كلمة أطول بحروف وأرقام ورموز.', '密码太弱。请使用更长且包含字母、数字和符号的密码。', 'パスワードが弱すぎます。英数字と記号を含む長いものにしてください。', '비밀번호가 너무 약합니다. 문자, 숫자, 기호를 섞어 길게 만드세요.', 'पासवर्ड बहुत कमज़ोर है। अक्षर, अंक और चिह्न मिलाकर लंबा रखें।', 'Şifre çok zayıf. Harf, rakam ve sembolle daha uzun yapın.'],
    pwWeak: ['Weak', 'Lemah', 'Débil', 'Faible', 'Schwach', 'Fraca', 'Слабый', 'ضعيفة', '弱', '弱い', '약함', 'कमज़ोर', 'Zayıf'],
    pwFair: ['Fair', 'Cukup', 'Regular', 'Moyen', 'Mittel', 'Razoável', 'Средний', 'مقبولة', '一般', '普通', '보통', 'ठीक-ठाक', 'Orta'],
    pwGood: ['Good', 'Bagus', 'Buena', 'Bon', 'Gut', 'Boa', 'Хороший', 'جيدة', '良好', '良い', '좋음', 'अच्छा', 'İyi'],
    pwStrong: ['Strong', 'Kuat', 'Fuerte', 'Fort', 'Stark', 'Forte', 'Надёжный', 'قوية', '强', '強い', '강함', 'मज़बूत', 'Güçlü'],
    okSignup: ['Account created. Check your email and click the confirmation link, then sign in.', 'Akun dibuat. Cek email lalu klik link konfirmasi, setelah itu masuk.', 'Cuenta creada. Revisa tu correo, confirma el enlace y luego inicia sesión.', 'Compte créé. Vérifiez votre e-mail, cliquez sur le lien de confirmation puis connectez-vous.', 'Konto erstellt. Bestätige den Link in deiner E-Mail und melde dich dann an.', 'Conta criada. Confira seu e-mail, clique no link de confirmação e depois entre.', 'Аккаунт создан. Подтвердите ссылку в письме, затем войдите.', 'تم إنشاء الحساب. افتح بريدك وانقر رابط التأكيد ثم سجّل الدخول.', '账号已创建。请查收邮件并点击确认链接，然后登录。', 'アカウントを作成しました。メールの確認リンクをクリックしてからログインしてください。', '계정이 만들어졌습니다. 이메일의 확인 링크를 누른 뒤 로그인하세요.', 'खाता बन गया। ईमेल में पुष्टि लिंक दबाएँ, फिर साइन इन करें।', 'Hesap oluşturuldu. E-postadaki onay bağlantısına tıklayın, sonra giriş yapın.'],
    barGuest: ['Guest mode', 'Mode tamu', 'Modo invitado', 'Mode invité', 'Gastmodus', 'Modo convidado', 'Гостевой режим', 'وضع الضيف', '访客模式', 'ゲストモード', '게스트 모드', 'अतिथि मोड', 'Misafir modu'],
    barSub: ['small limits, no photos', 'jatah kecil, tanpa foto', 'límite bajo, sin fotos', 'limite basse, sans photos', 'kleines Limit, keine Fotos', 'limite baixo, sem fotos', 'малый лимит, без фото', 'حد منخفض، بدون صور', '额度小，无图片', '上限小・写真不可', '한도 낮음, 사진 불가', 'कम सीमा, फ़ोटो नहीं', 'düşük limit, fotoğraf yok'],
    barToday: ['today', 'hari ini', 'hoy', 'aujourd\'hui', 'heute', 'hoje', 'сегодня', 'اليوم', '今天', '今日', '오늘', 'आज', 'bugün'],
    signinUp: ['Sign in / Sign up', 'Masuk / Daftar', 'Entrar / Registrarse', 'Connexion / Inscription', 'Anmelden / Registrieren', 'Entrar / Cadastrar', 'Войти / Регистрация', 'دخول / تسجيل', '登录 / 注册', 'ログイン / 登録', '로그인 / 가입', 'साइन इन / साइन अप', 'Giriş / Kayıt'],
    logout: ['Log out', 'Keluar', 'Cerrar sesión', 'Déconnexion', 'Abmelden', 'Sair', 'Выйти', 'تسجيل الخروج', '退出登录', 'ログアウト', '로그아웃', 'लॉग आउट', 'Çıkış yap'],
    needImg: ['Sending photos is only for signed-in accounts.', 'Kirim foto hanya untuk akun yang sudah masuk.', 'Enviar fotos es solo para cuentas con sesión iniciada.', 'L\'envoi de photos est réservé aux comptes connectés.', 'Fotos senden ist nur mit Konto möglich.', 'Enviar fotos é só para contas conectadas.', 'Отправка фото доступна только вошедшим пользователям.', 'إرسال الصور متاح فقط للحسابات المسجّلة.', '仅登录账号可发送图片。', '写真の送信はログイン済みアカウントのみです。', '사진 전송은 로그인한 계정만 가능합니다.', 'फ़ोटो भेजना सिर्फ़ साइन-इन खातों के लिए है।', 'Fotoğraf göndermek yalnızca giriş yapmış hesaplara açıktır.'],
    pTitle: ['Profile', 'Profil', 'Perfil', 'Profil', 'Profil', 'Perfil', 'Профиль', 'الملف الشخصي', '个人资料', 'プロフィール', '프로필', 'प्रोफ़ाइल', 'Profil'],
    pPhoto: ['Profile photo', 'Foto profil', 'Foto de perfil', 'Photo de profil', 'Profilfoto', 'Foto de perfil', 'Фото профиля', 'صورة الملف', '头像', 'プロフィール写真', '프로필 사진', 'प्रोफ़ाइल फ़ोटो', 'Profil fotoğrafı'],
    pPhotoD: ['PNG, JPEG or WebP', 'PNG, JPEG, atau WebP', 'PNG, JPEG o WebP', 'PNG, JPEG ou WebP', 'PNG, JPEG oder WebP', 'PNG, JPEG ou WebP', 'PNG, JPEG или WebP', 'PNG أو JPEG أو WebP', 'PNG、JPEG 或 WebP', 'PNG・JPEG・WebP', 'PNG, JPEG, WebP', 'PNG, JPEG या WebP', 'PNG, JPEG veya WebP'],
    pName: ['Full name', 'Nama lengkap', 'Nombre completo', 'Nom complet', 'Vollständiger Name', 'Nome completo', 'Полное имя', 'الاسم الكامل', '姓名', '氏名', '이름', 'पूरा नाम', 'Ad soyad'],
    pCall: ['What should the AI call you?', 'AI harus panggil kamu apa?', '¿Cómo debe llamarte la IA?', 'Comment l\'IA doit-elle vous appeler ?', 'Wie soll die KI dich nennen?', 'Como a IA deve te chamar?', 'Как ИИ должен к вам обращаться?', 'بماذا يناديك الذكاء الاصطناعي؟', 'AI 应该怎么称呼你？', 'AIにどう呼ばれたいですか？', 'AI가 뭐라고 불러야 할까요?', 'AI आपको क्या कहकर बुलाए?', 'Yapay zeka sana nasıl hitap etsin?'],
    pEmail: ['Email', 'Email', 'Correo', 'E-mail', 'E-Mail', 'E-mail', 'Эл. почта', 'البريد', '邮箱', 'メール', '이메일', 'ईमेल', 'E-posta'],
    pWork: ['What best describes your work?', 'Pekerjaanmu apa?', '¿A qué te dedicas?', 'Que faites-vous ?', 'Was machst du beruflich?', 'Qual é o seu trabalho?', 'Чем вы занимаетесь?', 'ما طبيعة عملك؟', '你的职业是？', 'お仕事は？', '하시는 일은?', 'आप क्या काम करते हैं?', 'Ne iş yapıyorsun?'],
    pSave: ['Save', 'Simpan', 'Guardar', 'Enregistrer', 'Speichern', 'Salvar', 'Сохранить', 'حفظ', '保存', '保存', '저장', 'सहेजें', 'Kaydet'],
    pSaved: ['Saved', 'Tersimpan', 'Guardado', 'Enregistré', 'Gespeichert', 'Salvo', 'Сохранено', 'تم الحفظ', '已保存', '保存しました', '저장됨', 'सहेजा गया', 'Kaydedildi'],
    pChange: ['Change photo', 'Ganti foto', 'Cambiar foto', 'Changer la photo', 'Foto ändern', 'Trocar foto', 'Сменить фото', 'تغيير الصورة', '更换头像', '写真を変更', '사진 변경', 'फ़ोटो बदलें', 'Fotoğrafı değiştir'],
    pRemove: ['Remove', 'Hapus', 'Quitar', 'Retirer', 'Entfernen', 'Remover', 'Удалить', 'إزالة', '移除', '削除', '삭제', 'हटाएं', 'Kaldır'],
    sTitle: ['Settings', 'Pengaturan', 'Ajustes', 'Paramètres', 'Einstellungen', 'Configurações', 'Настройки', 'الإعدادات', '设置', '設定', '설정', 'सेटिंग्स', 'Ayarlar'],
    sAcc: ['Account', 'Akun', 'Cuenta', 'Compte', 'Konto', 'Conta', 'Аккаунт', 'الحساب', '账号', 'アカウント', '계정', 'खाता', 'Hesap'],
    sLang: ['Language', 'Bahasa', 'Idioma', 'Langue', 'Sprache', 'Idioma', 'Язык', 'اللغة', '语言', '言語', '언어', 'भाषा', 'Dil'],
    sLangD: ['Language of menus and buttons. The AI also answers in this language.', 'Bahasa menu dan tombol. AI juga menjawab dalam bahasa ini.', 'Idioma de menús y botones. La IA también responde en este idioma.', 'Langue des menus et boutons. L\'IA répond aussi dans cette langue.', 'Sprache der Menüs und Buttons. Die KI antwortet ebenfalls darin.', 'Idioma de menus e botões. A IA também responde nele.', 'Язык меню и кнопок. ИИ тоже отвечает на нём.', 'لغة القوائم والأزرار. يجيب الذكاء الاصطناعي بها أيضًا.', '菜单和按钮的语言，AI 也会用此语言回答。', 'メニューとボタンの言語。AIもこの言語で答えます。', '메뉴와 버튼 언어입니다. AI도 이 언어로 답합니다.', 'मेनू और बटन की भाषा। AI भी इसी भाषा में जवाब देगा।', 'Menü ve düğmelerin dili. Yapay zeka da bu dilde yanıtlar.'],
    sNotif: ['Notifications', 'Notifikasi', 'Notificaciones', 'Notifications', 'Benachrichtigungen', 'Notificações', 'Уведомления', 'الإشعارات', '通知', '通知', '알림', 'सूचनाएँ', 'Bildirimler'],
    sAdv: ['Appearance, AI & privacy', 'Tampilan, AI & privasi', 'Apariencia, IA y privacidad', 'Apparence, IA et confidentialité', 'Darstellung, KI & Datenschutz', 'Aparência, IA e privacidade', 'Внешний вид, ИИ и конфиденциальность', 'المظهر والذكاء والخصوصية', '外观、AI 与隐私', '外観・AI・プライバシー', '화면, AI, 개인정보', 'दिखावट, AI और गोपनीयता', 'Görünüm, YZ ve gizlilik'],
    nFin: ['Finished responses', 'Jawaban selesai', 'Respuestas terminadas', 'Réponses terminées', 'Fertige Antworten', 'Respostas concluídas', 'Готовые ответы', 'الردود المكتملة', '回答完成', '回答の完了', '답변 완료', 'जवाब पूरा होने पर', 'Tamamlanan yanıtlar'],
    nFinD: ['Notify me when the AI finishes replying while this tab is in the background. Useful for long tasks.', 'Beri tahu saat AI selesai menjawab ketika tab ini di latar belakang. Berguna untuk tugas panjang.', 'Avisarme cuando la IA termine de responder con esta pestaña en segundo plano.', 'Me prévenir quand l\'IA a fini de répondre alors que l\'onglet est en arrière-plan.', 'Benachrichtigen, wenn die KI fertig ist und der Tab im Hintergrund liegt.', 'Avisar quando a IA terminar de responder com a aba em segundo plano.', 'Уведомлять, когда ИИ закончил ответ, пока вкладка в фоне.', 'أبلغني عند انتهاء الرد والتبويب في الخلفية.', '标签页在后台时，AI 回答完毕后通知我。', 'タブがバックグラウンドのとき、AIの回答完了を通知します。', '탭이 백그라운드일 때 AI 답변이 끝나면 알려줍니다.', 'टैब बैकग्राउंड में हो तो जवाब पूरा होने पर सूचना दें।', 'Sekme arka plandayken yanıt bitince bildir.'],
    nAnn: ['Announcements', 'Pengumuman', 'Anuncios', 'Annonces', 'Ankündigungen', 'Avisos', 'Объявления', 'الإعلانات', '公告', 'お知らせ', '공지', 'घोषणाएँ', 'Duyurular'],
    nAnnD: ['Show news and updates from the owner.', 'Tampilkan kabar dan update dari pemilik.', 'Mostrar novedades del propietario.', 'Afficher les actualités du propriétaire.', 'Neuigkeiten des Betreibers anzeigen.', 'Mostrar novidades do proprietário.', 'Показывать новости от владельца.', 'عرض أخبار وتحديثات المالك.', '显示站长的新闻与更新。', '運営からのお知らせを表示します。', '운영자의 소식과 업데이트를 표시합니다.', 'मालिक की खबरें और अपडेट दिखाएँ।', 'Sahibinden haber ve güncellemeleri göster.'],
    nSound: ['Sound', 'Suara', 'Sonido', 'Son', 'Ton', 'Som', 'Звук', 'الصوت', '提示音', '通知音', '소리', 'ध्वनि', 'Ses'],
    nSoundD: ['Play a soft sound with notifications.', 'Bunyikan suara lembut saat ada notifikasi.', 'Reproducir un sonido suave con las notificaciones.', 'Jouer un son discret avec les notifications.', 'Leisen Ton bei Benachrichtigungen abspielen.', 'Tocar um som suave nas notificações.', 'Тихий звук при уведомлениях.', 'تشغيل صوت هادئ مع الإشعارات.', '通知时播放轻柔提示音。', '通知時にやさしい音を鳴らします。', '알림 시 부드러운 소리를 재생합니다.', 'सूचना के साथ हल्की ध्वनि बजाएँ।', 'Bildirimde yumuşak bir ses çal.'],
    nDenied: ['Notifications are blocked in your browser. Allow them in the site settings.', 'Notifikasi diblokir di browser. Izinkan lewat pengaturan situs.', 'Notificaciones bloqueadas en el navegador. Permítelas en los ajustes del sitio.', 'Notifications bloquées par le navigateur. Autorisez-les dans les réglages du site.', 'Benachrichtigungen im Browser blockiert. In den Website-Einstellungen erlauben.', 'Notificações bloqueadas no navegador. Permita nas configurações do site.', 'Уведомления заблокированы в браузере. Разрешите их в настройках сайта.', 'الإشعارات محظورة في المتصفح. اسمح بها من إعدادات الموقع.', '浏览器已屏蔽通知，请在网站设置中允许。', 'ブラウザで通知がブロックされています。サイト設定で許可してください。', '브라우저에서 알림이 차단되었습니다. 사이트 설정에서 허용하세요.', 'ब्राउज़र में सूचनाएँ बंद हैं। साइट सेटिंग में अनुमति दें।', 'Bildirimler tarayıcıda engelli. Site ayarlarından izin verin.'],
    nDone: ['Your answer is ready', 'Jawabanmu sudah siap', 'Tu respuesta está lista', 'Votre réponse est prête', 'Deine Antwort ist fertig', 'Sua resposta está pronta', 'Ваш ответ готов', 'إجابتك جاهزة', '回答已就绪', '回答の準備ができました', '답변이 준비되었습니다', 'आपका जवाब तैयार है', 'Yanıtın hazır'],
    close: ['Close', 'Tutup', 'Cerrar', 'Fermer', 'Schließen', 'Fechar', 'Закрыть', 'إغلاق', '关闭', '閉じる', '닫기', 'बंद करें', 'Kapat'],
    signedAs: ['Signed in as', 'Masuk sebagai', 'Sesión como', 'Connecté en tant que', 'Angemeldet als', 'Conectado como', 'Вы вошли как', 'مسجّل باسم', '当前登录', 'ログイン中', '로그인 계정', 'इस रूप में साइन इन', 'Giriş yapılan'],
    notSigned: ['Sign in / Account', 'Masuk / Akun', 'Entrar / Cuenta', 'Connexion / Compte', 'Anmelden / Konto', 'Entrar / Conta', 'Вход / Аккаунт', 'دخول / الحساب', '登录 / 账号', 'ログイン / アカウント', '로그인 / 계정', 'साइन इन / खाता', 'Giriş / Hesap']
  };
  // teks statis UI lama (Indonesia -> English)
  const OLD = { 'Akun': 'Account', 'Cari': 'Search', 'Percakapan baru': 'New chat', 'Fitur AI': 'AI features', 'Pengaturan': 'Settings', 'Riwayat chat': 'Chat history', 'Kelola riwayat…': 'Manage history…', 'Terbaru': 'Recent', 'Tutup': 'Close', 'Tutup (Esc)': 'Close (Esc)', 'Tutup menu': 'Close menu', 'Menu': 'Menu', 'Pratinjau': 'Preview', 'Pratinjau kode': 'Code preview', 'Salin kode': 'Copy code', 'Buka di tab baru': 'Open in new tab', 'Muat ulang': 'Reload', 'Gelap': 'Dark', 'Terang': 'Light', 'Tema': 'Theme', 'Warna': 'Color', 'Ukuran': 'Size', 'Kecil': 'Small', 'Sedang': 'Medium', 'Besar': 'Large', 'Efek': 'Effects', 'Privasi': 'Privacy', 'Info': 'About', 'Yang baru': "What's new", 'Ukur koneksi': 'Test connection', 'Kirim (Enter)': 'Send (Enter)', 'Lampirkan foto atau PDF': 'Attach photo or PDF', 'Tahan untuk bicara (Alt+V)': 'Hold to talk (Alt+V)', 'Screenshot (layar / area)': 'Screenshot (screen / area)', 'Buat gambar AI': 'Create AI image', 'Mode gambar AI': 'AI image mode', 'Pilih AI / provider': 'Choose AI / provider', 'Tulis pertanyaan… ( / untuk perintah )': 'Ask anything… ( / for commands )', 'Cari info terbaru di web dulu sebelum menjawab': 'Search the web for the latest info before answering', 'Kepribadian AI': 'AI personality', 'Memori preferensi': 'Preference memory', 'Konteks beberapa tab': 'Multi-tab context', 'Layar yang terlihat': 'Visible screen', 'Pilih area…': 'Select area…', 'Lepas gambar, PDF, atau file teks di sini': 'Drop images, PDFs or text files here', 'Pengaturan & privasi lengkap': 'Full settings & privacy', 'Pintasan keyboard (?)': 'Keyboard shortcuts (?)', 'Jangan simpan riwayat chat': "Don't save chat history", 'Jelaskan, Ringkas, Terjemahkan, Tulis balasan': 'Explain, Summarize, Translate, Write a reply', 'Tampilan: warna, glow, glass, ukuran': 'Appearance: color, glow, glass, size', 'Unduh index.html': 'Download index.html', 'Indikator jaringan': 'Network indicator', 'Transparansi': 'Transparency', 'Kursor': 'Cursor', 'Polos': 'Plain', 'Lebar': 'Wide', 'Tinggi': 'Tall' };

  let lang = 'en';
  const get = (k, v) => { const row = R[k]; if (!row) return k; const i = O.indexOf(lang); let t = row[i]; if (!t) { t = row[0]; if (lang !== 'en' && lang !== 'id') { const x = (tc[lang] || {})[row[0]]; if (x) t = x; else if (tcLoaded) want(row[0]); } } if (v) Object.keys(v).forEach((x) => { t = t.replace('{' + x + '}', v[x]); }); return t; };
  const walk = (root) => {
    // atribut data-i18n untuk elemen baru
    root.querySelectorAll && root.querySelectorAll('[data-i18n]').forEach((e) => { { const t = get(e.dataset.i18n); if (e.textContent !== t) e.textContent = t; } });
    root.querySelectorAll && root.querySelectorAll('[data-i18n-ph]').forEach((e) => { const t = get(e.dataset.i18nPh); if (e.placeholder !== t) e.placeholder = t; });
  };
  // ---------- terjemahan otomatis seluruh UI lama (sumber: Indonesia) ----------
  const IDW = new Set(('yang dan untuk dengan tidak ini itu atau dari ke di pada akan sudah belum bisa gagal ada silakan mohon coba buka tutup simpan hapus kirim pilih salin unduh muat ulang baru lama semua kosong tulis jawab pertanyaan halaman gambar suara kamu mu anda berhasil dibatalkan menyusun mencari sedang memuat tampilkan sembunyikan batal lanjut kembali pengaturan akun cari percakapan riwayat chat tema warna ukuran kecil sedang besar gelap terang efek privasi info tab layar foto lampirkan kunci aktif nonaktif nyalakan matikan otomatis manual bahasa nama ganti pakai gunakan ketik pesan balasan jawaban soal tugas catatan memori ingat lupa bantuan fitur lihat lainnya selesai tunggu sebentar kesalahan error terjadi periksa koneksi internet jaringan server kode ringkas terjemah jelaskan tulis buat bikin hapus edit ubah perbaiki tambah tambahkan kurangi batas jatah hari ini besok minggu bulan tahun jam menit detik lalu baru saja belum pernah selalu kadang sering jarang hanya saja juga lagi masih telah sedang pernah harus boleh dapat mau ingin perlu tanpa dalam oleh bagi antara sampai hingga sejak karena sehingga jika kalau supaya agar maka tetapi namun lalu kemudian setelah sebelum saat ketika'+' pengguna tamu masuk daftar keluar kirim terkirim pratinjau unduh buka tutup siap model penyedia kunci tombol menu pintasan keyboard baca teks dokumen berkas file simpan tersimpan dihapus ditambahkan dibuat diubah dikirim diterima dibaca ditulis dilihat dipilih dicari ditemukan hasil sumber tautan situs web internet cuaca kurs berita harga terbaru').split(/\s+/));
  const SKIP = 'SCRIPT,STYLE,TEXTAREA,CODE,PRE,SVG,NOSCRIPT,INPUT,SELECT'.split(',');
  const NOTR = '#lgbGate,#lgbSet,#lgbBar,#lgbToasts,[data-i18n],[data-notr],.hljs,.katex';
  const isId = (t) => { const w = t.toLowerCase().match(/[a-zà-ÿ]+/g) || []; return w.some((x) => IDW.has(x)); };
  let tc = {}, tcLoaded = false, tcTimer = 0, pend = new Set(), inflight = false, failUntil = 0;
  const tr = () => (tc[lang] || (tc[lang] = {}));
  async function tcLoad() { try { tc = (await chrome.storage.local.get({ i18nc: {} })).i18nc || {}; } catch (e) { tc = {}; } tcLoaded = true; }
  const tcSave = () => { clearTimeout(tcTimer); tcTimer = setTimeout(() => { try { chrome.storage.local.set({ i18nc: tc }); } catch (e) { /* abaikan */ } }, 1500); };
  const want = (src) => { if (!tcLoaded || lang === 'id' || tr()[src] || (OLD[src] && lang === 'en')) return; pend.add(src); kick(); };
  const lookup = (src) => (lang === 'en' && OLD[src]) || tr()[src] || '';
  function kick() { clearTimeout(kick.t); kick.t = setTimeout(flush, 900); }
  async function flush() {
    if (inflight || !pend.size || Date.now() < failUntil || lang === 'id') return;
    const L = lang, items = [...pend].filter((x) => !tr()[x]).slice(0, 90); pend = new Set([...pend].filter((x) => !items.includes(x)));
    if (!items.length) return;
    inflight = true;
    const obj = {}; items.forEach((t, i) => { obj[i] = t; });
    try {
      const r = await fetch('/api/p/groq/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer server', 'x-lgb-i18n': '1' },
        body: JSON.stringify({ model: 'llama-3.1-8b-instant', temperature: 0, max_tokens: 3400, response_format: { type: 'json_object' }, messages: [
          { role: 'system', content: 'You translate app UI strings into ' + (AI_NAME[L] || 'English') + '. The source is Indonesian or English. Keep product names (Los Gk Bawel AI, Groq, Ollama, OpenRouter, Notion, Google, Supabase), numbers, emoji, URLs, keyboard keys, HTML tags and {placeholders} exactly. Keep the same tone and brevity. Reply with ONLY a JSON object mapping each key to its translation.' },
          { role: 'user', content: JSON.stringify(obj) }] }) });
      if (!r.ok) { failUntil = Date.now() + 60000; throw new Error('x' + r.status); }
      const j = await r.json(); let txt = (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '';
      txt = txt.replace(/^```(?:json)?/i, '').replace(/```$/, '').trim(); const out = JSON.parse(txt);
      if (L === lang) { items.forEach((t, i) => { if (typeof out[i] === 'string' && out[i].trim()) (tc[L] || (tc[L] = {}))[t] = out[i]; }); tcSave(); soon(true); }
    } catch (e) { /* diam-diam; dicoba lagi nanti */ }
    inflight = false; if (pend.size) kick();
  }
  const orig = new WeakMap();
  function eachText(root, fn) {
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode(n) {
      const p = n.parentElement; if (!p || SKIP.includes(p.tagName) || p.closest(NOTR)) return NodeFilter.FILTER_REJECT;
      const ch = p.closest('#chat'); if (ch && !p.closest('.note,.err,.sys')) return NodeFilter.FILTER_REJECT;
      return /[A-Za-zÀ-ÿ]{2}/.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; } });
    let n; while ((n = w.nextNode())) fn(n);
  }
  function oldUI() {
    const back = lang === 'id';
    eachText(document.body, (n) => {
      let rec = orig.get(n);
      if (!rec) { rec = { o: n.nodeValue, t: null }; orig.set(n, rec); }
      else if (n.nodeValue !== rec.t && n.nodeValue !== rec.o) { rec.o = n.nodeValue; rec.t = null; } // diubah aplikasi: sumber baru
      const o = rec.o, base = o.trim(); if (!base) return;
      if (back) { if (n.nodeValue !== o) n.nodeValue = o; rec.t = null; return; }
      if (!(OLD[base] || isId(base) || tr()[base])) { if (n.nodeValue !== o) n.nodeValue = o; return; }
      const t = lookup(base);
      if (t) { const v = o.replace(base, t); if (n.nodeValue !== v) n.nodeValue = v; rec.t = v; } else { if (n.nodeValue !== o) n.nodeValue = o; want(base); }
    });
    document.querySelectorAll('[title],[placeholder],[aria-label]').forEach((e) => {
      if (e.closest(NOTR)) return;
      ['title', 'placeholder', 'aria-label'].forEach((a) => {
        const v = e.getAttribute(a); if (!v) return;
        const o = orig.get(e) || {}; if (!(a in o) || (o['_' + a] !== undefined && o['_' + a] !== v)) { o[a] = v; } orig.set(e, o);
        const base = o[a].trim(); if (!(OLD[base] || isId(base) || tr()[base])) return;
        if (back) { e.setAttribute(a, o[a]); o['_' + a] = o[a]; return; }
        const t = lookup(base); if (t) { e.setAttribute(a, t); o['_' + a] = t; } else want(base);
      });
    });
    document.title && 0;
  }
  let applyT = 0;
  const apply = (emit) => {
    document.documentElement.lang = lang; document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    walk(document); oldUI();
    if (emit === true) window.dispatchEvent(new CustomEvent('lgb-lang', { detail: lang }));
  };
  const soon = (emit) => { clearTimeout(applyT); applyT = setTimeout(() => apply(emit === true), 120); };
  const addKeys = (o) => { Object.keys(o).forEach((k) => { if (!R[k]) R[k] = o[k]; }); };
  addKeys({
    role: ['Role', 'Peran'], roleOwner: ['Owner', 'Owner (pembuat)'], roleAdmin: ['Admin', 'Admin'], roleMember: ['Member', 'Anggota'],
    resetPw: ['Reset password', 'Reset password'], resetPwD: ['We email you a link to set a new password.', 'Kami kirim link ke emailmu untuk membuat password baru.'],
    resetSent: ['Reset link sent. Check your email.', 'Link reset terkirim. Cek emailmu.'], resetFail: ['Could not send the email. Try again.', 'Gagal mengirim email. Coba lagi.']
  });
  window.LGB_I18N = {
    addKeys,
    LANGS, T: get, get lang() { return lang; }, aiName: () => AI_NAME[lang] || 'English',
    async set(l) { if (!O.includes(l)) l = 'en'; lang = l; try { await chrome.storage.local.set({ uiLang: l }); } catch (e) { /* abaikan */ } apply(true); },
    apply: () => apply(false)
  };
  window.T = get;
  (async () => {
    await tcLoad();
    try { const s = await chrome.storage.local.get({ uiLang: 'en' }); lang = O.includes(s.uiLang) ? s.uiLang : 'en'; } catch (e) { /* abaikan */ }
    apply(true);
    new MutationObserver((m) => { const inChat = (t) => { const e = t.nodeType === 1 ? t : t.parentElement; return !!(e && e.closest && e.closest('#chat') && !e.closest('.note,.err,.sys')); }; if (m.some((x) => !inChat(x.target) && (x.addedNodes.length || x.type === 'characterData'))) soon(); }).observe(document.body, { childList: true, subtree: true, characterData: true });
  })();
})();
