// Profil (foto, nama), Pengaturan (bahasa, notifikasi) dan notifikasi/pengumuman.
(function () {
  if (!window.LGB_WEB) return;
  const $ = (s, r) => (r || document).querySelector(s);
  const T = (k) => (window.T ? window.T(k) : k);
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const st = { get: (o) => chrome.storage.local.get(o), set: (o) => chrome.storage.local.set(o) };
  let prof = { name: '', call: '', work: '', avatar: '' }, ov = null, tab = 'acct';
  let nset = { fin: false, ann: true, snd: true };
  let role = { role: 'user', name: '' }, roster = { owner: 'Jeremy Ibnu Latif Putra Iman', admins: [] };
  const CK = '<svg class="ck" width="16" height="16" viewBox="0 0 24 24" aria-label="verified"><path fill="#1d9bf0" d="M22.25 12c0-1.43-.88-2.67-2.19-3.34.46-1.39.2-2.9-.81-3.91s-2.52-1.27-3.91-.81c-.67-1.31-1.91-2.19-3.34-2.19s-2.67.88-3.34 2.19c-1.39-.46-2.9-.2-3.91.81s-1.27 2.52-.81 3.91C2.63 9.33 1.75 10.57 1.75 12s.88 2.67 2.19 3.34c-.46 1.39-.2 2.9.81 3.91s2.52 1.26 3.91.81c.67 1.31 1.91 2.19 3.34 2.19s2.67-.88 3.34-2.19c1.39.45 2.9.2 3.91-.81s1.27-2.52.81-3.91c1.31-.67 2.19-1.91 2.19-3.34z"/><path fill="#fff" d="M10.6 16.6l-3.3-3.3 1.4-1.4 1.9 1.9 4.7-4.7 1.4 1.4z"/></svg>';
  window.LGB_CHECK = CK;

  const clean = (t, n) => String(t || '').replace(/[\r\n"]+/g, ' ').trim().slice(0, n);
  function userLine() {
    window.LGB_ROLES_LINE = 'Info sistem (terpercaya): Owner = ' + roster.owner + '.' + (roster.admins.length ? ' Admin = ' + roster.admins.map((x) => clean(x, 60)).join(', ') + '.' : ' Belum ada admin.');
    const me = role.role === 'owner' ? 'Pengguna yang sedang mengobrol ADALAH OWNER (' + roster.owner + '), terverifikasi sistem. ' : role.role === 'admin' ? 'Pengguna yang sedang mengobrol adalah ADMIN bernama ' + clean(role.name, 60) + ', terverifikasi sistem. ' : '';
    window.LGB_USER_LINE = me + (prof.call ? 'Panggil pengguna dengan nama "' + clean(prof.call, 40) + '" bila terasa natural.' + (prof.work ? ' Pekerjaan/profil pengguna: ' + clean(prof.work, 60) + '.' : '') : ''); }

  async function load() {
    const s = await st.get({ lgbProfile: null, lgbNotif: null });
    if (s.lgbProfile) prof = Object.assign(prof, s.lgbProfile);
    if (s.lgbNotif) nset = Object.assign(nset, s.lgbNotif);
    userLine(); paint();
  }
  async function saveProf(extra) {
    prof = Object.assign(prof, extra || {}); userLine();
    await st.set({ lgbProfile: prof }); paint();
    // simpan juga di server akun (user_metadata) supaya ikut ke perangkat lain; gagal pun tidak masalah
    try {
      const s = await Acct.session();
      if (s && s.kind !== 'google') { const c = await Acct.cfg(); await fetch(c.url + '/auth/v1/user', { method: 'PUT', headers: { apikey: c.key, Authorization: 'Bearer ' + s.access_token, 'Content-Type': 'application/json' }, body: JSON.stringify({ data: { full_name: prof.name, call: prof.call, work: prof.work, avatar: prof.avatar } }) }); }
    } catch (e) { /* abaikan */ }
  }
  async function pullRemote() {
    try {
      const s = await Acct.session(); if (!s || s.kind === 'google') return;
      const c = await Acct.cfg();
      const r = await fetch(c.url + '/auth/v1/user', { headers: { apikey: c.key, Authorization: 'Bearer ' + s.access_token } });
      if (!r.ok) return; const m = (await r.json()).user_metadata || {};
      const next = { name: prof.name || m.full_name || m.name || '', call: prof.call || m.call || '', work: prof.work || m.work || '', avatar: prof.avatar || m.avatar || m.avatar_url || m.picture || '' };
      if (JSON.stringify(next) !== JSON.stringify(prof)) { prof = next; userLine(); await st.set({ lgbProfile: prof }); paint(); }
    } catch (e) { /* abaikan */ }
  }

  async function loadRole() {
    try { const r = await fetch('/api/roles'); if (r.ok) { const j = await r.json(); roster = { owner: j.owner || roster.owner, admins: j.admins || [] }; } } catch (e) { /* abaikan */ }
    try { const r = await fetch('/api/me'); if (r.ok) { const j = await r.json(); role = { role: j.role || 'user', name: j.name || '' }; } } catch (e) { /* abaikan */ }
    userLine(); paint();
  }
  const roleLabel = () => (role.role === 'owner' ? T('roleOwner') : role.role === 'admin' ? T('roleAdmin') : T('roleMember'));

  // ---------- sidebar ----------
  window.lgbPaintAcct = paint;
  function paint() {
    const nm = $('#sAcctName'), av = $('#sAv'); if (!nm || !av) return;
    const u = window.lgbSession && window.lgbSession();
    if (!u) return;
    const email = (u.user && u.user.email) || '';
    const shown = prof.name || (role.role === 'owner' ? roster.owner : role.role === 'admin' ? role.name : '') || prof.call || email.split('@')[0] || 'Account';
    nm.innerHTML = esc(shown) + (role.role !== 'user' ? CK : '');
    if (prof.avatar) { av.textContent = ''; av.style.backgroundImage = 'url("' + prof.avatar.replace(/"/g, '') + '")'; av.classList.add('img'); }
    else { av.style.backgroundImage = ''; av.classList.remove('img'); av.textContent = (shown[0] || '?').toUpperCase(); }
  }
  setInterval(() => { try { paint(); } catch (e) { /* abaikan */ } }, 2500);

  // ---------- modal ----------
  const EXTRA = [];
  window.lgbRegisterPane = (id, key, icon, fn) => { if (!EXTRA.some((x) => x.id === id)) EXTRA.push({ id, key, icon, fn }); };
  const navList = () => [['acct', 'sAcc', 'user'], ['lang', 'sLang', 'globe'], ['notif', 'sNotif', 'bell']].concat(EXTRA.map((x) => [x.id, x.key, 'x_' + x.id]), [['adv', 'sAdv', 'settings']]);
  const ICONS = { user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>', globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>', bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8M10 21a2 2 0 0 0 4 0"/>', settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>' };
  const svg = (n) => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + (ICONS[n] || ((EXTRA.find((x) => 'x_' + x.id === n) || {}).icon) || '') + '</svg>';

  function open(t) {
    tab = t || 'acct';
    if (!ov) {
      ov = document.createElement('div'); ov.id = 'lgbSet'; ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-modal', 'true');
      ov.addEventListener('mousedown', (e) => { if (e.target === ov) close(); });
      document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && ov && !ov.hidden) close(); });
      document.body.appendChild(ov);
    }
    ov.hidden = false; render();
  }
  function close() { if (ov) ov.hidden = true; }
  window.lgbOpenSettings = open;
  window.addEventListener('lgb-lang', () => { if (ov && !ov.hidden) render(); });

  function render() {
    const u = window.lgbSession && window.lgbSession();
    ov.innerHTML = '<div class="scard"><div class="shead"><strong>' + esc(T('sTitle')) + '</strong><button type="button" class="sx" aria-label="' + esc(T('close')) + '">✕</button></div>' +
      '<div class="sbody"><nav class="snav">' + navList().map((n) => '<button type="button" data-t="' + n[0] + '" class="' + (n[0] === tab ? 'on' : '') + '">' + svg(n[2]) + '<span>' + esc(T(n[1])) + '</span></button>').join('') + '</nav><div class="spane" id="sPane"></div></div></div>';
    $('.sx', ov).onclick = close;
    ov.querySelectorAll('.snav button').forEach((b) => { b.onclick = () => { if (b.dataset.t === 'adv') { close(); try { chrome.runtime.openOptionsPage(); } catch (e) { /* abaikan */ } return; } tab = b.dataset.t; render(); }; });
    const p = $('#sPane', ov);
    const ex = EXTRA.find((x) => x.id === tab);
    if (tab === 'acct') acctPane(p, u); else if (tab === 'lang') langPane(p); else if (ex) ex.fn(p); else notifPane(p);
  }

  function acctPane(p, u) {
    const email = u && u.user ? u.user.email : '';
    if (!u) { p.innerHTML = '<h3>' + esc(T('pTitle')) + '</h3><p class="sd">' + esc(T('gSub')) + '</p><button type="button" class="sbtn pri" id="pIn">' + esc(T('signinUp')) + '</button>'; $('#pIn', p).onclick = () => { close(); window.lgbOpenGate && window.lgbOpenGate(); }; return; }
    const ini = ((prof.name || email || '?')[0] || '?').toUpperCase();
    p.innerHTML = '<h3>' + esc(T('pTitle')) + '</h3>' +
      '<div class="srow"><div><b>' + esc(T('pPhoto')) + '</b><small>' + esc(T('pPhotoD')) + '</small></div><div class="pav-wrap"><button type="button" class="pav" id="pAv" title="' + esc(T('pChange')) + '"' + (prof.avatar ? ' style="background-image:url(\'' + prof.avatar.replace(/['"\\]/g, '') + '\')"' : '') + '>' + (prof.avatar ? '' : esc(ini)) + '</button><input type="file" id="pFile" accept="image/png,image/jpeg,image/webp" hidden>' + (prof.avatar ? '<button type="button" class="sbtn" id="pRm">' + esc(T('pRemove')) + '</button>' : '') + '</div></div>' +
      '<div class="srow"><b>' + esc(T('role')) + '</b><span class="sval rolechip r-' + role.role + '">' + esc(roleLabel()) + (role.role !== 'user' ? CK : '') + '</span></div>' +
      '<label class="srow"><b>' + esc(T('pName')) + '</b><input id="pName" maxlength="60" value="' + esc(prof.name) + '"></label>' +
      '<label class="srow"><b>' + esc(T('pCall')) + '</b><input id="pCall" maxlength="40" value="' + esc(prof.call) + '"></label>' +
      '<label class="srow"><b>' + esc(T('pWork')) + '</b><input id="pWork" maxlength="60" value="' + esc(prof.work) + '"></label>' +
      '<div class="srow"><b>' + esc(T('pEmail')) + '</b><span class="sval">' + esc(email) + '</span></div>' +
      '<div class="srow"><div><b>' + esc(T('resetPw')) + '</b><small>' + esc(T('resetPwD')) + '</small></div><button type="button" class="sbtn" id="pReset">' + esc(T('resetPw')) + '</button></div>' +
      '<div class="sact"><button type="button" class="sbtn pri" id="pSave">' + esc(T('pSave')) + '</button><span class="sok" id="pOk"></span><span class="sgrow"></span><button type="button" class="sbtn dng" id="pOut">' + esc(T('logout')) + '</button></div>';
    $('#pAv', p).onclick = () => $('#pFile', p).click();
    $('#pFile', p).onchange = async (e) => { const f = e.target.files[0]; if (!f) return; try { await saveProf({ avatar: await square(f, 192) }); render(); } catch (er) { /* abaikan */ } };
    const rm = $('#pRm', p); if (rm) rm.onclick = async () => { await saveProf({ avatar: '' }); render(); };
    $('#pSave', p).onclick = async () => { await saveProf({ name: clean($('#pName', p).value, 60), call: clean($('#pCall', p).value, 40), work: clean($('#pWork', p).value, 60) }); $('#pOk', p).textContent = '✓ ' + T('pSaved'); setTimeout(() => { const o = $('#pOk', p); if (o) o.textContent = ''; }, 2000); };
    $('#pReset', p).onclick = async (e) => {
      const b = e.currentTarget; b.disabled = true;
      try { const c = await Acct.cfg(); const r = await fetch(c.url + '/auth/v1/recover', { method: 'POST', headers: { apikey: c.key, 'Content-Type': 'application/json' }, body: JSON.stringify({ email }) }); $('#pOk', p).textContent = r.ok ? '✓ ' + T('resetSent') : T('resetFail'); } catch (er) { $('#pOk', p).textContent = T('resetFail'); }
      setTimeout(() => { b.disabled = false; const o = $('#pOk', p); if (o) o.textContent = ''; }, 5000);
    };
    $('#pOut', p).onclick = () => { close(); window.lgbSignOut && window.lgbSignOut(); };
  }
  function square(file, n) {
    return new Promise((res, rej) => {
      const img = new Image(), url = URL.createObjectURL(file);
      img.onload = () => { const c = document.createElement('canvas'); c.width = c.height = n; const m = Math.min(img.width, img.height); c.getContext('2d').drawImage(img, (img.width - m) / 2, (img.height - m) / 2, m, m, 0, 0, n, n); URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', 0.86)); };
      img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('img')); }; img.src = url;
    });
  }
  function langPane(p) {
    const cur = window.LGB_I18N ? window.LGB_I18N.lang : 'en';
    p.innerHTML = '<h3>' + esc(T('sLang')) + '</h3><p class="sd">' + esc(T('sLangD')) + '</p><div class="langs">' + window.LGB_I18N.LANGS.map((l) => '<button type="button" data-l="' + l[0] + '" class="' + (l[0] === cur ? 'on' : '') + '">' + esc(l[1]) + '</button>').join('') + '</div>';
    p.querySelectorAll('.langs button').forEach((b) => { b.onclick = () => window.LGB_I18N.set(b.dataset.l); });
  }
  function tog(id, label, desc, on) { return '<div class="srow tg"><div><b>' + esc(label) + '</b><small>' + esc(desc) + '</small></div><button type="button" role="switch" aria-checked="' + on + '" class="sw' + (on ? ' on' : '') + '" id="' + id + '"><i></i></button></div>'; }
  function notifPane(p) {
    p.innerHTML = '<h3>' + esc(T('sNotif')) + '</h3>' + tog('nFin', T('nFin'), T('nFinD'), nset.fin) + tog('nAnn', T('nAnn'), T('nAnnD'), nset.ann) + tog('nSnd', T('nSound'), T('nSoundD'), nset.snd) + '<p class="sd warn" id="nWarn" hidden></p>';
    const flip = async (k, el) => {
      let v = !nset[k];
      if (k === 'fin' && v) {
        let perm = 'denied'; try { perm = Notification.permission === 'default' ? await Notification.requestPermission() : Notification.permission; } catch (e) { /* abaikan */ }
        if (perm !== 'granted') { v = false; const w = $('#nWarn', p); w.textContent = T('nDenied'); w.hidden = false; }
      }
      nset[k] = v; await st.set({ lgbNotif: nset }); el.classList.toggle('on', v); el.setAttribute('aria-checked', v);
      if (v && k === 'snd') beep();
    };
    $('#nFin', p).onclick = (e) => flip('fin', e.currentTarget); $('#nAnn', p).onclick = (e) => flip('ann', e.currentTarget); $('#nSnd', p).onclick = (e) => flip('snd', e.currentTarget);
  }

  // ---------- notifikasi ----------
  let ac = null;
  function beep() {
    if (!nset.snd) return;
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)();
      const o = ac.createOscillator(), g = ac.createGain(); o.type = 'sine'; o.frequency.setValueAtTime(880, ac.currentTime); o.frequency.exponentialRampToValueAtTime(1320, ac.currentTime + 0.12);
      g.gain.setValueAtTime(0.0001, ac.currentTime); g.gain.exponentialRampToValueAtTime(0.12, ac.currentTime + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + 0.28);
      o.connect(g); g.connect(ac.destination); o.start(); o.stop(ac.currentTime + 0.3);
    } catch (e) { /* abaikan */ }
  }
  window.addEventListener('lgb-done', () => {
    if (!nset.fin || !document.hidden) return;
    try { if (Notification.permission === 'granted') { const n = new Notification('Los Gk Bawel AI', { body: T('nDone'), icon: 'icons/icon192.png', tag: 'lgb-done' }); n.onclick = () => { window.focus(); n.close(); }; beep(); } } catch (e) { /* abaikan */ }
  });
  function toast(title, body, id) {
    let box = $('#lgbToasts'); if (!box) { box = document.createElement('div'); box.id = 'lgbToasts'; document.body.appendChild(box); }
    const el = document.createElement('div'); el.className = 'ltoast';
    el.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + ICONS.bell + '</svg><div><b>' + esc(title) + '</b><span>' + esc(body) + '</span></div><button type="button" aria-label="' + esc(T('close')) + '">✕</button>';
    el.querySelector('button').onclick = () => el.remove(); box.appendChild(el); setTimeout(() => el.remove(), 14000); beep();
    try { if (document.hidden && Notification.permission === 'granted') new Notification(title, { body, icon: 'icons/icon192.png', tag: 'lgb-ann-' + id }); } catch (e) { /* abaikan */ }
  }
  async function poll() {
    if (!nset.ann) return;
    try {
      const r = await fetch('/api/notify'); if (!r.ok) return;
      const j = await r.json(); const seen = (await st.get({ lgbAnnSeen: 0 })).lgbAnnSeen || 0;
      const fresh = (j.items || []).filter((x) => x.id > seen).sort((a, b) => a.id - b.id);
      fresh.forEach((x) => toast(x.title, x.body, x.id));
      if (fresh.length) await st.set({ lgbAnnSeen: fresh[fresh.length - 1].id });
    } catch (e) { /* abaikan */ }
  }

  // ---------- pasang ke sidebar ----------
  function wire() {
    const a = $('#sAcct'), g = $('#sSet'); if (!a || !g) return setTimeout(wire, 400);
    a.addEventListener('click', (e) => { e.stopImmediatePropagation(); e.preventDefault(); try { document.getElementById('sClose') && matchMedia('(max-width:860px)').matches && document.getElementById('sClose').click(); } catch (x) { /* abaikan */ } open('acct'); }, true);
    g.addEventListener('click', (e) => { e.stopImmediatePropagation(); e.preventDefault(); open('lang'); }, true);
  }
  (async () => { await load(); wire(); setTimeout(() => { pullRemote(); poll(); loadRole(); }, 2500); setInterval(poll, 300000); setInterval(loadRole, 300000); window.addEventListener('lgb-signedin', pullRemote); })();
})();
