// Tema bersama: halaman Atur memakai warna/mode/glow yang sama persis dengan popup
(function () {
  const PAL = {
    ungu: ['#7c3aed', '#2563eb'], biru: ['#2563eb', '#06b6d4'], cyan: ['#06b6d4', '#3b82f6'], hijau: ['#16a34a', '#0d9488'],
    pink: ['#ec4899', '#8b5cf6'], merah: ['#ef4444', '#be123c'], oranye: ['#f97316', '#ef4444'], emas: ['#f59e0b', '#ea580c'], hitam: ['#3f3f46', '#18181b']
  };
  const root = document.documentElement;
  const valid = (v) => /^#[0-9a-f]{6}$/i.test(v);
  function hexToHsl(hex) {
    const r = parseInt(hex.slice(1, 3), 16) / 255, g = parseInt(hex.slice(3, 5), 16) / 255, b = parseInt(hex.slice(5, 7), 16) / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
    let h = 0;
    if (d) { if (max === r) h = ((g - b) / d) % 6; else if (max === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; }
    h = Math.round(h * 60); if (h < 0) h += 360;
    const l = (max + min) / 2, s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
    return [h, Math.round(s * 100), Math.round(l * 100)];
  }
  function hslToHex(h, s, l) {
    s /= 100; l /= 100;
    const k = (n) => (n + h / 30) % 12, a = s * Math.min(l, 1 - l);
    const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    const x = (v) => Math.round(v * 255).toString(16).padStart(2, '0');
    return '#' + x(f(0)) + x(f(8)) + x(f(4));
  }
  async function apply() {
    const s = await chrome.storage.local.get({ popupAccent: 'hitam', themeMode: 'dark', customColor: '#7c3aed', glow: 30 });
    const custom = valid(s.customColor) ? s.customColor : '#7c3aed';
    const [h, sat, l] = hexToHsl(custom);
    const pal = s.popupAccent === 'custom' ? [custom, hslToHex((h + 40) % 360, sat, l)] : (PAL[s.popupAccent] || PAL.hitam);
    root.style.setProperty('--accent', pal[0]);
    root.style.setProperty('--accent2', pal[1]);
    root.style.setProperty('--g', Math.min(100, Math.max(0, Number(s.glow) || 0)));
    if (s.themeMode === 'light' || s.themeMode === 'dark') root.dataset.theme = s.themeMode; else delete root.dataset.theme;
    window.dispatchEvent(new CustomEvent('lgb-theme', { detail: s }));
  }
  chrome.storage.onChanged.addListener((c) => { if (c.popupAccent || c.themeMode || c.customColor || c.glow) apply(); });
  window.LGB_PALETTE = PAL;
  apply();
})();
