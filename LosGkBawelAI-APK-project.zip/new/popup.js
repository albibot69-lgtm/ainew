// Los Gk Bawel AI v6 - popup
const chat = document.getElementById('chat');
const form = document.getElementById('form');
const input = document.getElementById('input');
const sendBtn = document.getElementById('send');
const usePage = document.getElementById('usePage');
const modelName = document.getElementById('modelName');
const strip = document.getElementById('strip');
const fileInput = document.getElementById('file');
const quizBtn = document.getElementById('quiz');
const ind = document.getElementById('ind');
const qchips = document.getElementById('qchips');
const sheets = document.getElementById('sheets');

const MAX_IMAGES = 4;
const ICONS = {
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
  retry: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></svg>',
  down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg>',
  bulb: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.5c.8.8 1 1.5 1 2.5h6c0-1 .2-1.7 1-2.5A6 6 0 0 0 12 3z"/></svg>',
  list: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/></svg>',
  globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>',
  reply: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 6 6v3"/></svg>',
  star: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/></svg>'
};
const COPY_ICON = ICONS.copy;

let history = [];   // { role, content, images }
let pending = [];   // gambar yang akan dikirim (dataURL)
let docs = [];      // PDF terlampir: { name, text, sent }
let tabCtx = [];    // konteks multi-tab: { title, url, text, sent }
let log = [];       // isi tampilan chat yang disimpan
let current = null; // permintaan yang sedang jalan { ctrl }
let lastMeta = {};  // opsi permintaan terakhir (untuk Ulangi)
let lastQuiz = null;
let imageMode = false;
let imgSize = 'square';
let S = Object.assign({}, DEFAULT_SETTINGS);
const ctxSent = new Set();
const ready = ensureDefaults();

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let persistT = 0;
function persistNow() {
  persistT = 0;
  if (S.noHistory) { chrome.storage.local.remove(['chatLog', 'chatHistory']).catch(() => {}); return; }
  // gambar hasil AI disimpan di log saja (bukan di history yang dikirim ke AI)
  chrome.storage.local.set({ chatLog: log, chatHistory: history, draft: input.value }).catch(() => {});
}
// Simpan digabung (debounce): menulis seluruh riwayat berulang kali itu berat. Dipaksa tulis saat popup/tab ditutup.
function persist() { if (!persistT) persistT = setTimeout(persistNow, 350); }
const flushPersist = () => { if (persistT) { clearTimeout(persistT); persistNow(); } };
window.addEventListener('pagehide', flushPersist);
document.addEventListener('visibilitychange', () => { if (document.hidden) flushPersist(); });
const save = persist;

// ---------- Popover (menu kecil) dengan animasi ----------
// Tutup popup dengan animasi (hanya berlaku untuk Esc / tombol ×; klik di luar popup ditutup langsung oleh Chrome)
let popupClosing = false;
function closePopup() {
  if (popupClosing) return;
  popupClosing = true;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { window.close(); return; }
  document.body.classList.add('closing');
  setTimeout(() => window.close(), 180);
}
function closePops(except) {
  document.querySelectorAll('.pop.open').forEach((p) => { if (p !== except) p.classList.remove('open'); });
}
function togglePop(el) {
  const open = !el.classList.contains('open');
  closePops(el);
  el.classList.toggle('open', open);
  return open;
}
document.addEventListener('click', (e) => {
  if (e.target.closest('.pop, [data-pop], .sheet')) return;
  closePops();
});

// ---------- Sheet / dialog dengan animasi ----------
function sheet(html, cls) {
  const o = document.createElement('div');
  o.className = 'sheet';
  o.innerHTML = '<div class="card-sheet ' + (cls || '') + '">' + html + '</div>';
  sheets.appendChild(o);
  requestAnimationFrame(() => requestAnimationFrame(() => o.classList.add('on')));
  o.close = () => { if (o._closed) return; o._closed = true; o.classList.remove('on'); setTimeout(() => o.remove(), 260); if (o.onclose) o.onclose(); };
  o.addEventListener('mousedown', (e) => { if (e.target === o) o.close(); });
  return o;
}
function topSheet() { const l = sheets.querySelectorAll('.sheet.on'); return l[l.length - 1]; }
// ---------- Pengaturan & tampilan ----------
const tw = document.getElementById('tw');
const th = document.getElementById('th');
const to = document.getElementById('to');
const ts = document.getElementById('ts');
const tunePanel = document.getElementById('tunePanel');
const tglow = document.getElementById('tglow');
const tauto = document.getElementById('tauto');
const tnohist = document.getElementById('tnohist');
const thl = document.getElementById('thl');
const tlite = document.getElementById('tlite');
const tdisguise = document.getElementById('tdisguise');
const ttb = document.getElementById('ttb');
const provSel = document.getElementById('provSel');
const cpNative = document.getElementById('cpNative');
const cpHex = document.getElementById('cpHex');
const cpHue = document.getElementById('cpHue');
const cpLight = document.getElementById('cpLight');
const root = document.documentElement;

const PALETTE = {
  ungu: ['#7c3aed', '#2563eb'],
  biru: ['#2563eb', '#06b6d4'],
  cyan: ['#06b6d4', '#3b82f6'],
  hijau: ['#16a34a', '#0d9488'],
  pink: ['#ec4899', '#8b5cf6'],
  merah: ['#ef4444', '#be123c'],
  oranye: ['#f97316', '#ef4444'],
  emas: ['#f59e0b', '#ea580c'],
  hitam: ['#3f3f46', '#18181b']
};

let view = { w: 380, h: 520, o: 100, stealth: false, accent: 'ungu', mode: 'auto', glow: 30, glass: 'off', custom: '#7c3aed' };

// ---- helper warna (hex <-> hsl) ----
const validHex = (v) => /^#[0-9a-f]{6}$/i.test(v);
function hexToHsl(hex) {
  const r = parseInt(hex.slice(1, 3), 16) / 255, g = parseInt(hex.slice(3, 5), 16) / 255, b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
  let h = 0;
  if (d) {
    if (max === r) h = ((g - b) / d) % 6;
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
  }
  h = Math.round(h * 60); if (h < 0) h += 360;
  const l = (max + min) / 2;
  const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
  return [h, Math.round(s * 100), Math.round(l * 100)];
}
function hslToHex(h, s, l) {
  s /= 100; l /= 100;
  const k = (n) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  const x = (v) => Math.round(v * 255).toString(16).padStart(2, '0');
  return '#' + x(f(0)) + x(f(8)) + x(f(4));
}
function shiftHue(hex, d) {
  const [h, s, l] = hexToHsl(hex);
  return hslToHex((h + d + 360) % 360, s, l);
}

// Tombol warna
const swBox = document.getElementById('swatches');
Object.entries(PALETTE).forEach(([name, [c1, c2]]) => {
  const el = document.createElement('button');
  el.type = 'button';
  el.className = 'sw';
  el.dataset.name = name;
  el.title = name;
  el.style.background = `linear-gradient(135deg, ${c1}, ${c2})`;
  el.onclick = () => { view.accent = name; applyView(); saveView(); };
  swBox.appendChild(el);
});
const customSw = document.createElement('button');
customSw.type = 'button';
customSw.className = 'sw swc';
customSw.dataset.name = 'custom';
customSw.title = 'Warna sendiri';
customSw.onclick = () => { view.accent = 'custom'; applyView(); saveView(); };
swBox.appendChild(customSw);

function applyView() {
  const w = Math.min(800, Math.max(300, Number(view.w) || 380));
  const h = Math.min(600, Math.max(300, Number(view.h) || 520));
  const o = Math.min(100, Math.max(30, Number(view.o) || 100));
  const g = Math.min(100, Math.max(0, Number(view.glow) || 0));
  const custom = validHex(view.custom) ? view.custom : '#7c3aed';
  const pal = view.accent === 'custom' ? [custom, shiftHue(custom, 40)] : (PALETTE[view.accent] || PALETTE.hitam);

  const PANEL = new URLSearchParams(location.search).has('panel') || !!window.LGB_WEB;
  document.documentElement.classList.toggle('panel', PANEL);
  document.body.style.width = PANEL ? '100%' : w + 'px';
  document.body.style.height = PANEL ? '100vh' : h + 'px';
  document.body.style.opacity = o / 100;
  document.body.style.setProperty('--g', g);
  document.body.classList.toggle('stealth', !!view.stealth);
  document.body.classList.toggle('glass', view.glass === 'v1');
  document.body.classList.toggle('ios', view.glass === 'ios');
  root.style.setProperty('--accent', pal[0]);
  root.style.setProperty('--accent2', pal[1]);
  if (view.mode === 'light' || view.mode === 'dark') root.dataset.theme = view.mode;
  else delete root.dataset.theme;

  tw.value = w; th.value = h; to.value = o; tglow.value = g;
  ts.checked = !!view.stealth;
  document.querySelectorAll('#glassSeg button').forEach((b) => b.classList.toggle('on', b.dataset.glass === view.glass));
  customSw.style.background = view.accent === 'custom' ? `linear-gradient(135deg, ${pal[0]}, ${pal[1]})` : '';
  cpNative.value = custom;
  if (document.activeElement !== cpHex) cpHex.value = custom;
  const [ch, , cl] = hexToHsl(custom);
  cpHue.value = ch; cpLight.value = cl;
  document.getElementById('wVal').textContent = w + ' px';
  document.getElementById('hVal').textContent = h + ' px';
  document.getElementById('oVal').textContent = o + '%';
  document.getElementById('gVal').textContent = g === 0 ? 'mati' : g + '%';
  swBox.querySelectorAll('.sw').forEach((s) => s.classList.toggle('active', s.dataset.name === view.accent));
  document.querySelectorAll('#modeSeg button').forEach((b) => b.classList.toggle('on', b.dataset.mode === view.mode));
}

function saveView() {
  chrome.storage.local.set({
    popupWidth: view.w, popupHeight: view.h, popupOpacity: view.o, stealth: view.stealth,
    popupAccent: view.accent, themeMode: view.mode, glow: view.glow, glassMode: view.glass, customColor: view.custom
  }).catch(() => {});
}

ready
  .then(() => chrome.storage.local.get({
    popupWidth: 380, popupHeight: 520, popupOpacity: 100, stealth: false,
    popupAccent: 'hitam', themeMode: 'dark', glow: 30, glass: false, glassMode: '', customColor: '#7c3aed', autoSwitch: true
  }))
  .then((s) => {
    view = {
      w: s.popupWidth, h: s.popupHeight, o: s.popupOpacity, stealth: s.stealth,
      accent: s.popupAccent, mode: s.themeMode, glow: s.glow,
      glass: s.glassMode || (s.glass ? 'v1' : 'off'), custom: s.customColor
    };
    tauto.checked = !!s.autoSwitch;
    applyView();
    refreshProviderUI();
  });

tw.oninput = () => { view.w = Number(tw.value); applyView(); saveView(); };
th.oninput = () => { view.h = Number(th.value); applyView(); saveView(); };
to.oninput = () => { view.o = Number(to.value); applyView(); saveView(); };
tglow.oninput = () => { view.glow = Number(tglow.value); applyView(); saveView(); };
ts.onchange = () => { view.stealth = ts.checked; applyView(); saveView(); };
document.querySelectorAll('#glassSeg button').forEach((btn) => {
  btn.onclick = () => { view.glass = btn.dataset.glass; applyView(); saveView(); };
});

// Color picker
function setCustom(hex) {
  if (!validHex(hex)) return;
  view.custom = hex.toLowerCase();
  view.accent = 'custom';
  applyView(); saveView();
}
cpNative.oninput = () => setCustom(cpNative.value);
cpHex.oninput = () => { let v = cpHex.value.trim(); if (v && v[0] !== '#') v = '#' + v; setCustom(v); };
cpHue.oninput = () => { const [, s, l] = hexToHsl(view.custom); setCustom(hslToHex(Number(cpHue.value), Math.max(s, 70), l)); };
cpLight.oninput = () => { const [h, s] = hexToHsl(view.custom); setCustom(hslToHex(h, s, Number(cpLight.value))); };
tauto.onchange = () => chrome.storage.local.set({ autoSwitch: tauto.checked });
document.querySelectorAll('#modeSeg button').forEach((btn) => {
  btn.onclick = () => { view.mode = btn.dataset.mode; applyView(); saveView(); };
});
document.querySelectorAll('#tunePanel .pre[data-w]').forEach((btn) => {
  btn.onclick = () => { view.w = Number(btn.dataset.w); view.h = Number(btn.dataset.h); applyView(); saveView(); };
});
document.getElementById('tune').onclick = (e) => { e.stopPropagation(); togglePop(tunePanel); };


// ---------- Pengaturan privasi & sinkron ----------
const personaSel = document.getElementById('personaSel');
const memNotes = document.getElementById('memNotes');
personaSel.onchange = () => { S.persona = personaSel.value; chrome.storage.local.set({ persona: S.persona }); if (S.persona !== 'default') add('note', 'Mode: ' + PERSONAS[S.persona].label + (S.persona.startsWith('rp_') ? ' — kirim pesan apa saja untuk memulai.' : '')); };
let memTimer;
memNotes.oninput = () => { clearTimeout(memTimer); memTimer = setTimeout(() => { S.memoryNotes = memNotes.value; chrome.storage.local.set({ memoryNotes: memNotes.value }); }, 400); };
const HOSTS = { origins: ['http://*/*', 'https://*/*'] };
// Toolbar hanya aktif kalau izin situs sudah diberikan -> centang harus mencerminkan itu
async function syncTb() {
  let has = false;
  try { has = await chrome.permissions.contains(HOSTS); } catch (e) { /* abaikan */ }
  ttb.checked = !!S.selToolbar && has;
  ttb.title = has ? '' : 'Klik untuk memberi izin agar toolbar muncul saat highlight teks';
}
async function loadS() {
  await ready;
  S = await getSettings();
  tnohist.checked = S.noHistory; thl.checked = S.autoHighlight; syncTb(); syncWs(); if (tsp) tsp.checked = !!S.sidePanel; tsr.checked = S.smartReply !== false; tlite.checked = !!S.lite; tdisguise.checked = !!S.disguise;
  if (!personaSel.options.length) Object.entries(PERSONAS).forEach(([k, v]) => personaSel.add(new Option(v.label, k)));
  personaSel.value = PERSONAS[S.persona] ? S.persona : 'default';
  if (document.activeElement !== memNotes) memNotes.value = S.memoryNotes || '';
}
chrome.storage.onChanged.addListener((c, area) => {
  if (area !== 'local') return;
  Object.keys(DEFAULT_SETTINGS).forEach((k) => { if (c[k]) S[k] = c[k].newValue; });
  tnohist.checked = S.noHistory; thl.checked = S.autoHighlight; syncTb(); syncWs(); if (tsp) tsp.checked = !!S.sidePanel; tsr.checked = S.smartReply !== false; tlite.checked = !!S.lite; tdisguise.checked = !!S.disguise;
  if (c.pingUnit) { pingSel.value = S.pingUnit; measureNet(); }
});
async function enableToolbar() {
  try {
    const ok = await chrome.permissions.request({ origins: ['http://*/*', 'https://*/*'] });
    await chrome.storage.local.set({ selToolbar: ok });
    return ok;
  } catch (e) { return false; }
}
tnohist.onchange = async () => {
  S.noHistory = tnohist.checked;
  await chrome.storage.local.set({ noHistory: S.noHistory });
  if (S.noHistory) chrome.storage.local.remove(['chatLog', 'chatHistory', 'chats']); else persist();
};
document.getElementById('tFeat').onclick = () => { closePops(); openFeatures(); };
document.getElementById('tNews').onclick = () => { closePops(); openChangelog(); };
const tsr = document.getElementById('tsr');
tsr.onchange = async () => {
  if (tsr.checked) { // butuh izin situs yang sama dengan toolbar highlight
    let ok = false; try { ok = await chrome.permissions.contains(HOSTS) || await chrome.permissions.request(HOSTS); } catch (e) { /* abaikan */ }
    if (!ok) { tsr.checked = false; return; }
  }
  chrome.storage.local.set({ smartReply: tsr.checked });
};
const tsp = document.getElementById('tsp');
if (tsp) {
  if (!chrome.sidePanel) tsp.closest('label').hidden = true;
  tsp.onchange = () => chrome.storage.local.set({ sidePanel: tsp.checked });
}
async function openSidePanel() {
  try { const w = await chrome.windows.getCurrent(); await chrome.sidePanel.open({ windowId: w.id }); if (!new URLSearchParams(location.search).has('panel')) window.close(); }
  catch (e) { add('err', 'Side panel tidak tersedia di browser ini: ' + e.message); }
}
const wsBtn = document.getElementById('wsBtn');
function syncWs() { wsBtn.classList.toggle('on', !!S.webSearch); wsBtn.title = S.webSearch ? 'Cari di web dulu: AKTIF (klik untuk mematikan)' : 'Cari info terbaru di web dulu sebelum menjawab'; }
wsBtn.onclick = async () => {
  if (S.webSearch) { S.webSearch = false; chrome.storage.local.set({ webSearch: false }); syncWs(); return; }
  if (window.LGB_WEB) { S.webSearch = true; chrome.storage.local.set({ webSearch: true }); syncWs(); return; }
  let ok = false; try { ok = await chrome.permissions.request({ origins: [WS_ORIGIN] }); } catch (e) { /* abaikan */ }
  if (!ok) { add('note', 'Izin pencarian web ditolak.'); return; }
  S.webSearch = true; chrome.storage.local.set({ webSearch: true }); syncWs();
};
thl.onchange = () => chrome.storage.local.set({ autoHighlight: thl.checked });
tlite.onchange = () => chrome.storage.local.set({ lite: tlite.checked });
tdisguise.onchange = () => chrome.storage.local.set({ disguise: tdisguise.checked });
ttb.onchange = async () => {
  if (ttb.checked) { ttb.checked = await enableToolbar(); } else chrome.storage.local.set({ selToolbar: false });
};
try { chrome.permissions.onAdded.addListener(syncTb); chrome.permissions.onRemoved.addListener(syncTb); } catch (e) { /* abaikan */ }
document.getElementById('openPrivacy').onclick = () => chrome.runtime.openOptionsPage();

// ---------- Pemilih provider AI ----------
async function refreshProviderUI() {
  const { all, active } = await loadProviders();
  provSel.innerHTML = '';
  all.forEach((p) => {
    const o = document.createElement('option');
    o.value = p.id; o.textContent = p.name;
    provSel.appendChild(o);
  });
  if (active) provSel.value = active.id;
  modelName.textContent = active ? active.model || '-' : 'Belum ada AI';
  modelName.title = modelName.textContent;
  if (typeof measureNet === 'function') measureNet();
}
provSel.onchange = async () => {
  await chrome.storage.local.set({ activeProvider: provSel.value });
  refreshProviderUI();
};

// ---------- Util tampilan ----------
function nearBottom() { return chat.scrollHeight - chat.scrollTop - chat.clientHeight < 90; }
function scrollDown() { chat.scrollTop = chat.scrollHeight; }
function removeEmpty() { document.getElementById('empty')?.remove(); }

async function copyText(text, btn) {
  const label = btn.querySelector('span');
  const old = label ? label.textContent : btn.textContent;
  const set = (t) => { if (label) label.textContent = t; else btn.textContent = t; };
  try { await navigator.clipboard.writeText(text); set('Tersalin'); } catch { set('Gagal'); }
  setTimeout(() => set(old), 1200);
}

function toolBtn(host, icon, label, fn, cls) {
  const b = document.createElement('button');
  b.type = 'button';
  if (cls) b.className = cls;
  b.innerHTML = icon + '<span>' + label + '</span>';
  b.onclick = () => fn(b);
  host.appendChild(b);
  return b;
}

function addTools(row, text, o = {}) {
  const host = row.querySelector('.col') || row;
  host.querySelector('.tools')?.remove();
  const tools = document.createElement('div');
  tools.className = 'tools';
  if (text) toolBtn(tools, COPY_ICON, 'Salin', (b) => copyText(text, b));
  if (text) addTableTools(tools, text);
  if (text) toolBtn(tools, '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12m0 0-4-4m4 4 4-4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/></svg>', 'Ekspor', (b) => { const r = b.getBoundingClientRect(); const ttl = (text.split('\n').map((l) => l.replace(/[#*`>_\[\]{}"]/g, '').trim()).find((l) => l.length > 3) || 'Jawaban AI').slice(0, 50); exportMenu(Math.min(r.left, innerWidth - 220), r.bottom + 4, ttl, text); });
  if (o.regen) toolBtn(tools, ICONS.retry, 'Ulangi', () => regenerate());
  if (o.retry) toolBtn(tools, ICONS.retry, 'Coba lagi', () => retryLast());
  if (tools.children.length) host.appendChild(tools);
}

// ---------- Sumber / sitasi ----------
function splitSources(text) {
  const m = text.match(/\[\[SUMBER\]\]([\s\S]*?)(?:\[\[\/SUMBER\]\]|$)/);
  if (!m) return { body: text.replace(/\[{1,2}[A-Z\/]{0,8}\]{0,2}$/, '').trimEnd(), sources: [] };
  const sources = [];
  m[1].split('\n').forEach((l) => {
    const k = l.match(/^\s*\[(\d{1,2})\]\s*["“«]?(.+?)["”»]?\s*$/);
    if (k) sources.push({ n: +k[1], q: k[2] });
  });
  return { body: text.slice(0, m.index).trim(), sources };
}

function linkCites(bubble, sources) {
  if (!sources.length) return;
  const has = new Set(sources.map((s) => s.n));
  const w = document.createTreeWalker(bubble, NodeFilter.SHOW_TEXT, {
    acceptNode: (n) => (n.parentElement.closest('pre,code,a,.katex') ? NodeFilter.FILTER_REJECT : /\[\d{1,2}\]/.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT)
  });
  const nodes = [];
  while (w.nextNode()) nodes.push(w.currentNode);
  nodes.forEach((n) => {
    const frag = document.createDocumentFragment();
    n.nodeValue.split(/(\[\d{1,2}\])/).forEach((part) => {
      const k = part.match(/^\[(\d{1,2})\]$/);
      if (k && has.has(+k[1])) {
        const b = document.createElement('button');
        b.type = 'button'; b.className = 'cite'; b.textContent = k[1]; b.dataset.n = k[1];
        b.title = 'Lihat sumber di halaman';
        frag.appendChild(b);
      } else if (part) frag.appendChild(document.createTextNode(part));
    });
    n.parentNode.replaceChild(frag, n);
  });
}

async function highlightQuotes(sources, focus = -1) {
  try {
    const tab = await activeTab();
    if (!tab || !hostOf(tab.url)) return [];
    const quotes = sources.map((s) => s.q);
    const res = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: pageHighlight, args: [quotes, focus] });
    return quotes.map((_, i) => res.some((r) => r.result && r.result[i]));
  } catch (e) { return []; }
}

function addSources(row, sources, found) {
  const col = row.querySelector('.col');
  const box = document.createElement('div');
  box.className = 'sources';
  box.innerHTML = '<span class="lbl">Sumber di halaman:</span>';
  sources.forEach((s, i) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.textContent = s.n + '. ' + (s.q.length > 38 ? s.q.slice(0, 38) + '…' : s.q);
    b.title = s.q;
    if (found && found[i] === false) { b.classList.add('miss'); b.title = 'Tidak ditemukan di halaman: ' + s.q; }
    b.onclick = async () => { const f = await highlightQuotes(sources, i); if (f[i] === false) b.classList.add('miss'); };
    box.appendChild(b);
  });
  col.appendChild(box);
  col.querySelectorAll('.cite').forEach(() => {});
  row.querySelectorAll('.cite').forEach((c) => { c.onclick = () => { const i = sources.findIndex((s) => String(s.n) === c.dataset.n); if (i >= 0) highlightQuotes(sources, i); }; });
}

// ---------- Follow-up chips ----------
function addFollow(row, kind) {
  chat.querySelectorAll('.follow').forEach((f) => f.remove());
  const list = FOLLOWUPS[kind] || FOLLOWUPS.chat;
  const box = document.createElement('div');
  box.className = 'follow';
  list.forEach((t) => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'chip'; b.textContent = t;
    b.onclick = () => { if (!current) send(t, [], { noPage: true, kind: 'chat' }); };
    box.appendChild(b);
  });
  row.querySelector('.col').appendChild(box);
}

// ---------- Pesan ----------
function add(role, text, images = [], extra = {}) {
  removeEmpty();
  const row = document.createElement('div');
  row.className = 'row ' + role;
  const bubble = document.createElement('div');
  bubble.className = 'msg';
  const col = document.createElement('div');
  col.className = 'col';
  col.appendChild(bubble);
  if (role === 'ai' || role === 'err') {
    const av = document.createElement('img');
    av.className = 'avatar sm'; av.src = 'avatar.png'; av.alt = '';
    row.appendChild(av);
  }
  row.appendChild(col);
  chat.appendChild(row);

  if (role === 'user') {
    if (images.length) {
      const box = document.createElement('div');
      box.className = 'imgs';
      images.forEach((src) => {
        const im = document.createElement('img');
        im.src = src; im.onclick = () => openImage(src);
        box.appendChild(im);
      });
      bubble.appendChild(box);
    }
    if (text) bubble.appendChild(document.createTextNode(text));
    if (extra.sent) { const t = document.createElement('span'); t.className = 'tag'; t.innerHTML = ic('send', 12) + ' ' + esc(extra.sent); bubble.appendChild(t); }
    addTools(row, text);
  } else if (role === 'ai' && text !== null) {
    setAI(row, text, extra);
  } else if (role === 'err') {
    bubble.textContent = text;
    if (extra.retry) addTools(row, '', { retry: true });
  } else if (text !== null) {
    bubble.textContent = text;
  }
  scrollDown();
  return row;
}

function typing(label) {
  const row = add('ai', null);
  const msg = row.querySelector('.msg');
  msg.innerHTML = '';
  if (window.LatticeLoader && !window.LGB_LITE) {
    row.lattice = LatticeLoader(msg, { label: label || 'Berpikir', doneLabel: 'Selesai dalam', errorLabel: 'Gagal setelah', pattern: 'orbit', grid: 3, shape: 'round', cellSize: 6, gap: 2, fontSize: 13, color: 'currentColor' });
    return row;
  }
  msg.innerHTML = '<span class="typing"><i></i><i></i><i></i></span><span class="tlabel"></span>';
  setLabel(row, label);
  return row;
}
function setLabel(row, t) {
  if (row.lattice) { row.lattice.setLabel(t || 'Berpikir'); return; }
  const l = row.querySelector('.tlabel'); if (l) l.textContent = t || '';
}

function setAI(row, text, o = {}) {
  row.className = 'row ai';
  const bubble = row.querySelector('.msg');
  bubble.className = 'msg md';
  const { body, sources } = splitSources(text);
  bubble.innerHTML = renderMarkdown(body);
  linkCites(bubble, sources);
  bubble.querySelectorAll('pre').forEach((pre) => {
    const b = document.createElement('button');
    b.className = 'copy'; b.type = 'button'; b.textContent = 'Salin';
    b.onclick = () => copyText(pre.querySelector('code')?.innerText ?? pre.innerText, b);
    pre.appendChild(b);
  });
  if (window.LGB_CODE) LGB_CODE.enhance(bubble, row, false, !!o.follow);
  const col = row.querySelector('.col');
  col.querySelectorAll('.sources,.follow').forEach((n) => n.remove());
  if (sources.length) addSources(row, sources, o.found);
  addTools(row, body, { regen: o.regen });
  if (o.follow) addFollow(row, o.kind);
}

let streamPaintAt = 0;
function renderStream(row, text) {
  // Render markdown penuh tiap token itu mahal: batasi ~12x/detik, sisa dirapikan oleh timer penutup
  const nowT = performance.now();
  if (nowT - streamPaintAt < 80 + Math.min(220, (text.length / 40) | 0)) {
    row._rsText = text;
    if (!row._rsTimer) row._rsTimer = setTimeout(() => {
      row._rsTimer = 0;
      const m = row.querySelector('.msg');
      if (m && m.classList.contains('streaming') && row._rsText != null) renderStream(row, row._rsText);
    }, 90);
    return;
  }
  streamPaintAt = nowT;
  const { body } = splitSources(text);
  const b = row.querySelector('.msg');
  const stick = nearBottom();
  b.className = 'msg md streaming';
  b.innerHTML = renderMarkdown(body);
  if (window.LGB_CODE) LGB_CODE.enhance(b, row, true);
  if (stick) scrollDown();
}

// ---------- Indikator konten dikirim ----------
function showInd(t, icon) { ind.innerHTML = (icon ? ic(icon, 14) + ' ' : '') + '<span></span>'; ind.lastChild.textContent = t; ind.hidden = false; }
function hideInd() { ind.hidden = true; }
async function provLabel() { const { active } = await loadProviders().catch(() => ({})); return active ? active.name : 'AI'; }

// ---------- Gambar & PDF ----------
function fileToDataURL(file) {
  return new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = rej; fr.readAsDataURL(file); });
}
async function shrink(dataURL, max = 1280) {
  const img = new Image();
  await new Promise((ok, fail) => { img.onload = ok; img.onerror = fail; img.src = dataURL; });
  const sc = Math.min(1, max / Math.max(img.width, img.height));
  const w = Math.round(img.width * sc), h = Math.round(img.height * sc);
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h);
  ctx.drawImage(img, 0, 0, w, h);
  return c.toDataURL('image/jpeg', 0.85);
}

async function pdfText(buf) {
  if (typeof pdfjsLib === 'undefined') {
    await new Promise((res, rej) => { const sc = document.createElement('script'); sc.src = 'lib/pdf.min.js'; sc.onload = res; sc.onerror = () => rej(new Error('Gagal memuat pembaca PDF')); document.head.appendChild(sc); });
  }
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
  const pdf = await pdfjsLib.getDocument({ data: buf }).promise;
  let out = '';
  const n = Math.min(pdf.numPages, 80);
  for (let i = 1; i <= n && out.length < 70000; i++) {
    const pg = await pdf.getPage(i);
    const tc = await pg.getTextContent();
    const t = tc.items.map((x) => x.str + (x.hasEOL ? '\n' : '')).join(' ').replace(/[ \t]+/g, ' ').trim();
    if (t) out += '\n[Hal. ' + i + ']\n' + t;
  }
  return { text: out.slice(0, 70000), pages: pdf.numPages, cut: out.length > 70000 || pdf.numPages > n };
}

function renderStrip() {
  strip.innerHTML = '';
  strip.hidden = pending.length + docs.length + tabCtx.length === 0;
  pending.forEach((src, i) => {
    const t = document.createElement('div');
    t.className = 'thumb';
    const im = document.createElement('img'); im.src = src;
    const x = document.createElement('button');
    x.type = 'button'; x.textContent = '×'; x.title = 'Hapus';
    x.onclick = () => { pending.splice(i, 1); renderStrip(); };
    t.append(im, x);
    strip.appendChild(t);
  });
  const chip = (label, fn, icon) => {
    const d = document.createElement('div');
    d.className = 'doc';
    d.innerHTML = (icon ? ic(icon, 13) : '') + '<span>' + esc(label) + '</span>';
    const x = document.createElement('button');
    x.type = 'button'; x.textContent = '×'; x.className = 'x'; x.title = 'Hapus';
    x.onclick = fn;
    d.appendChild(x);
    strip.appendChild(d);
  };
  docs.forEach((d, i) => chip((d.name.length > 22 ? d.name.slice(0, 22) + '…' : d.name), () => { docs.splice(i, 1); renderStrip(); }, 'file-text'));
  if (tabCtx.length) chip(tabCtx.length + ' tab sebagai konteks', () => { tabCtx = []; renderStrip(); }, 'files');
}

async function addFiles(files) {
  for (const f of [...files]) {
    try {
      if (f.type.startsWith('image/')) {
        if (window.lgbImageOk && !window.lgbImageOk()) continue;
        if (pending.length < MAX_IMAGES) pending.push(await shrink(await fileToDataURL(f)));
      } else if (/\.(txt|md|markdown|csv|tsv|json|log|html?|xml|ya?ml|js|ts|py|java|c|cpp|cs|go|rs|php|sql|css)$/i.test(f.name) || f.type.startsWith('text/')) {
        const t = (await f.text()).slice(0, 400000);
        if (t.trim().length < 3) { add('err', 'File "' + f.name + '" kosong.'); continue; }
        docs.push({ name: f.name, text: t, pages: 0, sent: false });
        showQuick(['Ringkas file ini', 'Jelaskan isi file ini']);
      } else if (f.type === 'application/pdf' || /\.pdf$/i.test(f.name)) {
        showInd('Membaca PDF ' + f.name + '…');
        const r = await pdfText(await f.arrayBuffer());
        hideInd();
        if (r.text.trim().length < 30) { add('err', 'PDF "' + f.name + '" tidak punya teks yang bisa dibaca (mungkin hasil scan).'); continue; }
        docs.push({ name: f.name, text: r.text, pages: r.pages, sent: false });
        showQuick(['Ringkas dokumen ini', 'Buat poin penting', 'Buat 5 soal latihan']);
      }
    } catch (e) { hideInd(); add('err', 'Gagal membaca ' + f.name + ': ' + e.message); }
  }
  renderStrip();
  input.focus();
}

document.getElementById('attach').onclick = () => fileInput.click();
fileInput.onchange = () => { addFiles(fileInput.files); fileInput.value = ''; };

input.addEventListener('paste', (e) => {
  const files = [...(e.clipboardData?.files || [])].filter((f) => f.type.startsWith('image/') || f.type === 'application/pdf');
  if (files.length) { e.preventDefault(); addFiles(files); }
});
let dragDepth = 0;
document.addEventListener('dragenter', (e) => { e.preventDefault(); dragDepth++; document.body.classList.add('dragging'); });
document.addEventListener('dragleave', () => { if (--dragDepth <= 0) { dragDepth = 0; document.body.classList.remove('dragging'); } });
document.addEventListener('dragover', (e) => e.preventDefault());
document.addEventListener('drop', (e) => { e.preventDefault(); dragDepth = 0; document.body.classList.remove('dragging'); addFiles(e.dataTransfer?.files || []); });

// ---------- Screenshot ----------
const shotMenu = document.getElementById('shotMenu');
document.getElementById('shot').onclick = (e) => { e.stopPropagation(); togglePop(shotMenu); };
shotMenu.querySelectorAll('button').forEach((b) => {
  b.onclick = async () => {
    closePops();
    if (window.lgbImageOk && !window.lgbImageOk()) return;
    if (b.dataset.shot === 'visible') {
      try {
        const url = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
        if (pending.length < MAX_IMAGES) { pending.push(await shrink(url)); renderStrip(); }
        showQuick(['Jelaskan gambar/UI ini', 'Cari solusi error ini', 'Tulis ulang teks di gambar']);
      } catch (e) { add('err', 'Gagal menangkap layar: ' + e.message); }
    } else {
      const tab = await activeTab();
      await chrome.runtime.sendMessage({ cmd: 'startArea', tabId: tab.id });
      closePopup();
    }
  };
});

// Chip saran cepat di atas kolom tulis
function showQuick(list) {
  qchips.innerHTML = '';
  list.forEach((t) => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'chip'; b.textContent = t;
    b.onclick = () => { qchips.hidden = true; input.value = t; autoGrow(); form.requestSubmit(); };
    qchips.appendChild(b);
  });
  qchips.hidden = !list.length;
}

// ======================================================================
// ===== Halaman aktif, izin baca, konteks =====
// ======================================================================
async function activeTab() { const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); return t; }
function hostOf(u) { try { const x = new URL(u); return /^https?:$/.test(x.protocol) ? x.hostname : ''; } catch { return ''; } }
const isYouTube = (u) => /^https:\/\/(www\.|m\.)?youtube\.com\/watch/.test(u || '');
const isPdf = (u) => /^(https?|file):\/\/[^#?]*\.pdf($|[?#])/i.test(u || '');

async function syncToggle() {
  const t = await activeTab();
  const h = t ? hostOf(t.url) : '';
  usePage.disabled = !h && !isPdf(t && t.url);
  usePage.checked = !!(h && S.allowedSites[h]);
  document.getElementById('ctxLabel').textContent = h ? 'Izinkan AI membaca halaman ini' : 'Halaman ini tidak bisa dibaca';
}
async function setSiteAllowed(host, val) {
  const a = Object.assign({}, S.allowedSites);
  if (val) a[host] = true; else delete a[host];
  S.allowedSites = a;
  await chrome.storage.local.set({ allowedSites: a });
}

function askConsent(host) {
  return new Promise(async (res) => {
    let done = false;
    const pn = await provLabel();
    const sh = sheet(`<h3>Izinkan AI membaca halaman ini?</h3>
      <p>Teks dari <b>${esc(host)}</b> akan dikirim ke penyedia AI yang kamu pilih (<b>${esc(pn)}</b>) supaya bisa menjawab. Tidak ada yang dikirim sebelum kamu menekan tombol atau mengirim pertanyaan. Jangan aktifkan di halaman berisi data pribadi atau rahasia.</p>
      <div class="row-btns"><button class="btn primary" data-v="site">Izinkan untuk situs ini</button><button class="btn" data-v="once">Sekali ini saja</button><button class="btn" data-v="no">Batal</button></div>`);
    const fin = (v) => { if (done) return; done = true; res(v); };
    sh.querySelectorAll('[data-v]').forEach((b) => { b.onclick = () => { fin(b.dataset.v); sh.close(); }; });
    sh.onclose = () => fin('no');
  });
}

async function ensurePageConsent() {
  const t = await activeTab();
  const h = t ? hostOf(t.url) : '';
  if (!h) throw new Error('Halaman ini tidak bisa dibaca (halaman khusus browser atau tab kosong).');
  if (S.allowedSites[h]) return true;
  const v = await askConsent(h);
  if (v === 'site') { await setSiteAllowed(h, true); usePage.checked = true; return true; }
  return v === 'once';
}

usePage.onchange = async () => {
  const t = await activeTab();
  const h = t ? hostOf(t.url) : '';
  if (!h) { usePage.checked = false; return; }
  if (usePage.checked) {
    const v = await askConsent(h);
    if (v === 'site') await setSiteAllowed(h, true);
    else { usePage.checked = false; if (v === 'once') add('note', 'Izin sekali ini hanya berlaku untuk tombol aksi. Aktifkan saklar untuk selalu menyertakan halaman.'); }
  } else await setSiteAllowed(h, false);
};

async function extractPage(limit = 30000) {
  const tab = await activeTab();
  if (!tab || !hostOf(tab.url)) throw new Error('Halaman ini tidak bisa dibaca (halaman khusus browser).');
  let res;
  try {
    res = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: pageExtract, args: [limit] });
  } catch (e) {
    try { res = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: pageExtract, args: [limit] }); }
    catch (e2) { throw new Error('Tidak bisa membaca halaman ini: ' + e2.message); }
  }
  const frames = res.filter((r) => r.result).map((r) => Object.assign({ frameId: r.frameId }, r.result)).sort((a, b) => (b.top ? 1 : 0) - (a.top ? 1 : 0));
  const selection = (frames.find((f) => f.selection) || {}).selection || '';
  const seen = new Set();
  let text = '';
  frames.forEach((f) => {
    const k = f.text.slice(0, 200);
    if (f.text.length >= 30 && !seen.has(k)) { seen.add(k); text += (text ? '\n\n' : '') + f.text; }
  });
  const blocks = [];
  frames.forEach((f) => f.blocks.forEach((b) => blocks.push(Object.assign({ frameId: f.frameId }, b))));
  const declared = Math.max(0, ...frames.map((f) => f.declared || 0));
  return { tab, frames, selection, text, blocks, declared, url: tab.url, title: tab.title };
}

async function getTabPdf(tab) {
  const u = new URL(tab.url);
  if (u.protocol !== 'file:') {
    const origins = [u.origin + '/*'];
    if (!(await chrome.permissions.contains({ origins }))) {
      const ok = await chrome.permissions.request({ origins });
      if (!ok) throw new Error('Izin untuk mengunduh PDF ini ditolak.');
    }
  }
  let r;
  try { r = await fetch(tab.url, { credentials: 'include' }); if (!r.ok) throw new Error('HTTP ' + r.status); }
  catch (e) {
    throw new Error(u.protocol === 'file:'
      ? 'Untuk PDF lokal, aktifkan "Izinkan akses ke URL file" di chrome://extensions → Detail extension ini. Atau seret file PDF-nya ke popup ini.'
      : 'Gagal mengunduh PDF: ' + e.message);
  }
  const out = await pdfText(await r.arrayBuffer());
  if (out.text.trim().length < 30) throw new Error('PDF ini tidak punya teks yang bisa dibaca (mungkin hasil scan). Coba screenshot halamannya lalu tanya lewat gambar.');
  return Object.assign(out, { name: decodeURIComponent(u.pathname.split('/').pop() || 'dokumen.pdf') });
}

async function getYouTube(tab) {
  const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: ytExtract, args: [28000] });
  return r.result;
}
function ytToText(y) {
  return `Video YouTube: ${y.title}\nURL: ${y.url}\n` + (y.desc ? `Deskripsi:\n${y.desc}\n` : '') +
    (y.transcript ? `\nTranskrip (${y.source}, dengan timestamp):\n${y.transcript}` : `\n(${y.error})`);
}

const CITE_SUFFIX = '\n\nAturan: jawab berdasarkan konteks di atas. Tandai dasar jawaban dengan [1], [2] pada kalimat yang relevan. Di akhir jawaban tambahkan blok persis seperti ini (tanpa teks apa pun sesudahnya):\n[[SUMBER]]\n[1] "kutipan persis dari halaman, maks 20 kata, disalin apa adanya"\n[[/SUMBER]]\nJika jawabannya tidak ada di halaman, katakan begitu dan jangan membuat blok sumber.';

// Konteks halaman untuk pertanyaan biasa (YouTube / PDF / halaman web)
async function getContext() {
  const tab = await activeTab();
  if (!tab) return null;
  if (isYouTube(tab.url)) {
    const y = await getYouTube(tab);
    return { kind: 'video', text: ytToText(y), label: 'transkrip video', cite: false, key: tab.url, warn: y.error };
  }
  if (isPdf(tab.url)) {
    const p = await getTabPdf(tab);
    return { kind: 'pdf', text: `Dokumen PDF "${p.name}" (${p.pages} halaman):\n${p.text}`, label: 'PDF ' + p.name, cite: false, key: tab.url };
  }
  const pg = await extractPage(14000);
  const text = pg.selection || pg.text;
  if (!text) return null;
  return {
    kind: 'page', cite: true, label: pg.selection ? 'teks terpilih' : 'isi halaman',
    text: `Konteks halaman (${pg.title} — ${pg.url}):\n"""\n${text.slice(0, 14000)}\n"""`,
    key: pg.url + '|' + text.length + '|' + text.slice(0, 60)
  };
}

// ======================================================================
// ===== Cari di web (opsional) & RAG lokal untuk dokumen panjang =====
// ======================================================================
const WS_ORIGIN = 'https://html.duckduckgo.com/*';
async function webSearch(q) {
  if (window.LGB_WEB) {
    let r;
    try { r = await fetch('/api/search?q=' + encodeURIComponent(q.slice(0, 300))); } catch (e) { throw new Error('Pencarian web gagal: tidak bisa terhubung ke server.'); }
    let j = null; try { j = await r.json(); } catch (e) { /* abaikan */ }
    if (!r.ok) throw new Error((j && j.error && j.error.message) || ('Pencarian web gagal (' + r.status + ').'));
    return (j && j.results) || [];
  }
  const has = await chrome.permissions.contains({ origins: [WS_ORIGIN] }).catch(() => false);
  if (!has) throw new Error('Izin pencarian web belum diberikan. Matikan lalu nyalakan lagi tombol Web.');
  const r = await fetch('https://html.duckduckgo.com/html/?q=' + encodeURIComponent(q.slice(0, 300)) + '&kl=id-id', { headers: { Accept: 'text/html' } });
  if (!r.ok) throw new Error('Pencarian web gagal (' + r.status + ').');
  const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
  const out = [];
  doc.querySelectorAll('.result').forEach((el) => {
    const a = el.querySelector('a.result__a'); if (!a || el.classList.contains('result--ad')) return;
    let href = a.getAttribute('href') || '';
    const m = href.match(/[?&]uddg=([^&]+)/); if (m) href = decodeURIComponent(m[1]);
    if (href.startsWith('//')) href = 'https:' + href;
    out.push({ title: a.textContent.trim(), url: href, snippet: (el.querySelector('.result__snippet')?.textContent || '').trim() });
  });
  return out.slice(0, 6);
}
const STOP = new Set('yang dan di ke dari untuk dengan ini itu pada adalah atau juga saya aku kamu apa bagaimana kenapa mengapa the and for with that this what how why are was were from have has can you your about'.split(' '));
function ragPick(text, q, budget) {
  const size = 1400, step = 1250, chunks = [];
  for (let i = 0; i < text.length; i += step) chunks.push(text.slice(i, i + size));
  const terms = [...new Set(q.toLowerCase().split(/[^a-z0-9À-ɏ]+/).filter((w) => w.length > 2 && !STOP.has(w)))];
  if (!terms.length) return chunks.slice(0, Math.ceil(budget / size)).join('\n…\n');
  const low = chunks.map((c) => c.toLowerCase());
  const df = terms.map((t) => low.filter((c) => c.includes(t)).length);
  const scored = low.map((c, i) => {
    let s = 0;
    terms.forEach((t, k) => { if (!df[k]) return; let tf = 0, at = c.indexOf(t); while (at >= 0 && tf < 8) { tf++; at = c.indexOf(t, at + t.length); } if (tf) s += Math.log(1 + tf) * Math.log(1 + chunks.length / df[k]); });
    return { i, s: s + (i === 0 ? 0.3 : 0) };
  }).sort((a, b) => b.s - a.s);
  const keep = []; let used = 0;
  for (const c of scored) { if (c.s <= 0 && keep.length) break; if (used + chunks[c.i].length > budget) continue; keep.push(c.i); used += chunks[c.i].length; }
  if (!keep.length) keep.push(0);
  return keep.sort((a, b) => a - b).map((i) => '[Bagian ' + (i + 1) + '/' + chunks.length + ']\n' + chunks[i]).join('\n…\n');
}

// ======================================================================
// ===== Suara -> prompt (tahan Alt+V atau tahan tombol mikrofon) =====
// ======================================================================
(function voice() {
  if (window.LGB_WEB && window.MediaRecorder && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) return; // web: pakai web-voice.js (Whisper)
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const micBtn = document.getElementById('mic');
  if (!SR) { if (micBtn) micBtn.hidden = true; return; }
  let rec = null, active = false, finalText = '', interim = '', startedAt = 0, base = '';
  function stopUI() { active = false; micBtn && micBtn.classList.remove('rec'); hideInd(); input.placeholder = 'Tulis pertanyaan… ( / untuk perintah )'; }
  function start(via) {
    if (active || current) return;
    active = true; finalText = ''; interim = ''; startedAt = Date.now(); base = input.value ? input.value.trim() + ' ' : '';
    micBtn && micBtn.classList.add('rec');
    showInd('Mendengarkan… ' + (via === 'key' ? 'lepas Alt+V' : 'lepas tombol') + ' untuk ' + (S.voiceAutoSend === false ? 'menulis' : 'mengirim'), 'mic');
    rec = new SR();
    rec.lang = S.voiceLang || 'id-ID'; rec.interimResults = true; rec.continuous = true;
    rec.onresult = (e) => {
      interim = ''; finalText = '';
      for (let i = 0; i < e.results.length; i++) { const t = e.results[i][0].transcript; if (e.results[i].isFinal) finalText += t + ' '; else interim += t; }
      input.value = base + (finalText + interim).trim(); input.dispatchEvent(new Event('input'));
    };
    rec.onerror = (e) => {
      stopUI();
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        add('note', 'Mikrofon belum diizinkan untuk extension ini. Klik tombol di bawah, izinkan mikrofon di tab yang terbuka, lalu coba lagi.');
        const b = document.createElement('button'); b.className = 'btn'; b.textContent = 'Izinkan mikrofon'; b.onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('mic.html') });
        chat.appendChild(b); scrollDown();
      } else if (e.error !== 'aborted' && e.error !== 'no-speech') add('err', 'Suara: ' + e.error);
    };
    rec.onend = () => {
      const was = active; stopUI();
      const text = (finalText + interim).trim();
      if (!was && !text) return;
      if (text) {
        input.value = base + text; input.dispatchEvent(new Event('input'));
        if (S.voiceAutoSend !== false && Date.now() - startedAt > 500) form.requestSubmit();
      }
    };
    try { rec.start(); } catch (e) { stopUI(); }
  }
  function stop() { if (!active) return; active = false; try { rec && rec.stop(); } catch (e) { /* abaikan */ } }
  document.addEventListener('keydown', (e) => { if (e.altKey && !e.ctrlKey && !e.metaKey && e.code === 'KeyV') { e.preventDefault(); if (!e.repeat) start('key'); } });
  document.addEventListener('keyup', (e) => { if (active && (e.code === 'KeyV' || e.key === 'Alt')) stop(); });
  if (micBtn) {
    micBtn.addEventListener('pointerdown', (e) => { e.preventDefault(); start('btn'); });
    ['pointerup', 'pointerleave', 'pointercancel'].forEach((ev) => micBtn.addEventListener(ev, stop));
  }
})();

// ======================================================================
// ===== Kirim & streaming =====
// ======================================================================
function buildMessages() {
  const userIdx = history.map((m, i) => (m.role === 'user' ? i : -1)).filter((i) => i >= 0).slice(-2);
  let msgs = history.map((m, i) => ({ role: m.role, content: m.content, images: userIdx.includes(i) ? m.images || [] : [] }));
  // jaga ukuran: kalau terlalu panjang, buang pesan paling lama (sisakan minimal 4)
  let total = msgs.reduce((a, m) => a + m.content.length, 0);
  while (total > 90000 && msgs.length > 4) { total -= msgs[0].content.length; msgs.shift(); }
  if (msgs[0] && msgs[0].role !== 'user') msgs.shift();
  return msgs;
}

function setBusy(b) {
  sendBtn.classList.toggle('stop', b);
  sendBtn.title = b ? 'Berhenti' : 'Kirim (Enter)';
  quizBtn.disabled = b;
  if (!b) hideInd();
  if (window._lgbWasBusy && !b) window.dispatchEvent(new Event('lgb-done'));
  window._lgbWasBusy = b;
}
sendBtn.addEventListener('click', (e) => {
  if (current) { e.preventDefault(); current.ctrl.abort(); }
});

function showError(row, err, retry) {
  hideInd();
  row.className = 'row err';
  const m = row.querySelector('.msg');
  m.className = 'msg';
  let tip = '';
  if (/image|vision|multimodal|support/i.test(err.message) && history.at(-1)?.images?.length) {
    tip = '\n\nTips: model ini mungkin tidak mendukung gambar. Pilih provider lain di bagian atas.';
  } else if (/model/i.test(err.message)) {
    tip = '\n\nTips: buka "Atur" lalu klik "Ambil daftar model dari API" untuk memilih model yang tersedia.';
  }
  const text = 'Error: ' + err.message + tip;
  m.textContent = text;
  row.querySelector('.col').querySelector('.tools')?.remove();
  if (retry) addTools(row, '', { retry: true });
  log.push({ role: 'err', text, retry: !!retry, t: Date.now() });
  save();
}

// Jalankan satu jawaban streaming ke dalam `row`
// Jawaban dijalankan di background supaya tetap selesai walau popup ditutup
function bgAsk(messages, o) {
  return new Promise((resolve, reject) => {
    let port;
    try { port = chrome.runtime.connect({ name: 'ask' }); } catch (e) { reject(e); return; }
    let settled = false, last = '';
    const end = (fn, v) => { if (settled) return; settled = true; try { port.disconnect(); } catch (e) { /* abaikan */ } fn(v); };
    o.signal && o.signal.addEventListener('abort', () => { try { port.postMessage({ cmd: 'stop' }); } catch (e) { /* abaikan */ } });
    port.onMessage.addListener((m) => {
      if (m.type === 'provider') o.onProvider && o.onProvider({ name: m.name });
      else if (m.type === 'delta') { last = m.text; o.onDelta && o.onDelta(m.text); }
      else if (m.type === 'shrink') o.onShrink && o.onShrink({ name: m.name });
      else if (m.type === 'switch') o.onSwitch && o.onSwitch({ name: m.from }, { name: m.to }, new Error(m.why || ''));
      else if (m.type === 'active') o.onActiveChanged && o.onActiveChanged();
      else if (m.type === 'done') end(resolve, { text: m.text, truncated: m.truncated });
      else if (m.type === 'stopped') { const e = new Error('Dihentikan'); e.name = 'AbortError'; end(reject, e); }
      else if (m.type === 'error') end(reject, new Error(m.message));
    });
    port.onDisconnect.addListener(() => end(reject, new Error('Koneksi ke background terputus. Coba kirim ulang.')));
    port.postMessage({ cmd: 'ask', messages, persist: true, kind: o.kind, deep: o.deep, maxTokens: o.maxTokens });
  });
}

// Popup dibuka lagi: ambil jawaban yang diselesaikan background saat popup tertutup
async function applyBgJob(job) {
  if (!job || job.running) return false;
  await chrome.storage.local.remove('bgJob');
  if (job.error) { const text = job.error; add('err', text); log.push({ role: 'err', text, t: Date.now() }); save(); return true; }
  if (job.text) {
    history.push({ role: 'assistant', content: job.text, images: [] });
    log.push({ role: 'ai', text: job.text, kind: job.kind || 'chat', t: Date.now() });
    save();
    drawLog();
    if (job.stopped) add('note', 'Dihentikan.');
    scrollDown();
  }
  return true;
}
function waitBgJob() {
  const row = typing('Melanjutkan jawaban yang tadi…');
  setBusy(true);
  current = { ctrl: { abort: () => { try { chrome.runtime.sendMessage({ cmd: 'bgStop' }); } catch (e) { /* abaikan */ } } } };
  const done = async (job) => {
    chrome.storage.onChanged.removeListener(on);
    clearInterval(poll);
    row.remove(); current = null; setBusy(false);
    await applyBgJob(job);
    input.focus();
  };
  const on = (c, area) => { if (area === 'local' && c.bgJob && c.bgJob.newValue && !c.bgJob.newValue.running) done(c.bgJob.newValue); };
  chrome.storage.onChanged.addListener(on);
  // jaga-jaga kalau background mati: lewat 5 menit tanpa kabar, anggap gagal
  const poll = setInterval(async () => {
    const { bgJob } = await chrome.storage.local.get('bgJob');
    if (!bgJob) done({ error: 'Jawaban tidak selesai. Kirim ulang pertanyaanmu.' });
    else if (!bgJob.running) done(bgJob);
    else if (Date.now() - bgJob.t > 300000) done({ error: 'Jawaban tidak selesai. Kirim ulang pertanyaanmu.' });
  }, 3000);
}

async function streamAnswer(row, o) {
  lastMeta = { kind: o.kind, cite: o.cite, deep: o.deep, maxTokens: o.maxTokens };
  const ctrl = new AbortController();
  current = { ctrl };
  setBusy(true);
  let text = '', raf = 0, first = true;
  const paint = () => { raf = 0; renderStream(row, text); };
  try {
    const r = await bgAsk(o.messages || buildMessages(), {
      signal: ctrl.signal, deep: o.deep, maxTokens: o.maxTokens || 4096, kind: o.kind,
      onProvider: (p) => setLabel(row, 'Menyusun jawaban dengan ' + p.name + '…'),
      onDelta: (t) => {
        text = t;
        if (first) { first = false; row.querySelector('.msg').innerHTML = ''; }
        if (!raf) raf = requestAnimationFrame(paint);
      },
      onShrink: (p) => setLabel(row, 'Memperkecil permintaan agar muat di batas ' + p.name + '…'),
      onSwitch: (from, to, why) => {
        const note = add('note', `${from.name} sedang tidak bisa dipakai (${friendlyError(why)}). Pindah ke ${to.name}…`);
        chat.insertBefore(note, row);
        log.push({ role: 'note', text: note.textContent, t: Date.now() });
      },
      onActiveChanged: () => refreshProviderUI(),
      onModel: () => refreshProviderUI()
    });
    cancelAnimationFrame(raf);
    text = r.text;
    history.push({ role: 'assistant', content: text, images: [] });
    log.push({ role: 'ai', text, kind: o.kind, t: Date.now() });
    save();
    let found;
    const { sources } = splitSources(text);
    if (o.cite && sources.length && S.autoHighlight) found = await highlightQuotes(sources);
    setAI(row, text, { follow: true, kind: o.kind, regen: true, found });
    if (r.truncated) add('note', 'Jawaban sangat panjang dan mungkin terpotong. Ketik "lanjutkan" untuk meneruskan.');
  } catch (err) {
    cancelAnimationFrame(raf);
    if (err.name === 'AbortError') {
      if (text) {
        history.push({ role: 'assistant', content: text, images: [] });
        log.push({ role: 'ai', text, kind: o.kind, t: Date.now() });
        save();
        setAI(row, text, { regen: true });
        add('note', 'Dihentikan.');
      } else { row.remove(); add('note', 'Dihentikan.'); }
    } else {
      showError(row, err, true);
    }
  } finally {
    current = null;
    setBusy(false);
    scrollDown();
    input.focus();
  }
}

function regenerate() {
  if (current) return;
  const last = history[history.length - 1];
  if (!last || last.role !== 'assistant') return;
  history.pop();
  for (let i = log.length - 1; i >= 0; i--) { if (log[i].role === 'ai') { log.splice(i, 1); break; } }
  const rows = chat.querySelectorAll('.row.ai');
  rows[rows.length - 1]?.remove();
  const row = typing('Menyusun jawaban ulang…');
  streamAnswer(row, Object.assign({}, lastMeta, { messages: buildMessages() }));
}

function retryLast() {
  if (current) return;
  if (history.at(-1)?.role !== 'user') return;
  for (let i = log.length - 1; i >= 0; i--) { if (log[i].role === 'err') { log.splice(i, 1); break; } }
  const rows = chat.querySelectorAll('.row.err');
  rows[rows.length - 1]?.remove();
  const row = typing('Mencoba lagi…');
  streamAnswer(row, Object.assign({}, lastMeta, { messages: buildMessages() }));
}

// opts: { display, kind, noPage, sent }
async function send(q, images, opts = {}) {
  if (current) return;
  qchips.hidden = true;
  if (history.at(-1)?.role === 'user') history.pop(); // pertanyaan lama yang gagal
  let content = q, cite = false, kind = opts.kind || 'chat', sent = opts.sent || '';
  const parts = [];
  const bubble = add('user', opts.display || q, images, {});
  log.push({ role: 'user', text: opts.display || q, images, t: Date.now() });
  const row = typing('Membaca…');
  setBusy(true);
  try {
    // 1) isi halaman (hanya kalau diizinkan)
    if (!opts.noPage && (usePage.checked || opts.forcePage)) {
      setLabel(row, 'Membaca halaman…');
      const ctx = await getContext();
      if (ctx && !ctxSent.has(ctx.key)) {
        parts.push(ctx.text);
        cite = ctx.cite; if (ctx.kind !== 'page') kind = ctx.kind;
        ctxSent.add(ctx.key);
        sent = ctx.label + ' · ' + ctx.text.length.toLocaleString('id') + ' karakter';
        if (ctx.warn) add('note', ctx.warn);
      } else if (ctx) { cite = ctx.cite; }
    }
    // 2) PDF terlampir
    docs.forEach((d) => {
      if (d.text.length > 30000) { // dokumen panjang: ambil cuplikan paling relevan untuk tiap pertanyaan (RAG lokal)
        parts.push(`Cuplikan paling relevan dari dokumen "${d.name}" (${d.pages ? d.pages + ' halaman, ' : ''}dokumen panjang, hanya sebagian ditampilkan):\n"""\n${ragPick(d.text, q, 11000)}\n"""`);
        sent = (sent ? sent + ' + ' : '') + 'dokumen ' + d.name + ' (RAG)';
      } else if (!d.sent) { parts.push(`Dokumen terlampir "${d.name}"${d.pages ? ' (' + d.pages + ' halaman)' : ''}:\n"""\n${d.text}\n"""`); d.sent = true; sent = (sent ? sent + ' + ' : '') + (d.pages ? 'PDF ' : 'file ') + d.name; }
    });
    // 2b) cari di web dulu
    if (S.webSearch && !opts.noPage) {
      try {
        setLabel(row, 'Mencari di web…');
        const res = await webSearch(q);
        if (res.length) {
          window.LGB_WEB_SRC = res.map((x) => ({ title: x.title, url: x.url }));
          parts.push('Hasil pencarian web terbaru untuk "' + q.slice(0, 120) + '" (diambil ' + new Date().toLocaleDateString('id', { day: 'numeric', month: 'long', year: 'numeric' }) + '):\n' + res.map((x, i) => (i + 1) + '. ' + x.title + '\n   ' + x.snippet + '\n   ' + x.url).join('\n') + '\n\nPakai hasil ini sebagai sumber utama untuk fakta terbaru (berita, harga, versi, skor, jadwal). Jangan menambah fakta yang tidak ada di hasil; jika hasilnya tidak menjawab, bilang terus terang. Beri nomor sumber [1], [2] di kalimat yang memakainya dan daftar URL sumber di akhir jawaban.');
          sent = (sent ? sent + ' + ' : '') + res.length + ' hasil web';
        } else add('note', 'Pencarian web tidak menemukan hasil.');
      } catch (e) { add('note', e.message); }
    }
    // 3) konteks multi-tab
    const unsent = tabCtx.filter((t) => !t.sent);
    if (unsent.length) {
      unsent.forEach((t, i) => { parts.push(`Tab ${i + 1}: ${t.title}\nURL: ${t.url}\n"""\n${t.text}\n"""`); t.sent = true; });
      kind = 'tabs'; sent = (sent ? sent + ' + ' : '') + unsent.length + ' tab';
    }
    if (parts.length) content = parts.join('\n\n') + '\n\nPertanyaan: ' + q + (cite ? CITE_SUFFIX : '');
    else if (cite) content = q + '\n\n(Jawab berdasarkan konteks halaman yang sudah dikirim sebelumnya.)' + CITE_SUFFIX;

    if (sent) {
      const tag = document.createElement('span');
      tag.className = 'tag'; tag.innerHTML = ic('send', 12) + ' ' + esc(sent);
      bubble.querySelector('.msg').appendChild(tag);
      const lg = log[log.length - 1]; if (lg && lg.role === 'user') lg.sent = sent;
      showInd('Mengirim ' + sent + ' ke ' + (await provLabel()) + '…', 'send');
    }
    history.push({ role: 'user', content, images });
    save();
    setLabel(row, 'Menyusun jawaban…');
    renderStrip();
    current = null;
    await streamAnswer(row, { kind, cite, deep: !!opts.deep, maxTokens: opts.maxTokens });
  } catch (err) {
    current = null; setBusy(false);
    if (history.at(-1)?.role === 'user') showError(row, err, true);
    else showError(row, err, false);
  }
}

// ======================================================================
// ===== Jawab soal di halaman (lengkap: per soal, per bagian, cek kelengkapan) =====
// ======================================================================
function chunkText(text, size = 6500, overlap = 500) {
  const out = [];
  let start = 0;
  while (start < text.length) {
    let end = Math.min(start + size, text.length);
    if (end < text.length) {
      const k = Math.max(text.lastIndexOf('\n\n', end), text.lastIndexOf('\n', end));
      if (k > start + size * 0.6) end = k;
    }
    out.push(text.slice(start, end));
    if (end >= text.length) break;
    start = Math.max(end - overlap, start + 1);
    const nl = text.indexOf('\n', start);
    if (nl > 0 && nl < start + 200) start = nl + 1;
  }
  return out;
}

function chunkItems(items, maxN = 6, maxChars = 7000) {
  const out = []; let cur = [], len = 0;
  items.forEach((it) => {
    if (cur.length && (cur.length >= maxN || len + it.text.length > maxChars)) { out.push(cur); cur = []; len = 0; }
    cur.push(it); len += it.text.length;
  });
  if (cur.length) out.push(cur);
  return out;
}

const QUIZ_FORMAT = `Format WAJIB untuk setiap soal (satu soal = satu blok, urut):
**No. X: B**
(huruf pilihan benar; jika boleh lebih dari satu: **No. X: B, D**) lalu tulis isi pilihannya, dan 1-2 kalimat alasan. Untuk soal hitungan tunjukkan langkah singkat.
Jika sebuah soal benar-benar terpotong, butuh gambar yang tidak terlihat, atau ambigu, tulis **No. X: ?** dan jelaskan alasannya. Jangan menebak asal dan jangan mengarang soal yang tidak ada.`;

function parseAnswers(text) {
  // pecah per header "**No. N:" lalu ambil huruf jawabannya
  const parts = text.split(/(?=\*\*\s*No\.?\s*\d+\s*:)/);
  const map = new Map();
  parts.forEach((p) => {
    const m = p.match(/^\*\*\s*No\.?\s*(\d+)\s*:\s*([^*\n]*?)\s*\*\*/);
    if (!m) return;
    const no = +m[1];
    if (map.has(no)) return; // simpan kemunculan pertama
    let ans = m[2].replace(/^jawaban\s*/i, '').trim();
    let letters = [];
    if (!/^\?/.test(ans)) {
      const lm = ans.match(/^[A-Z](?:\s*(?:,|dan|&|\/)\s*[A-Z])*(?![a-z])/);
      if (lm) letters = lm[0].match(/[A-Z]/g) || [];
    }
    map.set(no, { text: p.trim(), letters, unsure: /^\?/.test(ans) });
  });
  return map;
}

async function runQuiz(only) {
  if (current) return;
  let ok;
  try { ok = await ensurePageConsent(); } catch (e) { add('err', e.message); return; }
  if (!ok) return;
  const shown = only ? 'Coba lagi soal yang belum terjawab: ' + only.join(', ') : 'Jawab semua soal pilihan ganda di halaman ini';
  add('user', shown);
  log.push({ role: 'user', text: shown, t: Date.now() });
  const row = typing('Membaca halaman…');
  const ctrl = new AbortController();
  current = { ctrl };
  setBusy(true);
  let acc = '';
  try {
    const pg = await extractPage(40000);
    setLabel(row, 'Mencari soal di halaman…');
    const blockMode = pg.blocks.length >= 1 && (!pg.declared || pg.blocks.length >= pg.declared * 0.6);
    let items = [], batches = [], qText = '';
    if (blockMode) {
      items = pg.blocks.map((b, i) => ({
        no: i + 1, frameId: b.frameId, local: b.i, img: b.img,
        text: `[No. ${i + 1}] ${b.q}\n` + b.opts.map((o) => `${o.l}. ${o.t}`).join('\n') +
          (b.kind === 'checkbox' ? '\n(boleh lebih dari satu jawaban)' : '') + (b.img ? `\n(soal ini memuat ${b.img} gambar yang tidak terbaca)` : '')
      }));
      if (only) items = items.filter((it) => only.includes(it.no));
      batches = chunkItems(items);
      qText = items.map((i) => i.text).join('\n\n');
    } else {
      if (pg.text.length < 150) {
        try { pending = [await shrink(await chrome.tabs.captureVisibleTab(null, { format: 'png' }))]; renderStrip(); } catch (e) { /* lanjut */ }
      }
      qText = pg.text;
      batches = chunkText(pg.text).map((t) => ({ text: t }));
    }
    if (!batches.length) throw new Error('Tidak ada soal yang ditemukan di halaman ini.');
    const shots = pending.slice(0, 1);
    const provName = await provLabel();
    showInd('Mengirim ' + qText.length.toLocaleString('id') + ' karakter soal ke ' + provName + '…', 'send');

    const ask = async (prompt, label, partialBase) => {
      setLabel(row, label);
      const head = '> ' + label + '\n\n';
      if (acc) renderStream(row, head + acc);
      const r = await askAI([{ role: 'user', content: prompt, images: shots }], {
        signal: ctrl.signal, deep: true, maxTokens: 7000,
        onDelta: (t) => renderStream(row, head + (acc ? acc + '\n\n' : '') + t),
        onShrink: (pv) => setLabel(row, 'Memperkecil permintaan agar muat di batas ' + pv.name + '…'),
        onSwitch: (f, t) => setLabel(row, `${f.name} penuh, pindah ke ${t.name}…`),
        onActiveChanged: () => refreshProviderUI()
      });
      return r.text;
    };

    for (let i = 0; i < batches.length; i++) {
      const b = batches[i];
      const label = `Menjawab bagian ${i + 1} dari ${batches.length}…`;
      let prompt;
      if (blockMode) {
        const nums = b.map((x) => x.no);
        prompt = `Jawab SEMUA ${b.length} soal berikut (nomor ${nums.join(', ')}). Nomor di sini adalah urutan soal di halaman. Jangan ada yang dilewati atau digabung.\n${QUIZ_FORMAT}\n\nSOAL:\n\n${b.map((x) => x.text).join('\n\n')}`;
      } else {
        prompt = `Berikut bagian ${i + 1} dari ${batches.length} isi sebuah halaman web yang memuat soal. Temukan SEMUA soal pilihan ganda yang lengkap di bagian ini, lalu jawab semuanya secara berurutan memakai nomor asli di soal. Bagian bisa terpotong di awal/akhir: lewati soal yang terpotong (soal itu ada di bagian lain). Jika tidak ada soal, katakan singkat.\n${QUIZ_FORMAT}\n\nISI HALAMAN:\n"""\n${b.text}\n"""`;
      }
      const out = await ask(prompt, label, {});
      acc += (acc ? '\n\n' : '') + out;

      // pastikan setiap soal di bagian ini benar-benar terjawab; yang terlewat ditanyakan ulang
      if (blockMode) {
        for (let attempt = 0; attempt < 2; attempt++) {
          const got = parseAnswers(acc);
          const miss = b.filter((x) => !got.has(x.no));
          if (!miss.length) break;
          const p2 = `Soal nomor ${miss.map((x) => x.no).join(', ')} belum dijawab. Jawab HANYA soal-soal ini.\n${QUIZ_FORMAT}\n\nSOAL:\n\n${miss.map((x) => x.text).join('\n\n')}`;
          acc += '\n\n' + await ask(p2, `Melengkapi soal yang terlewat (${miss.length})…`, {});
        }
      }
    }

    // mode teks: cek nomor yang tertulis di halaman tapi belum terjawab
    if (!blockMode && pg.declared) {
      for (let attempt = 0; attempt < 2; attempt++) {
        const got = parseAnswers(acc);
        const miss = []; for (let n = 1; n <= pg.declared; n++) if (!got.has(n)) miss.push(n);
        if (!miss.length || miss.length > 40) break;
        const p2 = `Dari isi halaman di bawah, jawab HANYA soal nomor ${miss.join(', ')} (cari soalnya di teks, pakai nomor aslinya).\n${QUIZ_FORMAT}\n\nISI HALAMAN:\n"""\n${pg.text.slice(0, 30000)}\n"""`;
        acc += '\n\n' + await ask(p2, `Melengkapi soal yang terlewat (${miss.length})…`, {});
      }
    }

    // susun hasil akhir: urut nomor, tanpa duplikat
    const map = parseAnswers(acc);
    const nums = [...map.keys()].sort((a, b) => a - b);
    let final = nums.length ? nums.map((n) => map.get(n).text).join('\n\n') : acc;
    const total = blockMode ? (only ? only.length : items.length) : (pg.declared || nums.length);
    const answered = nums.filter((n) => !map.get(n).unsure && (!blockMode || !only || only.includes(n))).length;
    const unsure = nums.filter((n) => map.get(n).unsure);
    let missing = [];
    if (blockMode) missing = items.filter((i) => !map.has(i.no) || map.get(i.no).unsure).map((i) => i.no);
    else if (pg.declared) for (let n = 1; n <= pg.declared; n++) if (!map.has(n)) missing.push(n);
    final += `\n\n---\n**Terjawab ${answered} dari ${total} soal**`;
    if (missing.length) final += `\n\nBelum terjawab / ragu: nomor ${missing.join(', ')}.`;
    if (blockMode && items.some((i) => i.img)) final += `\n\nBeberapa soal memuat gambar yang tidak terbaca. Untuk soal itu, pakai tombol kamera lalu tanyakan lewat screenshot.`;
    if (pg.declared && blockMode && pg.blocks.length < pg.declared) final += `\n\nCatatan: halaman menyebut sekitar ${pg.declared} soal, tapi hanya ${pg.blocks.length} yang terdeteksi sebagai pilihan ganda (sisanya mungkin isian/esai atau belum dimuat; coba scroll lalu tekan tombol lagi).`;
    if (!blockMode && !nums.length) final = acc;

    // simpan konteks supaya pertanyaan lanjutan bisa dijawab
    history.push({ role: 'user', content: 'Soal-soal di halaman:\n' + qText.slice(0, 12000) + '\n\nJawab semua soal.', images: [] });
    history.push({ role: 'assistant', content: final, images: [] });
    log.push({ role: 'ai', text: final, kind: 'quiz', t: Date.now() });
    save();
    setAI(row, final, { follow: true, kind: 'quiz', regen: false });

    if (blockMode) {
      const prev = lastQuiz && only ? lastQuiz : { items: [], answers: new Map(), tabId: pg.tab.id };
      const merged = new Map(prev.answers);
      map.forEach((v, n) => { if (v.letters.length) merged.set(n, v.letters); });
      const allItems = only && lastQuiz ? lastQuiz.items : items;
      lastQuiz = { items: allItems, answers: merged, tabId: pg.tab.id };
    }
    const box = document.createElement('div');
    box.className = 'qact';
    if (blockMode && lastQuiz && lastQuiz.answers.size) {
      const b1 = document.createElement('button'); b1.type = 'button'; b1.className = 'btn'; b1.textContent = 'Tandai jawaban di halaman';
      b1.onclick = async () => { const n = await markQuiz(); b1.textContent = n ? `Ditandai ${n} pilihan ✓` : 'Pilihan tidak ditemukan'; };
      const b2 = document.createElement('button'); b2.type = 'button'; b2.className = 'btn'; b2.textContent = 'Hapus tanda';
      b2.onclick = async () => { await clearPageMarks(); };
      box.append(b1, b2);
    }
    if (missing.length && blockMode) {
      const b3 = document.createElement('button'); b3.type = 'button'; b3.className = 'btn primary'; b3.textContent = `Coba lagi ${missing.length} soal`;
      b3.onclick = () => runQuiz(missing);
      box.appendChild(b3);
    }
    if (box.children.length) row.querySelector('.col').insertBefore(box, row.querySelector('.follow'));
  } catch (err) {
    if (err.name === 'AbortError') {
      if (acc) { setAI(row, acc, {}); log.push({ role: 'ai', text: acc, kind: 'quiz', t: Date.now() }); save(); add('note', 'Dihentikan. Jawaban yang sudah selesai tetap ditampilkan.'); }
      else { row.remove(); add('note', 'Dihentikan.'); }
    } else {
      if (acc) { setAI(row, acc, {}); }
      else row.className = 'row err';
      if (acc) { const e2 = add('err', 'Berhenti di tengah jalan: ' + err.message); log.push({ role: 'err', text: err.message, t: Date.now() }); }
      else showError(row, err, false);
    }
  } finally {
    current = null; setBusy(false); scrollDown();
  }
}

async function markQuiz() {
  if (!lastQuiz) return 0;
  const byFrame = new Map();
  lastQuiz.answers.forEach((letters, no) => {
    const it = lastQuiz.items.find((i) => i.no === no);
    if (!it) return;
    if (!byFrame.has(it.frameId)) byFrame.set(it.frameId, []);
    byFrame.get(it.frameId).push({ q: it.local, letters });
  });
  let total = 0;
  for (const [fid, arr] of byFrame) {
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: lastQuiz.tabId, frameIds: [fid] }, func: pageMarkAnswers, args: [arr] });
      total += r.result || 0;
    } catch (e) { /* frame sudah hilang */ }
  }
  return total;
}
async function clearPageMarks() {
  try {
    const tab = await activeTab();
    if (!tab || !hostOf(tab.url)) return;
    await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: pageMarkAnswers, args: [[]] });
    await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: pageHighlight, args: [[], -1] });
  } catch (e) { /* abaikan */ }
}

quizBtn.onclick = () => runQuiz();

// ======================================================================
// ===== Perintah (Jelaskan / Ringkas / Terjemahkan / Tulis balasan / kustom) =====
// ======================================================================
async function readTarget() {
  if (window.LGB_WEB) { const t = input.value.trim(); if (!t) throw new Error('Tulis atau tempel teksnya di kolom dulu, lalu pilih perintah.'); input.value = ''; autoGrow(); return { text: t, label: 'teks yang kamu ketik' }; }
  const tab = await activeTab();
  if (!tab) throw new Error('Tidak ada tab aktif.');
  if (isYouTube(tab.url)) {
    // pilihan teks tetap diutamakan
    const pg = await extractPage(20000).catch(() => null);
    if (pg && pg.selection) return { text: pg.selection, label: 'teks terpilih' };
    if (!(await ensurePageConsent())) return null;
    const y = await getYouTube(tab);
    return { text: ytToText(y), label: 'transkrip video' };
  }
  if (isPdf(tab.url)) {
    if (!(await ensurePageConsent().catch(() => true))) return null;
    const p = await getTabPdf(tab);
    return { text: p.text, label: 'PDF ' + p.name };
  }
  const pg = await extractPage(14000);
  if (pg.selection) return { text: pg.selection, label: 'teks terpilih' };
  if (!(await ensurePageConsent())) return null;
  if (!pg.text) throw new Error('Halaman ini tidak punya teks yang bisa dibaca.');
  return { text: pg.text.slice(0, 14000), label: 'halaman ini' };
}

async function runCommand(cmd, override) {
  if (current) return;
  try {
    let text = override, label = 'teks yang kamu ketik';
    if (!text) {
      const t = await readTarget();
      if (!t) return;
      text = t.text; label = t.label;
    }
    const prompt = fillCmd(cmd, text, S.translateTo);
    await send(prompt, [], { display: cmd.name + ' — ' + label, kind: cmd.id in FOLLOWUPS ? cmd.id : 'chat', noPage: true, sent: label + ' · ' + text.length.toLocaleString('id') + ' karakter' });
  } catch (e) { add('err', e.message); }
}

async function pageAction(q, display, kind) {
  if (current) return;
  try {
    if (!(await ensurePageConsent())) return;
    await send(q, [], { display: display || q, kind: kind || 'chat', forcePage: true });
  } catch (e) { add('err', e.message); }
}

const cmdMenu = document.getElementById('cmdMenu');
async function buildCmdMenu() {
  const c = await getAllCmds();
  cmdMenu.innerHTML = '<div class="hint">Untuk teks yang di-highlight, atau seluruh halaman bila tidak ada.</div>';
  const item = (icon, label, fn, sm) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.innerHTML = (ICONS[icon] || ICONS.star) + '<span>' + esc(label) + '</span>' + (sm ? '<small>' + esc(sm) + '</small>' : '');
    b.onclick = () => { closePops(); fn(); };
    cmdMenu.appendChild(b);
  };
  c.builtin.forEach((cmd) => item(cmd.icon, cmd.name, () => runCommand(cmd)));
  cmdMenu.appendChild(document.createElement('hr'));
  c.study.forEach((cmd) => item(cmd.icon, cmd.name, () => runCommand(cmd)));
  if (c.custom.length) { cmdMenu.appendChild(document.createElement('hr')); c.custom.forEach((cc) => item('star', cc.name, () => runCommand(cc))); }
  cmdMenu.appendChild(document.createElement('hr'));
  item('star', 'Perintah baru…', () => openCmdEditor());
  cmdMenu.appendChild(document.createElement('hr'));
  item('star', 'Ekstrak data → JSON / CSV…', () => openExtractor());
}
document.getElementById('cmdBtn').onclick = async (e) => {
  e.stopPropagation();
  if (!cmdMenu.classList.contains('open')) await buildCmdMenu();
  togglePop(cmdMenu);
};

function slug(s) { return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''); }

function openCmdEditor(existing) {
  const sh = sheet(`<h3>Perintah kustom</h3>
    <p>Contoh: <i>Ringkas gaya tweet</i> atau <i>Ubah jadi caption IG</i>. Pakai <b>{{teks}}</b> untuk menyisipkan teks yang di-highlight / isi halaman.</p>
    <input type="text" id="cn" maxlength="40" placeholder="Nama perintah">
    <textarea class="f" id="cp" rows="5" placeholder="Ubah teks berikut menjadi caption Instagram yang santai dengan 3 hashtag:&#10;{{teks}}"></textarea>
    <div class="row-btns"><button class="btn primary" id="cs">Simpan</button><button class="btn" id="cc">Batal</button></div>`);
  const cn = sh.querySelector('#cn'), cp = sh.querySelector('#cp');
  if (existing) { cn.value = existing.name; cp.value = existing.prompt; }
  cn.focus();
  sh.querySelector('#cc').onclick = () => sh.close();
  sh.querySelector('#cs').onclick = async () => {
    const name = cn.value.trim(), prompt = cp.value.trim();
    if (!name || !prompt) return;
    const list = (S.customCmds || []).filter((x) => !existing || x.id !== existing.id);
    list.push({ id: existing ? existing.id : 'c' + Date.now(), name, prompt });
    S.customCmds = list;
    await chrome.storage.local.set({ customCmds: list });
    sh.close();
    add('note', 'Perintah "' + name + '" disimpan. Pakai lewat menu ⋮, Ctrl+K, atau ketik /' + slug(name));
  };
}

// ======================================================================
// ===== Gambar AI =====
// ======================================================================
const IMG_INTENT = /^(?:tolong\s+)?(?:(?:buat(?:kan)?|bikin(?:kan)?|generate|create|draw|render|lukis(?:kan)?)\s+(?:sebuah\s+|satu\s+|an?\s+|me\s+)?(?:gambar|foto|ilustrasi|image|picture|logo|poster|wallpaper|lukisan|sketsa|avatar|ikon|icon|photo)\b|gambarkan\s)/i;
let lastGenPrompt = '';

function setImageMode(on) {
  imageMode = on;
  document.getElementById('imgbar').hidden = !on;
  document.getElementById('imagine').classList.toggle('on', on);
  input.placeholder = on ? 'Deskripsikan gambar yang ingin dibuat…' : 'Tulis pertanyaan… ( / untuk perintah )';
  document.querySelectorAll('#sizeSeg button').forEach((b) => b.classList.toggle('on', b.dataset.size === imgSize));
  if (on) input.focus();
}
document.getElementById('imagine').onclick = () => setImageMode(!imageMode);
document.getElementById('imgOff').onclick = () => setImageMode(false);
document.querySelectorAll('#sizeSeg button').forEach((b) => {
  b.onclick = () => { imgSize = b.dataset.size; chrome.storage.local.set({ imgSize }); setImageMode(true); };
});

function openImage(src) {
  fetch(src).then((r) => r.blob()).then((b) => window.open(URL.createObjectURL(b), '_blank')).catch(() => {});
}

async function toPngBlob(dataUrl) {
  const img = new Image();
  await new Promise((ok, no) => { img.onload = ok; img.onerror = no; img.src = dataUrl; });
  const c = document.createElement('canvas');
  c.width = img.naturalWidth; c.height = img.naturalHeight;
  c.getContext('2d').drawImage(img, 0, 0);
  return new Promise((r) => c.toBlob(r, 'image/png'));
}

function showGen(row, g) {
  row.className = 'row ai';
  lastGenPrompt = g.prompt;
  const msg = row.querySelector('.msg');
  msg.className = 'msg';
  msg.innerHTML = '';
  const fig = document.createElement('figure');
  fig.className = 'genimg';
  const im = document.createElement('img');
  im.src = g.dataUrl; im.alt = g.prompt;
  im.onclick = () => openImage(g.dataUrl);
  const cap = document.createElement('figcaption');
  cap.innerHTML = ic('palette', 12) + ' ' + esc(g.prompt + ' · ' + (g.engine || '') + (g.model ? ' (' + g.model + ')' : ''));
  fig.append(im, cap);
  msg.appendChild(fig);
  const col = row.querySelector('.col');
  col.querySelector('.tools')?.remove();
  const tools = document.createElement('div');
  tools.className = 'tools';
  toolBtn(tools, ICONS.down, 'Unduh', () => {
    const a = document.createElement('a');
    a.href = g.dataUrl; a.download = 'gambar-ai-' + Date.now() + (g.dataUrl.startsWith('data:image/jpeg') ? '.jpg' : '.png');
    document.body.appendChild(a); a.click(); a.remove();
  });
  toolBtn(tools, COPY_ICON, 'Salin', async (b) => {
    const span = b.querySelector('span');
    try { const blob = await toPngBlob(g.dataUrl); await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]); span.textContent = 'Tersalin'; } catch { span.textContent = 'Gagal'; }
    setTimeout(() => (span.textContent = 'Salin'), 1200);
  });
  toolBtn(tools, ICONS.retry, 'Buat ulang', () => generateAndShow(g.prompt));
  toolBtn(tools, ICONS.star, 'Jadikan referensi', () => { if (pending.length < MAX_IMAGES) { pending.push(g.dataUrl); renderStrip(); input.placeholder = 'Tanya tentang gambar ini…'; input.focus(); } });
  col.appendChild(tools);
}

async function generateAndShow(prompt) {
  if (current) return;
  qchips.hidden = true;
  const shown = 'Gambar: ' + prompt;
  add('user', shown);
  log.push({ role: 'user', text: shown, t: Date.now() });
  const row = typing('Menyiapkan gambar…');
  const ctrl = new AbortController();
  current = { ctrl };
  setBusy(true);
  try {
    const r = await generateImage(prompt, { size: imgSize, signal: ctrl.signal, onStatus: (t) => setLabel(row, t) });
    const g = { prompt, dataUrl: r.dataUrl, engine: r.engine, model: r.model };
    showGen(row, g);
    addFollow(row, 'image');
    history.push({ role: 'user', content: '[Pengguna meminta dibuatkan gambar] ' + prompt, images: [] },
      { role: 'assistant', content: '[Gambar sudah dibuat untuk permintaan: ' + prompt + ']', images: [] });
    log.push({ role: 'ai', text: '', gen: g, kind: 'image', t: Date.now() });
    save();
  } catch (e) {
    if (e.name === 'AbortError') { row.remove(); add('note', 'Pembuatan gambar dihentikan.'); }
    else showError(row, e, false);
  } finally {
    current = null; setBusy(false); scrollDown();
  }
}

// ======================================================================
// ===== Multi-tab =====
// ======================================================================
async function openTabPicker() {
  const sh = sheet('<h3>Konteks beberapa tab</h3><div id="tbody"></div>');
  const body = sh.querySelector('#tbody');
  const list = async () => {
    const tabs = (await chrome.tabs.query({ currentWindow: true })).filter((t) => hostOf(t.url));
    if (!tabs.length) { body.innerHTML = '<p>Tidak ada tab web yang bisa dibaca di jendela ini.</p>'; return; }
    body.innerHTML = '<p>Pilih sampai 5 tab. Isinya hanya dibaca setelah kamu menekan "Pakai tab ini" dan dikirim ke AI saat kamu bertanya.</p>';
    tabs.forEach((t) => {
      const r = document.createElement('label');
      r.className = 'tabrow';
      r.innerHTML = `<input type="checkbox" data-id="${t.id}"><img src="${t.favIconUrl && /^https?:/.test(t.favIconUrl) ? esc(t.favIconUrl) : 'icons/icon16.png'}" alt=""><span class="tt"><b>${esc(t.title || t.url)}</b><small>${esc(hostOf(t.url))}${t.active ? ' · tab ini' : ''}</small></span>`;
      if (t.active) r.querySelector('input').checked = true;
      body.appendChild(r);
    });
    const bt = document.createElement('div');
    bt.className = 'row-btns';
    bt.innerHTML = '<button class="btn primary" id="use">Pakai tab ini</button><button class="btn" id="cx">Batal</button>';
    body.appendChild(bt);
    bt.querySelector('#cx').onclick = () => sh.close();
    bt.querySelector('#use').onclick = async () => {
      const ids = [...body.querySelectorAll('input:checked')].map((i) => +i.dataset.id).slice(0, 5);
      if (!ids.length) return;
      const chosen = tabs.filter((t) => ids.includes(t.id));
      const origins = [...new Set(chosen.filter((t) => !t.active).map((t) => new URL(t.url).origin + '/*'))];
      if (origins.length) {
        const granted = await chrome.permissions.request({ origins });
        if (!granted) { body.insertAdjacentHTML('afterbegin', '<p style="color:#ef4444">Izin membaca tab ditolak.</p>'); return; }
      }
      bt.querySelector('#use').disabled = true; bt.querySelector('#use').textContent = 'Membaca…';
      const out = [];
      for (const t of chosen) {
        try {
          const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, func: pageExtract, args: [9000] });
          const txt = (r.result && (r.result.text || '')) || '';
          out.push({ title: t.title || t.url, url: t.url, text: txt.slice(0, 9000), sent: false });
        } catch (e) { out.push({ title: t.title || t.url, url: t.url, text: '(gagal dibaca: ' + e.message + ')', sent: false }); }
      }
      tabCtx = out; renderStrip(); sh.close();
      showQuick(['Bandingkan tab-tab ini', 'Gabungkan informasi dari semua tab', 'Buat tabel perbandingan']);
    };
  };
  if (await chrome.permissions.contains({ permissions: ['tabs'] })) { await list(); return; }
  body.innerHTML = '<p>Untuk menampilkan daftar tab yang terbuka, Chrome perlu izin "tabs". Izin ini hanya dipakai saat kamu membuka daftar ini; isi tab baru dibaca setelah kamu memilihnya.</p><div class="row-btns"><button class="btn primary" id="grant">Izinkan lihat daftar tab</button><button class="btn" id="cx">Batal</button></div>';
  body.querySelector('#cx').onclick = () => sh.close();
  body.querySelector('#grant').onclick = async () => {
    const ok = await chrome.permissions.request({ permissions: ['tabs'] });
    if (ok) await list(); else body.querySelector('p').textContent = 'Izin ditolak, jadi daftar tab tidak bisa ditampilkan.';
  };
}
document.getElementById('tabsBtn').onclick = openTabPicker;

// ======================================================================
// ===== Riwayat chat (AnimatedList) =====
// ======================================================================
function relTime(ts) {
  const d = Math.max(0, Date.now() - ts), m = Math.floor(d / 60000);
  if (m < 1) return 'baru';
  if (m < 60) return m + 'm';
  const h = Math.floor(m / 60); if (h < 24) return h + 'j';
  const dd = Math.floor(h / 24); if (dd < 7) return dd + 'h';
  const w = Math.floor(dd / 7); if (w < 5) return w + 'mg';
  return new Date(ts).toLocaleDateString('id', { day: 'numeric', month: 'short' });
}
const ICON_CHAT = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H8l-5 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>';
const ICON_TRASH = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2m2 0-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>';
const ICON_DOTS = '<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg>';
const ICON_PIN = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 17v5M9 3h6l-1 6 3 3v2H7v-2l3-3z"/></svg>';
async function updateChat(id, fn) {
  const cur = await chrome.storage.local.get({ chats: [] });
  const next = cur.chats.map((c) => (c.id === id ? fn(Object.assign({}, c, { mt: Date.now() })) : c)).filter(Boolean);
  await chrome.storage.local.set({ chats: next });
  Acct.syncSoon();
}
// Menu konteks (klik kanan / tombol ⋯ / tombol P, R, C, D pada baris terpilih)
function ctxMenu(anchorX, anchorY, entries, onClose) {
  const m = document.createElement('div');
  m.className = 'ctxm';
  m.innerHTML = entries.map((en, i) => en === '-' ? '<div class="ctxm__sep"></div>' :
    '<button type="button" class="ctxm__it' + (en.danger ? ' danger' : '') + '" data-i="' + i + '"><span>' + esc(en.label) + '</span><kbd>' + esc(en.key) + '</kbd></button>').join('');
  document.body.appendChild(m);
  const w = m.offsetWidth, h = m.offsetHeight;
  m.style.left = Math.max(6, Math.min(anchorX, innerWidth - w - 6)) + 'px';
  m.style.top = Math.max(6, Math.min(anchorY, innerHeight - h - 6)) + 'px';
  requestAnimationFrame(() => m.classList.add('on'));
  let closed = false;
  const close = () => { if (closed) return; closed = true; document.removeEventListener('mousedown', away, true); document.removeEventListener('keydown', key, true); m.classList.remove('on'); setTimeout(() => m.remove(), 120); onClose && onClose(); };
  const run = (en) => { close(); setTimeout(() => en.run(), 30); };
  const away = (e) => { if (!m.contains(e.target)) { e.stopPropagation(); close(); } };
  const key = (e) => {
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); return; }
    const en = entries.find((x) => x !== '-' && x.key.toLowerCase() === e.key.toLowerCase());
    if (en && !e.ctrlKey && !e.metaKey && !e.altKey) { e.preventDefault(); e.stopPropagation(); run(en); }
  };
  m.addEventListener('click', (e) => { const b = e.target.closest('.ctxm__it'); if (b) run(entries[+b.dataset.i]); });
  document.addEventListener('mousedown', away, true);
  document.addEventListener('keydown', key, true);
  return { close };
}
function renameDialog(current, done) {
  const sh = sheet('<h3>Ganti nama</h3><input id="rn" class="rn-in" maxlength="80" autocomplete="off"><div class="row-btns"><button class="btn" id="rnok">Simpan</button><button class="btn" id="rncancel">Batal</button></div>', 'rename');
  const inp = sh.querySelector('#rn'); inp.value = current; setTimeout(() => { inp.focus(); inp.select(); }, 60);
  const ok = () => { const v = inp.value.trim(); sh.close(); if (v && v !== current) done(v); };
  sh.querySelector('#rnok').onclick = ok; sh.querySelector('#rncancel').onclick = () => sh.close();
  inp.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); ok(); } else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); sh.close(); } };
}
async function openHistory() {
  if (topSheet()?.classList.contains('hist')) return;
  const sh = sheet('<h3>Riwayat chat <span class="h-r"><small id="hc"></small><button type="button" class="btn h-acct" id="hacct">Akun</button></span></h3><div id="hl"></div><div class="hist-foot" id="hf"></div>', 'hist hist-sheet');
  sh.querySelector('#hacct').onclick = () => openAccount();
  const onSynced = () => render();
  window.addEventListener('lgb-synced', onSynced);
  const box = sh.querySelector('#hl'), foot = sh.querySelector('#hf'), cnt = sh.querySelector('#hc');
  let list = null, items = [], menuOpen = false;
  const render = async (keepIdx) => {
    const st = await chrome.storage.local.get({ chats: [] });
    const chats = st.chats.slice().sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0));
    cnt.textContent = chats.length ? chats.length + ' percakapan' : '';
    if (list) { list.destroy(); list = null; }
    box.innerHTML = ''; foot.innerHTML = '';
    if (!chats.length) {
      box.innerHTML = '<div class="hist-empty">' + (S.noHistory ? 'Riwayat dimatikan (mode "Jangan simpan riwayat chat").' : 'Belum ada riwayat. Percakapan lama muncul di sini setelah kamu mulai percakapan baru.') + '</div>';
      return;
    }
    items = chats.map((c) => {
      const ai = (c.log || []).find((m) => m.role === 'ai' && m.text);
      const n = (c.log || []).filter((m) => m.role === 'user').length;
      const snip = ai ? ai.text.replace(/[#*`>_\[\]]/g, '').replace(/\s+/g, ' ').trim().slice(0, 60) : '';
      return {
        id: c.id, title: c.title || 'Percakapan', description: n + ' pesan' + (snip ? ' · ' + snip : ''), meta: relTime(c.ts), icon: c.pinned ? ICON_PIN : ICON_CHAT, chat: c,
        actions: [{ title: 'Opsi', icon: ICON_DOTS, onClick: (it, i, ev) => { const r = ev.target.closest('button').getBoundingClientRect(); openMenu(it, r.right - 150, r.bottom + 4); } }]
      };
    });
    list = AnimatedList(box, {
      items, animation: window.LGB_LITE ? 'none' : 'pop', showGradients: !window.LGB_LITE, maxHeight: 300, fadeSize: 36,
      initialSelectedIndex: keepIdx >= 0 && keepIdx < items.length ? keepIdx : -1,
      onItemSelect: (it) => openChat(it),
      onContextMenu: (it, i, ev) => openMenu(it, ev.clientX, ev.clientY)
    });
    list.focus();
    const clr = document.createElement('button');
    clr.type = 'button'; clr.className = 'btn'; clr.textContent = 'Hapus semua';
    clr.onclick = async () => { if (clr.dataset.sure) { const all = (await chrome.storage.local.get({ chats: [] })).chats.map((x) => x.id); await chrome.storage.local.set({ chats: [] }); Acct.tombstone(all); render(); } else { clr.dataset.sure = '1'; clr.textContent = 'Yakin? Klik lagi'; setTimeout(() => { clr.dataset.sure = ''; clr.textContent = 'Hapus semua'; }, 2500); } };
    const tip = document.createElement('small'); tip.style.color = 'var(--muted)'; tip.textContent = '↑↓ pilih · klik kanan: opsi';
    foot.append(tip, clr);
  };
  const openChat = (it) => { sh.close(); setTimeout(() => loadChat(it.chat), 140); };
  const idxOf = (it) => items.findIndex((x) => x.id === it.id);
  const entriesFor = (it) => [
    { label: 'Buka', key: 'Enter', run: () => openChat(it) },
    '-',
    { label: it.chat.pinned ? 'Lepas pin' : 'Pin', key: 'P', run: async () => { await updateChat(it.id, (c) => { c.pinned = !c.pinned; return c; }); render(); } },
    { label: 'Ganti nama', key: 'R', run: () => renameDialog(it.title, async (v) => { await updateChat(it.id, (c) => { c.title = v; return c; }); render(idxOf(it)); }) },
    { label: 'Salin judul', key: 'C', run: () => { navigator.clipboard.writeText(it.title).catch(() => {}); } },
    '-',
    { label: 'Hapus', key: 'D', danger: true, run: async () => { const i = idxOf(it); const cur = await chrome.storage.local.get({ chats: [] }); await chrome.storage.local.set({ chats: cur.chats.filter((x) => x.id !== it.id) }); Acct.tombstone(it.id); render(i); } }
  ];
  function openMenu(it, x, y) {
    if (menuOpen) return;
    menuOpen = true;
    ctxMenu(x, y, entriesFor(it), () => { menuOpen = false; list && list.focus(); });
  }
  // pintasan langsung pada baris terpilih: P, R, C, D
  sh.addEventListener('keydown', (e) => {
    if (menuOpen || e.ctrlKey || e.metaKey || e.altKey || !list || /^(INPUT|TEXTAREA)$/.test(e.target.tagName)) return;
    const i = list.getSelected(); if (i < 0 || !items[i]) return;
    const en = entriesFor(items[i]).find((x) => x !== '-' && x.key.length === 1 && x.key.toLowerCase() === e.key.toLowerCase());
    if (en) { e.preventDefault(); en.run(); }
    else if (e.key === 'ContextMenu' || (e.shiftKey && e.key === 'F10')) { e.preventDefault(); const r = list.itemEl(i).getBoundingClientRect(); openMenu(items[i], r.right - 150, r.bottom); }
  });
  const prevClose = sh.close;
  sh.close = () => { window.removeEventListener('lgb-synced', onSynced); if (list) { list.destroy(); list = null; } prevClose(); };
  render();
}
document.getElementById('hist').onclick = openHistory;

// ======================================================================
// ===== Akun & sinkronisasi =====
// ======================================================================
async function openAccount() {
  if (topSheet()?.classList.contains('acct')) return;
  const sh = sheet('<div id="ab"></div>', 'acct hist-sheet');
  const ab = sh.querySelector('#ab');
  let mode = 'pw', editServer = false, editGoogle = false, busy = false, codeSent = false, msg = null;
  const fmt = (t) => t ? new Date(t).toLocaleString('id', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'belum pernah';
  const flash = (text, ok) => { msg = { text, ok }; draw(); };
  async function run(fn, okText) {
    if (busy) return; busy = true; msg = null; draw();
    try { await fn(); if (okText) msg = { text: okText, ok: true }; } catch (e) { msg = { text: e.message, ok: false }; }
    busy = false; draw();
  }
  const afterLogin = async () => { await Acct.sync(); await loadChatsIntoUI(); };
  async function draw() {
    const configured = await Acct.configured(), user = await Acct.user(), c = await Acct.cfg();
    const last = (await chrome.storage.local.get({ acctLastSync: 0 })).acctLastSync;
    const m = msg ? '<div class="ac-msg ' + (msg.ok ? 'ok' : 'bad') + '">' + esc(msg.text) + '</div>' : '';
    const dis = busy ? ' disabled' : '';
    const sess = await Acct.session(), isG = sess && sess.kind === 'google', gReady = await Acct.googleReady(), gCid = (await chrome.storage.local.get({ acctGoogleCid: '' })).acctGoogleCid;
    let html = '<h3>Akun & sinkronisasi</h3>';
    if (user && !editServer && !editGoogle) {
      html += '<p class="ac-p">Masuk sebagai <b>' + esc(user.name || user.email || 'akun') + '</b>' + (user.name ? '<br><small>' + esc(user.email) + '</small>' : '') + ' <small>(' + (isG ? 'Google · disimpan di Drive-mu' : 'server Supabase') + ')</small><br>Riwayat chat, memori, persona & perintah kustom disinkronkan. API key tidak pernah dikirim.<br><small>Sinkron terakhir: ' + esc(fmt(last)) + '</small></p>' + m +
        '<div class="row-btns"><button class="btn" id="aSync"' + dis + '>' + (busy ? 'Menyinkronkan…' : 'Sinkronkan sekarang') + '</button>' + (isG ? '<button class="btn" id="aSwitch"' + dis + '>Ganti akun Google</button>' : '') + '<button class="btn" id="aOut"' + dis + '>Keluar</button></div>';
    } else if (editGoogle) {
      html += '<p class="ac-p">Login Google langsung (tanpa server): kamu bisa <b>memilih akun Google</b>, dan riwayat disimpan di folder tersembunyi Google Drive-mu. Butuh <b>OAuth Client ID</b> sekali saja.</p>' +
        '<input class="rn-in" id="gCid" placeholder="xxxx.apps.googleusercontent.com" value="' + esc(gCid) + '" autocomplete="off">' + m +
        '<div class="row-btns"><button class="btn" id="gSave">Simpan & lanjut</button><button class="btn" id="gBack">Batal</button></div>' +
        '<p class="ac-p ac-small">console.cloud.google.com → proyek baru → <b>APIs & Services → Library</b>: aktifkan <b>Google Drive API</b> → <b>OAuth consent screen</b> (External, tambahkan emailmu sebagai test user) → <b>Credentials → Create credentials → OAuth client ID → Web application</b> → Authorized redirect URI: <code>' + esc('https://' + chrome.runtime.id + '.chromiumapp.org/') + '</code> → salin Client ID ke atas.</p>';
    } else if (editServer) {
      html += '<p class="ac-p">Metode email, kode, GitHub, Discord & Microsoft memakai server <b>Supabase</b> milikmu (gratis). Isi URL & anon key proyekmu.</p>' +
        '<input class="rn-in" id="aUrl" placeholder="https://xxxx.supabase.co" value="' + esc(c.url) + '" autocomplete="off"><input class="rn-in" id="aKey" placeholder="anon public key" value="' + esc(c.key) + '" autocomplete="off" style="margin-top:8px">' + m +
        '<div class="row-btns"><button class="btn" id="aSave">Simpan</button><button class="btn" id="aBack">Batal</button><button class="btn" id="aSql">Salin SQL tabel</button></div>' +
        '<p class="ac-p ac-small">Setup sekali: supabase.com → proyek baru → SQL Editor → tempel SQL (tombol di atas) → Authentication → URL Configuration → Redirect URL: <code>' + esc('https://' + chrome.runtime.id + '.chromiumapp.org/') + '</code>. Aktifkan provider (GitHub/Discord/Azure) di Authentication → Providers.</p>';
    } else {
      html += '<button class="btn ac-google" id="aG"' + dis + '><svg width="16" height="16" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.6 5.9c4.4-4.1 7-10.1 7-17.6z"/><path fill="#FBBC05" d="M10.5 28.7c-.5-1.5-.8-3-.8-4.7s.3-3.2.8-4.7l-7.9-6.1C.9 16.4 0 20.1 0 24s.9 7.6 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.6-5.9c-2.1 1.4-4.9 2.3-8.3 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg> Lanjutkan dengan Google</button>' +
        '<p class="ac-p ac-small" style="margin:6px 2px 0">' + (gReady ? 'Pilih akun Google yang mau dipakai. Riwayat disimpan di Drive-mu sendiri, tanpa server.' : 'Sekali setup: masukkan Client ID Google (klik tombol di atas).') + (gReady ? ' <a href="#" id="aGcfg">Ubah Client ID</a>' : '') + '</p>' + m;
      if (!configured) {
        html += '<div class="ac-or"><span>metode lain</span></div><div class="row-btns" style="margin-top:0"><button class="btn" id="aSrv">Email, GitHub, Discord… (butuh server Supabase)</button></div>';
      } else {
        html += '<div class="ac-or"><span>metode lain</span></div><div class="seg ac-seg"><button class="' + (mode === 'pw' ? 'on' : '') + '" data-m="pw">Email & password</button><button class="' + (mode === 'code' ? 'on' : '') + '" data-m="code">Kode email</button></div>' +
          '<input class="rn-in" id="aEmail" type="email" placeholder="email@kamu.com" autocomplete="email" style="margin-top:10px">';
        if (mode === 'pw') html += '<input class="rn-in" id="aPw" type="password" placeholder="Password (min. 6 karakter)" autocomplete="current-password" style="margin-top:8px">' +
          '<div class="row-btns"><button class="btn" id="aIn"' + dis + '>Masuk</button><button class="btn" id="aUp"' + dis + '>Daftar</button></div>';
        else html += (codeSent ? '<input class="rn-in" id="aCode" inputmode="numeric" placeholder="Kode dari email" autocomplete="one-time-code" style="margin-top:8px">' : '') +
          '<div class="row-btns">' + (codeSent ? '<button class="btn" id="aVerify"' + dis + '>Verifikasi</button>' : '') + '<button class="btn" id="aSend"' + dis + '>' + (codeSent ? 'Kirim ulang' : 'Kirim kode ke email') + '</button></div>';
        html += '<div class="row-btns" style="margin-top:8px"><button class="btn" id="aGithub"' + dis + '>GitHub</button><button class="btn" id="aDiscord"' + dis + '>Discord</button><button class="btn" id="aAzure"' + dis + '>Microsoft</button><button class="btn" id="aSrv">Server</button></div>';
      }
    }
    const keep = {}; ab.querySelectorAll('input').forEach((i) => { keep[i.id] = i.value; });
    ab.innerHTML = html;
    ab.querySelectorAll('input').forEach((i) => { if (keep[i.id] && !i.value) i.value = keep[i.id]; });
    const $ = (id) => ab.querySelector(id), val = (id) => ($(id) ? $(id).value.trim() : '');
    const on = (id, fn) => { const e = $(id); if (e) e.onclick = fn; };
    ab.querySelectorAll('.ac-seg button').forEach((b) => { b.onclick = () => { mode = b.dataset.m; msg = null; draw(); }; });
    on('#aG', () => run(async () => { try { await Acct.googleSignIn(); } catch (e) { if (e.message === 'NEED_CID') { editGoogle = true; return; } throw e; } await afterLogin(); }, 'Berhasil masuk dengan Google.'));
    on('#aGcfg', () => { editGoogle = true; msg = null; draw(); });
    ab.querySelectorAll('a#aGcfg').forEach((x) => { x.onclick = (ev) => { ev.preventDefault(); editGoogle = true; msg = null; draw(); }; });
    on('#gBack', () => { editGoogle = false; msg = null; draw(); });
    on('#gSave', () => run(async () => { const v = val('#gCid'); if (!/^[0-9]+-[a-z0-9]+\.apps\.googleusercontent\.com$/i.test(v)) throw new Error('Itu bukan Client ID Google. Bentuknya 123456789-abc….apps.googleusercontent.com (bukan ID extension).'); await Acct.setGoogleCid(v); editGoogle = false; }, 'Client ID disimpan. Klik "Lanjutkan dengan Google".'));
    on('#aSwitch', () => run(async () => { await Acct.signOut(); await Acct.googleSignIn(); await afterLogin(); }, 'Akun diganti & tersinkron.'));
    on('#aDiscord', () => run(async () => { await Acct.oauth('discord'); await afterLogin(); }, 'Berhasil masuk dengan Discord.'));
    on('#aAzure', () => run(async () => { await Acct.oauth('azure'); await afterLogin(); }, 'Berhasil masuk dengan Microsoft.'));
    on('#aSave', () => run(async () => { const u = val('#aUrl'), k = val('#aKey'); if (!/^https?:\/\//i.test(u) || !k) throw new Error('Isi URL (https://…) dan anon key dengan benar.'); await Acct.saveConfig(u, k); editServer = false; }, 'Server disimpan.'));
    on('#aBack', () => { editServer = false; msg = null; draw(); });
    on('#aSrv', () => { editServer = true; msg = null; draw(); });
    on('#aSql', () => { navigator.clipboard.writeText(Acct.SQL).then(() => flash('SQL disalin. Tempel di Supabase → SQL Editor → Run.', true), () => flash('Gagal menyalin.', false)); });
    on('#aIn', () => run(async () => { const e = val('#aEmail'), pw = $('#aPw').value; if (!e || !pw) throw new Error('Isi email dan password.'); await Acct.signIn(e, pw); await afterLogin(); }, 'Berhasil masuk & tersinkron.'));
    on('#aUp', () => run(async () => { const e = val('#aEmail'), pw = $('#aPw').value; if (!e || pw.length < 6) throw new Error('Isi email dan password (min. 6 karakter).'); const r = await Acct.signUp(e, pw); if (r.signedIn) await afterLogin(); else throw new Error('Akun dibuat. Cek email untuk konfirmasi, lalu pilih Masuk.'); }));
    on('#aSend', () => run(async () => { const e = val('#aEmail'); if (!e) throw new Error('Isi email dulu.'); await Acct.sendCode(e); codeSent = true; }, 'Kode dikirim. Cek email lalu masukkan kodenya.'));
    on('#aVerify', () => run(async () => { const e = val('#aEmail'), t = val('#aCode'); if (!e || !t) throw new Error('Isi email dan kode.'); await Acct.verifyCode(e, t); codeSent = false; await afterLogin(); }, 'Berhasil masuk & tersinkron.'));
    on('#aGithub', () => run(async () => { await Acct.oauth('github'); await afterLogin(); }, 'Berhasil masuk dengan GitHub.'));
    on('#aSync', () => run(async () => { await Acct.sync(); await loadChatsIntoUI(); }, 'Tersinkron.'));
    on('#aOut', () => run(async () => { await Acct.signOut(); }, 'Sudah keluar. Data di perangkat ini tetap ada.'));
    const inp = ab.querySelector('input'); if (inp && !inp.value) inp.focus();
  }
  draw();
}
// memuat ulang catatan memori/persona dari storage setelah sinkron
async function loadChatsIntoUI() {
  const s = await chrome.storage.local.get({ memoryNotes: '', persona: 'default' });
  S.memoryNotes = s.memoryNotes; S.persona = s.persona;
  try { memNotes.value = s.memoryNotes || ''; if (PERSONAS[s.persona]) personaSel.value = s.persona; } catch (e) { /* abaikan */ }
  window.dispatchEvent(new CustomEvent('lgb-synced'));
}

// ======================================================================
// ===== Ekspor instan: .md, Google Docs, Notion =====
// ======================================================================
function chatMarkdown() {
  const first = log.find((m) => m.role === 'user');
  const title = (first ? first.text : 'Percakapan').replace(/\s+/g, ' ').slice(0, 60);
  const body = log.filter((m) => m.role === 'user' || m.role === 'ai').map((m) => (m.role === 'user' ? '### Kamu\n\n' : '### AI\n\n') + (m.text || '').trim()).join('\n\n---\n\n');
  return { title, md: '# ' + title + '\n\n_Diekspor dari Los Gk Bawel AI · ' + new Date().toLocaleString('id') + '_\n\n' + body + '\n' };
}
function downloadFile(name, text, mime) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: mime || 'text/plain;charset=utf-8' }));
  a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
const safeName = (t) => (t || 'chat').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 60) || 'chat';
function mdToBlocks(md) {
  const blocks = [], rt = (t) => { const out = []; for (let i = 0; i < t.length; i += 1900) out.push({ type: 'text', text: { content: t.slice(i, i + 1900) } }); return out; };
  let code = null;
  md.split('\n').forEach((ln) => {
    if (/^```/.test(ln)) { if (code) { blocks.push({ object: 'block', type: 'code', code: { rich_text: rt(code.join('\n') || ' '), language: 'plain text' } }); code = null; } else code = []; return; }
    if (code) { code.push(ln); return; }
    let m;
    if (!ln.trim()) return;
    if ((m = ln.match(/^(#{1,3})\s+(.*)/))) blocks.push({ object: 'block', type: 'heading_' + m[1].length, ['heading_' + m[1].length]: { rich_text: rt(m[2]) } });
    else if ((m = ln.match(/^\s*[-*]\s+(.*)/))) blocks.push({ object: 'block', type: 'bulleted_list_item', bulleted_list_item: { rich_text: rt(m[1]) } });
    else if ((m = ln.match(/^\s*\d+[.)]\s+(.*)/))) blocks.push({ object: 'block', type: 'numbered_list_item', numbered_list_item: { rich_text: rt(m[1]) } });
    else if (/^---+$/.test(ln.trim())) blocks.push({ object: 'block', type: 'divider', divider: {} });
    else blocks.push({ object: 'block', type: 'paragraph', paragraph: { rich_text: rt(ln.replace(/\*\*(.*?)\*\*/g, '$1')) } });
  });
  return blocks;
}
async function exportNotion(title, md) {
  const st = await chrome.storage.local.get({ notionToken: '', notionParent: '' });
  if (!st.notionToken || !st.notionParent) { await notionSetup(); return; }
  const ok = await chrome.permissions.request({ origins: ['https://api.notion.com/*'] }).catch(() => false);
  if (!ok) throw new Error('Izin akses Notion ditolak.');
  const pid = (st.notionParent.match(/[0-9a-f]{32}/i) || st.notionParent.replace(/-/g, '').match(/[0-9a-f]{32}/i) || [])[0];
  if (!pid) throw new Error('ID halaman Notion tidak valid. Buka Ekspor → Notion lagi untuk memperbaikinya.');
  const blocks = mdToBlocks(md);
  const hdr = { Authorization: 'Bearer ' + st.notionToken, 'Notion-Version': '2022-06-28', 'Content-Type': 'application/json' };
  const r = await fetch('https://api.notion.com/v1/pages', { method: 'POST', headers: hdr, body: JSON.stringify({ parent: { page_id: pid }, properties: { title: { title: [{ text: { content: title.slice(0, 100) } }] } }, children: blocks.slice(0, 100) }) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error('Notion: ' + (j.message || r.status) + (r.status === 404 ? ' (pastikan halaman sudah di-share ke integrasimu)' : ''));
  for (let i = 100; i < blocks.length; i += 100) {
    const r2 = await fetch('https://api.notion.com/v1/blocks/' + j.id + '/children', { method: 'PATCH', headers: hdr, body: JSON.stringify({ children: blocks.slice(i, i + 100) }) });
    if (!r2.ok) throw new Error('Notion: gagal menulis sebagian isi.');
  }
  if (j.url) chrome.tabs.create({ url: j.url });
  return 'Terkirim ke Notion.';
}
function notionSetup() {
  return new Promise((res) => {
    const sh = sheet('<h3>Hubungkan Notion</h3><p class="ac-p">Buat integrasi di notion.so/my-integrations (Internal), salin <b>Secret</b>, lalu di Notion buka halaman tujuan → ⋯ → Connections → tambahkan integrasimu. Tempel link/ID halaman itu di bawah.</p><input class="rn-in" id="nt" type="password" placeholder="Internal integration secret (secret_… / ntn_…)" autocomplete="off"><input class="rn-in" id="np" placeholder="Link / ID halaman tujuan" autocomplete="off" style="margin-top:8px"><div class="row-btns"><button class="btn" id="nok">Simpan</button><button class="btn" id="nno">Batal</button></div>', 'rename');
    chrome.storage.local.get({ notionToken: '', notionParent: '' }).then((s) => { sh.querySelector('#nt').value = s.notionToken; sh.querySelector('#np').value = s.notionParent; });
    sh.querySelector('#nok').onclick = async () => { await chrome.storage.local.set({ notionToken: sh.querySelector('#nt').value.trim(), notionParent: sh.querySelector('#np').value.trim() }); sh.close(); add('note', 'Notion tersimpan. Pilih Ekspor → Notion lagi.'); res(); };
    sh.querySelector('#nno').onclick = () => { sh.close(); res(); };
  });
}
function exportMenu(x, y, title, md) {
  const doing = async (fn, ok) => { try { showInd('Mengekspor…'); const r = await fn(); hideInd(); if (ok || r) add('note', ok || r); } catch (e) { hideInd(); add('err', e.message); } };
  ctxMenu(x, y, [
    { label: 'Unduh Markdown (.md)', key: 'M', run: () => downloadFile(safeName(title) + '.md', md, 'text/markdown;charset=utf-8') },
    { label: 'Salin Markdown', key: 'C', run: () => navigator.clipboard.writeText(md).then(() => add('note', 'Markdown disalin.')) },
    { label: 'Google Docs', key: 'G', run: () => doing(async () => { const html = '<html><body>' + DOMPurify.sanitize(marked.parse(md, { gfm: true })) + '</body></html>'; const f = await Acct.googleDocCreate(title, html); if (f.webViewLink) chrome.tabs.create({ url: f.webViewLink }); return 'Dokumen Google dibuat.'; }) },
    { label: 'Notion', key: 'N', run: () => doing(() => exportNotion(title, md)) }
  ]);
}
function exportChatFrom(el) { const r = el.getBoundingClientRect(); const { title, md } = chatMarkdown(); exportMenu(Math.min(r.left, innerWidth - 220), r.bottom + 4, title, md); }

// ======================================================================
// ===== Ekstrak data halaman -> JSON / CSV =====
// ======================================================================
function openExtractor() {
  const sh = sheet('<h3>Ekstrak data dari halaman</h3><p class="ac-p">Tulis data apa yang mau diambil. AI membaca halaman ini lalu merapikannya jadi tabel yang siap diunduh (JSON / CSV).</p><textarea id="exw" class="memtxt" rows="3" maxlength="400" placeholder="mis. daftar produk beserta harga dan rating"></textarea><div class="qchips" id="exq" style="margin:8px 0"></div><div class="row-btns"><button class="btn" id="exok">Ekstrak</button><button class="btn" id="exno">Batal</button></div>', 'rename');
  const ta = sh.querySelector('#exw'), q = sh.querySelector('#exq');
  ['Daftar produk, harga & rating', 'Semua tabel di halaman', 'Semua link (teks & URL)', 'Email & nomor telepon', 'Daftar nama dan jabatan'].forEach((t) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'chip'; b.textContent = t; b.onclick = () => { ta.value = t; ta.focus(); }; q.appendChild(b); });
  setTimeout(() => ta.focus(), 60);
  const go = () => { const w = ta.value.trim(); if (!w) return; sh.close(); extractData(w); };
  sh.querySelector('#exok').onclick = go; sh.querySelector('#exno').onclick = () => sh.close();
  ta.onkeydown = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); go(); } };
}
function extractData(what) {
  usePage.checked = true;
  send('Ekstrak data berikut dari halaman ini: ' + what + '.\n\nAturan: keluarkan HANYA satu blok kode ```json berisi array objek dengan kunci konsisten dan huruf kecil (harga/angka tulis sebagai angka tanpa simbol bila bisa, tambahkan kolom mata uang terpisah). Jangan mengarang data yang tidak ada di halaman; isi null bila kosong. Setelah blok kode, tulis satu kalimat jumlah baris yang ditemukan.', [], { display: 'Ekstrak: ' + what, forcePage: true, kind: 'extract' });
}
// Jawaban berisi array JSON / blok CSV -> tombol unduh
function tableFromAnswer(text) {
  const m = text.match(/```(?:json|csv)?\s*\n([\s\S]*?)```/i);
  if (!m) return null;
  const body = m[1].trim();
  try {
    let j = JSON.parse(body);
    if (j && !Array.isArray(j)) { const arr = Object.values(j).find((v) => Array.isArray(v)); j = arr || [j]; }
    if (Array.isArray(j) && j.length && j.every((x) => x && typeof x === 'object' && !Array.isArray(x))) return j;
  } catch (e) { /* mungkin CSV */ }
  const lines = body.split('\n').filter((l) => l.trim());
  if (lines.length >= 2 && lines[0].includes(',')) {
    const split = (l) => { const out = []; let cur = '', q = false; for (let i = 0; i < l.length; i++) { const ch = l[i]; if (q) { if (ch === '"' && l[i + 1] === '"') { cur += '"'; i++; } else if (ch === '"') q = false; else cur += ch; } else if (ch === '"') q = true; else if (ch === ',') { out.push(cur); cur = ''; } else cur += ch; } out.push(cur); return out; };
    const head = split(lines[0]);
    if (head.length >= 2) return lines.slice(1).map((l) => { const c = split(l), o = {}; head.forEach((h, i) => { o[h.trim()] = c[i] === undefined ? '' : c[i]; }); return o; });
  }
  return null;
}
function rowsToCsv(rows) {
  const cols = []; rows.forEach((r) => Object.keys(r).forEach((k) => { if (!cols.includes(k)) cols.push(k); }));
  const cell = (v) => { if (v === null || v === undefined) return ''; const s = typeof v === 'object' ? JSON.stringify(v) : String(v); return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  return '﻿' + cols.map(cell).join(',') + '\r\n' + rows.map((r) => cols.map((c) => cell(r[c])).join(',')).join('\r\n') + '\r\n';
}
function addTableTools(tools, text) {
  const rows = tableFromAnswer(text || ''); if (!rows) return;
  const dl = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12m0 0-4-4m4 4 4-4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/></svg>';
  toolBtn(tools, dl, 'JSON (' + rows.length + ')', () => downloadFile('data.json', JSON.stringify(rows, null, 2), 'application/json'));
  toolBtn(tools, dl, 'CSV', () => downloadFile('data.csv', rowsToCsv(rows), 'text/csv;charset=utf-8'));
}

// ======================================================================
// ===== Panduan fitur & Yang baru =====
// ======================================================================
function openFeatures() {
  if (topSheet()?.classList.contains('info')) return;
  const html = '<h3>Fitur-fitur Los Gk Bawel AI</h3><p class="ac-p">Semua yang bisa kamu lakukan di sini, dijelaskan singkat.</p><div class="info-list">' +
    LGB_FEATURES.map((g) => '<div class="info-g">' + esc(g.g) + '</div>' + g.items.map((it) => '<div class="info-it"><span class="info-ic">' + ic(it[0], 17) + '</span><div><b>' + esc(it[1]) + '</b><p>' + esc(it[2]) + '</p></div></div>').join('')).join('') + '</div>' +
    '<div class="row-btns"><button class="btn" id="ifNew">' + ic('notebook-pen') + ' Yang baru</button><button class="btn" id="ifKeys">' + ic('keyboard') + ' Pintasan</button></div>';
  const sh = sheet(html, 'info hist-sheet');
  sh.querySelector('#ifNew').onclick = () => { sh.close(); setTimeout(openChangelog, 160); };
  sh.querySelector('#ifKeys').onclick = () => { sh.close(); setTimeout(openShortcuts, 160); };
}
function openChangelog() {
  if (topSheet()?.classList.contains('info')) return;
  const ver = chrome.runtime.getManifest().version;
  const lab = { add: [ic('plus', 14) + ' Ditambah', 'ok'], fix: [ic('wrench', 14) + ' Diperbaiki / ditingkatkan', 'fx'], change: [ic('refresh-cw', 14) + ' Diubah', 'ch'], remove: [ic('minus', 14) + ' Dihilangkan', 'rm'] };
  const html = '<h3>Yang baru <small>versi ' + esc(ver) + '</small></h3><div class="info-list">' + LGB_CHANGELOG.map((r) =>
    '<div class="info-g">v' + esc(r.v) + ' · ' + esc(r.t) + '</div>' + Object.keys(lab).filter((k) => r[k] && r[k].length).map((k) =>
      '<div class="cl ' + lab[k][1] + '"><div class="cl-t">' + lab[k][0] + '</div><ul>' + r[k].map((x) => '<li>' + esc(x) + '</li>').join('') + '</ul></div>').join('')).join('') + '</div>' +
    '<div class="row-btns"><button class="btn" id="clF">' + ic('sparkles') + ' Lihat semua fitur</button></div>';
  const sh = sheet(html, 'info hist-sheet');
  sh.querySelector('#clF').onclick = () => { sh.close(); setTimeout(openFeatures, 160); };
}

// ======================================================================
// ===== Command palette (Ctrl/Cmd + K) =====
// ======================================================================
async function openPalette() {
  if (topSheet()?.classList.contains('palette')) return;
  const sh = sheet(`<div class="pal"><input id="pq" placeholder="Ketik perintah, atau cari riwayat…" autocomplete="off"><div class="list" id="pl"></div></div>`, 'palette');
  const pq = sh.querySelector('#pq'), pl = sh.querySelector('#pl');
  pq.focus();
  const cmds = await getAllCmds();
  const st = await chrome.storage.local.get({ chats: [] });
  const go = (fn) => () => { sh.close(); setTimeout(fn, 120); };
  const actions = [
    { g: 'Aksi', t: 'Jawab soal di halaman', hint: '', run: go(() => runQuiz()) },
    { g: 'Aksi', t: 'Ringkas halaman ini', hint: cmdKeys['summarize-page'] || '', run: go(() => summarize()) },
    { g: 'Aksi', t: 'Buat gambar AI…', hint: '', run: go(() => setImageMode(true)) },
    { g: 'Aksi', t: 'Bandingkan beberapa tab…', hint: '', run: go(() => openTabPicker()) },
    { g: 'Aksi', t: 'Screenshot area…', hint: cmdKeys['area-shot'] || '', run: go(async () => { const tab = await activeTab(); await chrome.runtime.sendMessage({ cmd: 'startArea', tabId: tab.id }); closePopup(); }) },
    { g: 'Aksi', t: 'Percakapan baru', hint: '', run: go(() => newChat()) },
    { g: 'Aksi', t: 'Ekspor chat… (.md / Google Docs / Notion)', hint: '', run: go(() => exportMenu(innerWidth - 230, 60, chatMarkdown().title, chatMarkdown().md)) },
    { g: 'Aksi', t: 'Ekstrak data halaman → JSON / CSV…', hint: '', run: go(() => openExtractor()) },
    { g: 'Aksi', t: 'Buka sebagai side panel (tidak tertutup saat klik halaman)', hint: '', run: go(() => openSidePanel()) },
    { g: 'Aksi', t: 'Akun & sinkronisasi…', hint: '', run: go(() => openAccount()) },
    { g: 'Aksi', t: 'Tampilan & privasi cepat', hint: '', run: go(() => togglePop(tunePanel)) },
    { g: 'Aksi', t: 'Fitur-fitur AI (panduan singkat)', hint: '', run: go(() => openFeatures()) },
    { g: 'Aksi', t: 'Yang baru (changelog)', hint: '', run: go(() => openChangelog()) },
    { g: 'Aksi', t: 'Pintasan keyboard', hint: '?', run: go(() => openShortcuts()) },
    { g: 'Aksi', t: 'Pengaturan lengkap', hint: '', run: go(() => chrome.runtime.openOptionsPage()) }
  ];
  cmds.builtin.forEach((c) => actions.push({ g: 'Perintah', t: c.name, hint: '/' + slug(c.name), run: go(() => runCommand(c)) }));
  cmds.study.forEach((c) => actions.push({ g: 'Mode belajar', t: c.name, hint: '/' + slug(c.name), run: go(() => runCommand(c)) }));
  cmds.custom.forEach((c) => actions.push({ g: 'Perintah kustom', t: c.name, hint: '/' + slug(c.name), run: go(() => runCommand(c)) }));
  actions.push({ g: 'Perintah kustom', t: 'Buat perintah baru…', hint: '', run: go(() => openCmdEditor()) });
  let shown = [], idx = 0;

  const draw = () => {
    const q = pq.value.trim().toLowerCase();
    shown = actions.filter((a) => !q || a.t.toLowerCase().includes(q));
    if (q.length >= 2) {
      st.chats.filter((c) => (c.title + ' ' + c.log.map((m) => m.text || '').join(' ')).toLowerCase().includes(q)).slice(0, 6)
        .forEach((c) => shown.push({ g: 'Riwayat', t: c.title, hint: new Date(c.ts).toLocaleDateString('id'), run: go(() => loadChat(c)) }));
      const hit = log.filter((m) => (m.text || '').toLowerCase().includes(q)).slice(-3);
      hit.forEach((m) => shown.push({ g: 'Percakapan ini', t: (m.text || '').replace(/\s+/g, ' ').slice(0, 70), hint: m.role === 'user' ? 'kamu' : 'AI', run: go(() => { scrollDown(); }) }));
      shown.push({ g: 'Tanya', t: 'Tanya AI: ' + pq.value.trim(), hint: 'Enter', run: go(() => send(pq.value.trim(), [])) });
      shown.push({ g: 'Tanya', t: 'Buat gambar: ' + pq.value.trim(), hint: '', run: go(() => generateAndShow(pq.value.trim())) });
    }
    idx = Math.min(idx, Math.max(0, shown.length - 1));
    pl.innerHTML = '';
    let lastG = '';
    shown.forEach((a, i) => {
      if (a.g !== lastG) { const g = document.createElement('div'); g.className = 'grp'; g.textContent = a.g; pl.appendChild(g); lastG = a.g; }
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'mi' + (i === idx ? ' sel' : '');
      b.innerHTML = '<span>' + esc(a.t) + '</span>' + (a.hint ? '<small>' + esc(a.hint) + '</small>' : '');
      b.onclick = a.run;
      pl.appendChild(b);
    });
    pl.querySelector('.sel')?.scrollIntoView({ block: 'nearest' });
  };
  pq.oninput = () => { idx = 0; draw(); };
  pq.onkeydown = (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); idx = Math.min(idx + 1, shown.length - 1); draw(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); idx = Math.max(idx - 1, 0); draw(); }
    else if (e.key === 'Enter') { e.preventDefault(); if (shown[idx]) shown[idx].run(); }
  };
  draw();
}
document.getElementById('palette').onclick = openPalette;
document.getElementById('closeBtn').onclick = closePopup;

document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    const t = topSheet();
    if (t && t.querySelector('.pal')) t.close(); else openPalette();
  } else if (e.key === 'Escape') {
    const t = topSheet();
    if (t) t.close(); else if (document.querySelector('.pop.open')) closePops(); else closePopup();
  }
});

async function summarize() {
  const tab = await activeTab();
  const u = tab ? tab.url : '';
  const q = isYouTube(u) ? 'Ringkas video ini: satu kalimat inti, poin-poin penting dengan timestamp, dan kesimpulan.'
    : isPdf(u) ? 'Ringkas dokumen PDF ini: satu kalimat inti, poin-poin penting, dan kesimpulan.'
    : 'Ringkas halaman ini: satu kalimat inti, lalu poin-poin penting.';
  pageAction(q, 'Ringkas halaman ini', 'summarize');
}

// ======================================================================
// ===== Slash command =====
// ======================================================================
const slashBox = document.getElementById('slash');
async function updateSlash() {
  const v = input.value;
  if (!/^\/[^\s]*$/.test(v)) { slashBox.classList.remove('open'); return; }
  const q = v.slice(1).toLowerCase();
  const c = await getAllCmds();
  const list = [{ n: 'gambar', d: 'Buat gambar AI' }, { n: 'ingat', d: 'Simpan ke memori preferensi' }, { n: 'memori', d: 'Lihat memori' }, { n: 'lupa', d: 'Hapus memori' }, ...c.study.map((x) => ({ n: slug(x.name), d: x.name })), ...c.builtin.map((x) => ({ n: slug(x.name), d: x.name })), ...c.custom.map((x) => ({ n: slug(x.name), d: x.name }))]
    .filter((x) => x.n.startsWith(q));
  if (!list.length) { slashBox.classList.remove('open'); return; }
  slashBox.innerHTML = '';
  list.forEach((x) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.innerHTML = '<span>/' + esc(x.n) + '</span><small>' + esc(x.d) + '</small>';
    b.onclick = () => { input.value = '/' + x.n + ' '; slashBox.classList.remove('open'); autoGrow(); input.focus(); };
    slashBox.appendChild(b);
  });
  closePops(slashBox);
  slashBox.classList.add('open');
}

async function handleSlash(name, rest) {
  if (['gambar', 'img', 'image'].includes(name)) { if (rest) generateAndShow(rest); else setImageMode(true); return true; }
  if (name === 'ingat') {
    if (!rest) { add('note', 'Tulis: /ingat panggil aku Bro'); return true; }
    S.memoryNotes = ((S.memoryNotes || '').trim() + '\n' + rest).trim();
    await chrome.storage.local.set({ memoryNotes: S.memoryNotes }); memNotes.value = S.memoryNotes;
    add('note', 'Oke, aku ingat: ' + rest); return true;
  }
  if (name === 'memori') { add('note', S.memoryNotes ? 'Memori:\n' + S.memoryNotes : 'Memori masih kosong. Pakai /ingat <catatan>.'); return true; }
  if (name === 'lupa') { S.memoryNotes = ''; await chrome.storage.local.set({ memoryNotes: '' }); memNotes.value = ''; add('note', 'Memori dikosongkan.'); return true; }
  const c = await getAllCmds();
  const cmd = [...c.builtin, ...c.study, ...c.custom].find((x) => slug(x.name) === name || x.id === name);
  if (!cmd) return false;
  runCommand(cmd, rest || undefined);
  return true;
}

// ======================================================================
// ===== Kolom tulis, kirim =====
// ======================================================================
function autoGrow() {
  input.style.height = 'auto';
  input.style.height = Math.max(66, Math.min(input.scrollHeight, 150)) + 'px';
}

function clearComposer() {
  input.value = ''; pending = []; renderStrip(); autoGrow();
  chrome.storage.local.set({ draft: '' }).catch(() => {});
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (current) return;
  if (pending.length && window.lgbImageOk && !window.lgbImageOk()) { pending = []; renderStrip(); return; }
  const images = pending.slice();
  let q = input.value.trim();
  if (!q && !images.length && !docs.length) return;
  slashBox.classList.remove('open');

  // perintah rahasia: membuka panel pemilik (halaman itu sendiri hanya bisa dimasuki pemilik)
  if (window.LGB_WEB && /^\/?(kirim\s+)?(web\s*owner|owner\s*web|owner)\s*$/i.test(q)) {
    clearComposer();
    add('note', 'Owner panel: ' + location.origin + '/owner.html');
    const ob = document.createElement('button'); ob.className = 'btn'; ob.textContent = 'Open owner panel'; ob.onclick = () => window.open('/owner.html', '_blank', 'noopener');
    chat.appendChild(ob); scrollDown(); return;
  }
  const sm = q.match(/^\/([^\s]+)\s*([\s\S]*)$/);
  if (sm && (await handleSlash(sm[1].toLowerCase(), sm[2].trim()))) { clearComposer(); return; }
  if (imageMode && q) { clearComposer(); generateAndShow(q); return; }
  if (!images.length && IMG_INTENT.test(q)) { clearComposer(); generateAndShow(q); return; }
  if (!q) q = images.length ? 'Jelaskan gambar ini.' : 'Ringkas dokumen ini.';
  clearComposer();
  send(q, images);
});

input.addEventListener('input', () => { autoGrow(); updateSlash(); });
let draftTimer;
input.addEventListener('input', () => {
  clearTimeout(draftTimer);
  draftTimer = setTimeout(() => chrome.storage.local.set({ draft: input.value }).catch(() => {}), 300);
});
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); }
});

// ======================================================================
// ===== Empty state sesuai halaman =====
// ======================================================================
let emptyChips = [];
function kbHint() {
  const parts = [];
  if (cmdKeys._execute_action) parts.push(kbdHtml(cmdKeys._execute_action) + ' buka');
  if (cmdKeys['summarize-page']) parts.push(kbdHtml(cmdKeys['summarize-page']) + ' ringkas');
  parts.push(kbdHtml(MOD + '+K') + ' palette');
  return '<div class="kb-hint">' + parts.map((x) => '<span>' + x + '</span>').join('') + '<button type="button" data-keys>Semua pintasan</button></div>';
}
async function renderEmpty() {
  if (chat.children.length) return;
  const tab = await activeTab();
  const url = tab ? tab.url : '';
  const P = (l, q, k) => ({ l, q, page: true, kind: k });
  if (isYouTube(url)) {
    emptyChips = [P('Ringkas video ini', 'Ringkas video ini: satu kalimat inti, poin-poin penting dengan timestamp, dan kesimpulan.', 'video'),
      P('Buat rangkuman belajar', 'Buat rangkuman belajar dari video ini: konsep utama, istilah penting, dan 5 pertanyaan latihan beserta jawabannya.', 'video'),
      P('Poin penting + timestamp', 'Buat daftar poin penting dari video ini lengkap dengan timestamp.', 'video')];
  } else if (isPdf(url)) {
    emptyChips = [P('Ringkas PDF ini', 'Ringkas dokumen PDF ini: satu kalimat inti, poin-poin penting, dan kesimpulan.', 'pdf'),
      P('Buat rangkuman belajar', 'Buat rangkuman belajar dari dokumen ini beserta 5 soal latihan.', 'pdf'),
      { l: 'Tanya isi dokumen…', focus: true }];
  } else {
    emptyChips = (window.LGB_WEB ? [{ l: 'Buat gambar AI', act: 'image' }, { l: 'Jelaskan konsep rumit dengan sederhana', q: 'Jelaskan cara kerja internet dengan bahasa sederhana.' }] : [{ l: 'Ringkas halaman ini', act: 'summarize' }, { l: 'Jawab soal di halaman', act: 'quiz' }, { l: 'Buat gambar AI', act: 'image' }]).concat([
      { l: 'Bantu hitung', q: 'Berapa 100 pangkat 3 dikali 200 pangkat 4? Kasih caranya.' }]);
  }
  const sub = isYouTube(url) ? 'Kamu sedang di video YouTube. Aku bisa meringkas dari transkripnya.' : isPdf(url) ? 'Kamu sedang membuka PDF. Tanyakan isi dokumennya.'
    : (window.LGB_WEB ? 'Ketik pertanyaan atau kirim foto dan PDF (lampir, tempel, atau seret ke sini).' : 'Ketik pertanyaan, highlight teks di halaman, atau kirim foto (lampir, tempel, atau seret ke sini).');
  chat.innerHTML = `<div id="empty"><img class="avatar big" src="avatar.png" alt=""><div class="hello">Halo! Mau tanya apa?</div><div class="sub">${esc(sub)}</div><div class="chips">${emptyChips.map((c, i) => `<button class="chip" data-i="${i}">${esc(c.l)}</button>`).join('')}</div>${kbHint()}<div class="info-row"><button type="button" class="btn" data-info="features">${ic('sparkles')} Fitur AI</button><button type="button" class="btn" data-info="news">${ic('notebook-pen')} Yang baru</button></div></div>`;
}
chat.addEventListener('click', (e) => {
  if (e.target.closest('[data-keys]')) { openShortcuts(); return; }
  const inf = e.target.closest('[data-info]'); if (inf) { inf.dataset.info === 'news' ? openChangelog() : openFeatures(); return; }
  const chip = e.target.closest('#empty .chip');
  if (!chip) return;
  const c = emptyChips[+chip.dataset.i];
  if (!c) return;
  if (c.act === 'summarize') summarize();
  else if (c.act === 'quiz') runQuiz();
  else if (c.act === 'image') setImageMode(true);
  else if (c.focus) input.focus();
  else if (c.page) pageAction(c.q, c.l, c.kind);
  else if (c.q) send(c.q, []);
});

// ======================================================================
// ===== Percakapan baru & arsip =====
// ======================================================================
async function archiveCurrent() {
  if (S.noHistory || !log.some((m) => m.role === 'user')) return;
  const st = await chrome.storage.local.get({ chats: [] });
  const title = (log.find((m) => m.role === 'user').text || 'Percakapan').slice(0, 60);
  const slim = log.map((m) => ({ role: m.role, text: m.text, kind: m.kind, t: m.t, sent: m.sent, gen: m.gen ? { prompt: m.gen.prompt, engine: m.gen.engine } : undefined }));
  st.chats.unshift({ id: Date.now(), title, ts: Date.now(), log: slim, history: history.map((h) => ({ role: h.role, content: h.content, images: [] })) });
  await chrome.storage.local.set({ chats: st.chats.slice(0, 30) });
  Acct.syncSoon();
}

function drawLog() {
  chat.innerHTML = '';
  let lastAi = null, lastKind = 'chat';
  log.forEach((m) => {
    if (m.role === 'ai' && m.gen) {
      if (m.gen.dataUrl) { const r = add('ai', null); showGen(r, m.gen); lastAi = null; }
      else add('note', 'Gambar "' + m.gen.prompt + '" tidak disimpan di arsip.');
    } else if (m.role === 'ai') { lastAi = add('ai', m.text, [], { regen: false }); lastKind = m.kind || 'chat'; }
    else add(m.role, m.text, m.images || [], { sent: m.sent, retry: m.retry && false });
  });
  if (lastAi && log[log.length - 1].role === 'ai') {
    addFollow(lastAi, lastKind);
    if (lastKind !== 'quiz') addTools(lastAi, splitSources(log[log.length - 1].text).body, { regen: true });
  }
  scrollDown();
}

async function newChat() {
  if (current) current.ctrl.abort();
  await archiveCurrent();
  history = []; log = []; pending = []; docs = []; tabCtx = []; lastQuiz = null; ctxSent.clear();
  clearTimeout(persistT); persistT = 0; chrome.storage.local.remove(['chatLog', 'chatHistory', 'draft']);
  renderStrip(); qchips.hidden = true; input.value = ''; autoGrow();
  chat.innerHTML = '';
  renderEmpty();
  clearPageMarks();
  input.focus();
}
async function loadChat(c) {
  await archiveCurrent();
  { const cur = await chrome.storage.local.get({ chats: [] }); await chrome.storage.local.set({ chats: cur.chats.filter((x) => x.id !== c.id) }); Acct.tombstone(c.id); }
  log = c.log.slice(); history = c.history.slice(); ctxSent.clear();
  drawLog(); save();
}
document.getElementById('clear').onclick = newChat;
document.getElementById('settings').onclick = () => chrome.runtime.openOptionsPage();

// ======================================================================
// ===== Onboarding 1 layar + persetujuan =====
// ======================================================================
function showOnboarding() {
  return new Promise((res) => {
    const sh = sheet(`<h3>Selamat datang</h3>
      <ul class="tip-list">
        <li><span class="e">${ic('sparkles', 20)}</span><div><b>${window.LGB_WEB ? 'Tanya apa saja' : 'Highlight teks untuk bertanya'}</b><small>${window.LGB_WEB ? 'Ketik pertanyaan, kirim foto atau PDF, dan AI menjawab langsung.' : 'Blok teks di halaman mana pun, lalu pilih Jelaskan, Ringkas, Terjemahkan, atau Tulis balasan.'}</small></div></li>
        <li><span class="e">${ic('pointer', 20)}</span><div><b>${window.LGB_WEB ? 'Pasang di layar utama' : 'Klik ikon untuk ringkas halaman'}</b><small>${window.LGB_WEB ? 'Di HP pilih Tambahkan ke layar utama agar terbuka seperti aplikasi. Ctrl/Cmd+K membuka command palette.' : 'Atau tekan Alt+S. Ctrl/Cmd+K membuka command palette.'}</small></div></li>
        <li><span class="e">${ic('palette', 20)}</span><div><b>Buat gambar AI</b><small>Tekan ikon gambar di kolom tulis, atau ketik /gambar kucing astronot.</small></div></li>
      </ul>
      <p>${ic('lock', 14)} <b>Privasi:</b> ${window.LGB_WEB ? 'gambar, dokumen, dan pertanyaanmu' : 'teks halaman, teks yang kamu highlight, gambar, dan pertanyaanmu'} hanya dikirim ke penyedia AI yang kamu pilih saat kamu meminta, dan tidak pernah otomatis.${window.LGB_WEB ? '' : ' Halaman hanya dibaca bila kamu mengizinkannya per situs.'} Riwayat disimpan di perangkatmu dan bisa dimatikan; hanya jika kamu masuk ke akun (opsional), riwayat ikut disinkronkan ke server Supabase milikmu.</p>
      <div id="oc"></div>
      <div id="ot"></div>
      <div class="slidehost" id="go"></div>`);
    const slide = SlideCommit(sh.querySelector('#go'), {
      label: 'Geser untuk mulai', doneLabel: 'Siap', errorLabel: 'Gagal, coba lagi',
      width: Math.max(220, sh.querySelector('#go').clientWidth || 260), height: 52, radius: 26, holdMs: 0, disabled: true,
      onConfirm: async () => {
        const tb = otC.checked ? await enableToolbar() : false;
        await chrome.storage.local.set({ consented: true, onboarded: true, selToolbar: tb });
        S.consented = true; S.onboarded = true; S.selToolbar = tb;
      },
      onDone: () => setTimeout(() => { sh.close(); res(); }, 550)
    });
    const chk = { boxSize: 22, boxRadius: 7, fontSize: 12, strike: 'none', doneOpacity: 1, wrap: true };
    const ocC = SpringCheck(sh.querySelector('#oc'), Object.assign({ label: 'Saya mengerti dan setuju data di atas dikirim ke penyedia AI saat saya memakainya.', onChange: (v) => slide.setDisabled(!v) }, chk));
    const otC = SpringCheck(sh.querySelector('#ot'), Object.assign({ label: 'Aktifkan toolbar saat highlight teks (Chrome akan meminta izin akses situs).' }, chk));
    sh.onclick = null;
  });
}

// ======================================================================
// ===== Indikator jaringan (ms / Mbps / kbps) =====
// ======================================================================
const netBtn = document.getElementById('net');
const pingSel = document.getElementById('pingUnit');
let netTimer = null, netBusy = false;

let lastMs = null, lastBps = null, lastSpeedAt = 0, lastActive = null;

// Tes unduh sungguhan dari Cloudflare (bukan perkiraan Chrome yang sering terkunci di 1.5 Mbps).
// Mengembalikan bit per detik, atau null kalau gagal.
async function measureSpeed() {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 7000);
  let got = 0, gotFirst = 0, tFirst = null, tEnd = 0;
  const t0 = performance.now();
  try {
    const r = await fetch('https://speed.cloudflare.com/__down?bytes=4000000&r=' + Math.random(), { cache: 'no-store', signal: ctl.signal });
    if (!r.ok) return null;
    const rd = r.body.getReader();
    for (;;) {
      const { done, value } = await rd.read();
      if (done) break;
      if (tFirst === null) { tFirst = performance.now(); gotFirst = value.length; }
      got += value.length; tEnd = performance.now();
    }
  } catch (e) { /* waktu habis: pakai data yang sudah masuk */ }
  clearTimeout(timer);
  if (got < 100000) return null;
  tEnd = tEnd || performance.now();
  const body = (got - gotFirst) * 8, sec = (tEnd - tFirst) / 1000;   // hitung setelah byte pertama (tanpa waktu sambung)
  return sec > 0.05 && body > 0 ? body / sec : (got * 8) / ((tEnd - t0) / 1000);
}

function fmtSpeed(bps, unit) {
  if (bps == null) return '— ' + (unit === 'kbps' ? 'kbps' : 'Mbps');
  return unit === 'kbps' ? Math.round(bps / 1000).toLocaleString('id') + ' kbps' : (bps >= 1e7 ? Math.round(bps / 1e6) : (bps / 1e6).toFixed(1)) + ' Mbps';
}

function renderNet() {
  const unit = S.pingUnit || 'ms';
  const ms = lastMs, bps = lastBps, active = lastActive;
  let text = '', cls = 'mid';
  if (!navigator.onLine) { text = 'offline'; cls = 'bad'; }
  else if (unit === 'ms') {
    if (ms == null) { text = 'gagal'; cls = 'bad'; }
    else { text = ms + ' ms'; cls = ms < 300 ? 'good' : ms < 800 ? 'mid' : 'bad'; }
  } else {
    text = fmtSpeed(bps, unit);
    cls = bps == null ? 'mid' : bps >= 5e6 ? 'good' : bps >= 1e6 ? 'mid' : 'bad';
  }
  netBtn.className = 'net ' + cls + (netBusy ? ' busy' : '');
  netBtn.querySelector('span').textContent = text;
  netBtn.title = (active ? 'Ping ke ' + active.name + ': ' + (ms == null ? 'tidak terjangkau' : ms + ' ms') : 'Belum ada AI aktif') +
    '\nUnduh: ' + (bps == null ? 'belum terukur' : fmtSpeed(bps, 'mbps') + ' (' + fmtSpeed(bps, 'kbps') + ')') + '\nKlik untuk ukur ulang.';
}

async function measureNet(force) {
  if (netBusy) return;
  const unit = S.pingUnit || 'ms';
  if (unit === 'off') { netBtn.hidden = true; return; }
  netBtn.hidden = false;
  netBusy = true; netBtn.classList.add('busy');
  try {
    ({ active: lastActive } = await loadProviders());
    if (navigator.onLine) {
      if (lastActive) {
        // request kosong ke server penyedia (tanpa API key & tanpa isi chat); status 401 pun cukup untuk mengukur RTT
        const t0 = performance.now();
        try { await fetch(lastActive.baseUrl.replace(/\/$/, '') + '/models', { cache: 'no-store', signal: AbortSignal.timeout(6000) }); lastMs = Math.round(performance.now() - t0); }
        catch (e) { lastMs = null; }
      }
      // tes kecepatan hanya kalau satuannya Mbps/kbps; maksimal tiap 45 detik kecuali diklik
      if (unit !== 'ms' && (force || Date.now() - lastSpeedAt > 45000)) {
        lastSpeedAt = Date.now();
        netBtn.querySelector('span').textContent = 'mengukur…';
        lastBps = await measureSpeed();
      }
    }
  } catch (e) { /* abaikan */ }
  netBusy = false;
  renderNet();
}
function startNet() {
  clearInterval(netTimer);
  measureNet();
  netTimer = setInterval(() => { if (!document.hidden) measureNet(); }, 15000);
}
netBtn.onclick = () => measureNet(true);
pingSel.onchange = async () => { S.pingUnit = pingSel.value; await chrome.storage.local.set({ pingUnit: S.pingUnit }); measureNet(true); };
window.addEventListener('online', () => measureNet(true));
window.addEventListener('offline', measureNet);

// ======================================================================
// ===== Pintasan keyboard =====
// ======================================================================
let cmdKeys = {};
const MAC = /Mac|iPhone|iPad/.test(navigator.platform);
const MOD = MAC ? '⌘' : 'Ctrl';
async function loadKeys() {
  try { (await chrome.commands.getAll()).forEach((c) => { cmdKeys[c.name] = c.shortcut || ''; }); } catch (e) { /* abaikan */ }
}
function kbdHtml(keys) {
  if (!keys) return '<span class="kbd none">belum diatur</span>';
  return (keys.includes('+') ? keys.split('+') : [keys]).map((k) => '<span class="kbd">' + esc(k.trim()) + '</span>').join('');
}
async function openShortcuts() {
  if (topSheet()?.querySelector('.keyrow')) return;
  await loadKeys();
  const row = (k, t) => '<div class="keyrow"><div class="kk">' + k + '</div><div>' + t + '</div></div>';
  const html = `<h3>${ic('keyboard', 18)} Pintasan keyboard</h3>
    <div class="kgrp">Di browser (di halaman mana pun)</div>
    ${row(kbdHtml(cmdKeys._execute_action), 'Buka panel AI')}
    ${row(kbdHtml(cmdKeys['summarize-page']), 'Ringkas halaman ini')}
    ${row(kbdHtml(cmdKeys['area-shot']), 'Screenshot area ke AI')}
    <div class="kgrp">Di dalam popup</div>
    ${row(kbdHtml(MOD + '+K'), 'Command palette: perintah &amp; cari riwayat')}
    ${row(kbdHtml('Enter'), 'Kirim pesan')}
    ${row(kbdHtml('Shift+Enter'), 'Baris baru')}
    ${row(kbdHtml('/'), 'Daftar perintah (/gambar, /ringkas, /jelaskan, /terjemahkan, /balas, /kuis-latihan, /flashcard, /mind-map, /rencana-belajar, /ingat, + kustom)')}
    ${row(kbdHtml('?'), 'Buka daftar ini (saat kolom tulis kosong)')}
    ${row(kbdHtml('Esc'), 'Tutup menu / dialog, lalu tutup popup')}
    ${row(kbdHtml(MOD + '+V'), 'Tempel gambar dari clipboard')}
    <div class="kgrp">Di halaman web</div>
    ${row('<span class="kbd">Blok teks</span>', 'Toolbar Jelaskan · Ringkas · Terjemahkan · Balas')}
    ${row(kbdHtml('Esc'), 'Tutup toolbar / kartu jawaban')}
    ${row('<span class="kbd">Seret</span>', 'Pilih area screenshot (Esc batal)')}
    <div class="row-btns"><button class="btn" id="kEdit" type="button">Ubah pintasan browser</button><button class="btn primary" id="kOk" type="button">Tutup</button></div>`;
  const sh = sheet(html);
  sh.querySelector('#kOk').onclick = () => sh.close();
  sh.querySelector('#kEdit').onclick = () => chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
}
document.getElementById('keys').onclick = openShortcuts;
document.addEventListener('keydown', (e) => {
  if (e.key === '?' && !/^(TEXTAREA|INPUT|SELECT)$/.test(document.activeElement.tagName)) { e.preventDefault(); openShortcuts(); }
  else if (e.key === '?' && document.activeElement === input && !input.value) { e.preventDefault(); openShortcuts(); }
});

// ======================================================================
// ===== Mulai =====
// ======================================================================
(async function init() {
  await loadS();
  pingSel.value = S.pingUnit || 'ms';
  await loadKeys();
  startNet();
  const st = await chrome.storage.local.get({ chatLog: [], chatHistory: [], draft: '', imgSize: 'square', pendingShot: null, pendingAction: null, chats: [] });
  imgSize = st.imgSize;
  chrome.action.setBadgeText({ text: '' }).catch(() => {});
  syncToggle();

  // Hapus otomatis riwayat lama (privasi)
  if (S.autoDeleteDays > 0) {
    const cutoff = Date.now() - S.autoDeleteDays * 86400000;
    const lastT = st.chatLog.length ? (st.chatLog[st.chatLog.length - 1].t || 0) : 0;
    if (lastT && lastT < cutoff) { st.chatLog = []; st.chatHistory = []; chrome.storage.local.remove(['chatLog', 'chatHistory']); }
    const keep = st.chats.filter((c) => c.ts >= cutoff);
    if (keep.length !== st.chats.length) chrome.storage.local.set({ chats: keep });
  }
  if (S.noHistory) { st.chatLog = []; st.chatHistory = []; }

  log = st.chatLog; history = st.chatHistory;
  if (log.length) drawLog(); else await renderEmpty();

  // popup ditutup sebelum jawaban selesai -> background tetap menjawab
  const bg = (await chrome.storage.local.get('bgJob')).bgJob;
  let resumed = false;
  if (history.length && history[history.length - 1].role === 'user' && bg && !bg.running) resumed = await applyBgJob(bg);
  else if (bg && !bg.running) await chrome.storage.local.remove('bgJob');
  if (!resumed && history.length && history[history.length - 1].role === 'user' && bg && bg.running && Date.now() - bg.t < 300000) { waitBgJob(); resumed = true; }
  if (!resumed && history.length && history[history.length - 1].role === 'user') {
    history.pop();
    const text = 'Popup tertutup sebelum jawaban selesai. Kirim ulang pertanyaanmu.';
    add('err', text); log.push({ role: 'err', text, t: Date.now() }); save();
  }
  if (st.draft) { input.value = st.draft; autoGrow(); }
  scrollDown();

  if (!S.onboarded) await showOnboarding();
  // sinkron otomatis di latar kalau sudah masuk (maks. 1x per menit)
  Acct.user().then(async (u) => { if (!u) return; const l = (await chrome.storage.local.get({ acctLastSync: 0 })).acctLastSync; if (Date.now() - l > 60000) { await Acct.sync(); loadChatsIntoUI(); } }).catch(() => {});

  // Screenshot area / aksi dari shortcut atau toolbar halaman
  if (st.pendingShot) {
    try { pending.push(await shrink(st.pendingShot)); renderStrip(); showQuick(['Jelaskan gambar/UI ini', 'Cari solusi error ini', 'Tulis ulang teks di gambar']); } catch (e) { /* abaikan */ }
    chrome.storage.local.remove('pendingShot');
  }
  if (st.pendingAction && Date.now() - st.pendingAction.t < 60000) {
    chrome.storage.local.remove('pendingAction');
    if (st.pendingAction.type === 'summarize') summarize();
    else if (st.pendingAction.type === 'ask') send(st.pendingAction.text, [], { display: st.pendingAction.display, noPage: true, sent: 'teks terpilih' });
  } else if (st.pendingAction) chrome.storage.local.remove('pendingAction');
  input.focus();
})();


// ElectricBorder di bar prompt (WebGL2; diam-diam dilewati bila tidak didukung)
(function () {
  try {
    const form = document.getElementById('form');
    if (window.LGB_LITE || !form || typeof ElectricBorder !== 'function') return;
    const col = () => getComputedStyle(document.body).getPropertyValue('--eb').trim() || '#9fefff';
    const eb = ElectricBorder(form, { color: col(), borderRadius: 28, speed: 1, chaos: 0.45, spread: 0.35, thickness: 1.4, strands: 3, glow: 0.7, intensity: 0.8, arcs: 1, cursorRadius: 80 });
    if (!eb.ok) { eb.destroy(); return; }
    form.classList.add('electric');
    window.__eb = eb;
  } catch (e) { console.warn('ElectricBorder off', e); }
})();

try { if (window.SpecularButtons && !window.LGB_LITE) SpecularButtons('button.icon, button.tool, button#send, button.pill, button.chip, button.btn, button.net, button.pre, button[data-mode], button[data-glass], button[data-size], button[data-shot]'); } catch (e) { console.warn('SpecularButtons off', e); }
