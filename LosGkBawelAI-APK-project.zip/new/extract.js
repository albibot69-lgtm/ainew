// Fungsi-fungsi di file ini DISUNTIKKAN ke halaman lewat chrome.scripting.executeScript({ func }).
// Tiap fungsi harus berdiri sendiri (tidak boleh memakai variabel di luar fungsi).

// ---------- Baca halaman + deteksi soal pilihan ganda ----------
function pageExtract(limit) {
  const clean = (s) => String(s || '').replace(/\u00a0/g, ' ').replace(/[ \t]+/g, ' ').replace(/\n[ \t]+/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  const txt = (el) => (el ? clean(el.innerText || el.textContent || '') : '');
  const sel = clean(String(window.getSelection ? window.getSelection() : ''));
  const bodyText = document.body ? clean(document.body.innerText) : '';
  const res = {
    url: location.href, title: document.title, top: window === window.top,
    selection: sel.slice(0, limit), text: bodyText.slice(0, limit), truncated: bodyText.length > limit,
    blocks: [], declared: 0
  };

  // jumlah soal yang "tertulis" di halaman (1. 2. 3. ...), untuk mengecek kelengkapan
  const nums = (bodyText.match(/^\s*(?:soal\s*)?(\d{1,3})\s*[.)]\s+\S/gim) || [])
    .map((m) => parseInt(m.replace(/\D+/g, ' ').trim().split(' ')[0], 10)).filter((n) => n > 0 && n <= 300);
  if (nums.length >= 2) res.declared = Math.max.apply(null, nums);

  // bersihkan tanda lama
  document.querySelectorAll('[data-lgb-hit]').forEach((n) => { n.style.outline = ''; n.style.outlineOffset = ''; n.style.background = ''; n.style.borderRadius = ''; n.removeAttribute('data-lgb-hit'); });
  document.querySelectorAll('[data-lgb-q],[data-lgb-o]').forEach((e) => { e.removeAttribute('data-lgb-q'); e.removeAttribute('data-lgb-o'); });

  const OPT = 'input[type=radio],input[type=checkbox],[role=radio],[role=checkbox]';
  const els = [...document.querySelectorAll(OPT)];
  const ids = new WeakMap(); let idc = 0;
  const idOf = (n) => { if (!n) return 'x'; if (!ids.has(n)) ids.set(n, ++idc); return ids.get(n); };
  const groups = new Map();
  const add = (key, item) => { if (!groups.has(key)) groups.set(key, []); groups.get(key).push(item); };

  els.forEach((el) => {
    let key;
    if (el.tagName === 'INPUT' && el.type === 'radio' && el.name) {
      key = 'r:' + idOf(el.form) + ':' + el.name;
    } else {
      const g = el.closest('[role=radiogroup],fieldset');
      if (g) key = 'g:' + idOf(g);
      else {
        let a = el.parentElement;
        while (a && a !== document.body && a.querySelectorAll(OPT).length < 2) a = a.parentElement;
        key = 'p:' + idOf(a);
      }
    }
    add(key, { el, kind: el.type === 'checkbox' || el.getAttribute('role') === 'checkbox' ? 'checkbox' : 'radio' });
  });
  // dropdown <select>
  document.querySelectorAll('select').forEach((s) => {
    const o = [...s.options].filter((x) => x.value !== '' && x.text.trim());
    if (o.length >= 3) groups.set('s:' + idOf(s), o.map((x) => ({ el: x, kind: 'select', sel: s })));
  });

  const optText = (it) => {
    const el = it.el; let t = '';
    if (it.kind === 'select') t = el.text;
    else if (el.tagName === 'INPUT') {
      if (el.labels && el.labels.length) t = txt(el.labels[0]);
      if (!t) { const lb = el.closest('label'); if (lb) t = txt(lb); }
      if (!t && el.id) { try { t = txt(document.querySelector('label[for="' + CSS.escape(el.id) + '"]')); } catch (e) { /* abaikan */ } }
      if (!t) t = el.getAttribute('aria-label') || '';
      if (!t) t = txt(el.parentElement);
    } else t = el.getAttribute('aria-label') || txt(el) || el.getAttribute('data-value') || '';
    return clean(t).replace(/^[A-Ha-h][.)]\s+/, '').slice(0, 500);
  };
  const optNode = (it) => {
    if (it.kind === 'select') return it.sel;
    const el = it.el;
    if (el.tagName !== 'INPUT') return el;
    return (el.labels && el.labels[0]) || el.closest('label') || el.closest('li') || el.parentElement;
  };

  const allEls = els;
  const seen = new Set();
  let qi = 0;
  groups.forEach((items) => {
    if (items.length < 2) return;
    const texts = items.map(optText);
    if (texts.filter(Boolean).length < 2) return;
    const first = items[0].kind === 'select' ? items[0].sel : items[0].el;
    // cari wadah terkecil yang memuat semua opsi
    let c = first.parentElement;
    const nodes = items.map((i) => (i.kind === 'select' ? i.sel : i.el));
    while (c && c !== document.body && !nodes.every((n) => c.contains(n))) c = c.parentElement;
    if (!c) return;
    const others = allEls.filter((e) => !nodes.includes(e));
    const optLen = texts.reduce((a, t) => a + t.length, 0);
    for (let guard = 0; guard < 8; guard++) {
      const p = c.parentElement;
      if (!p || p === document.body) break;
      if (others.some((e) => p.contains(e))) break;
      const stemLen = txt(c).length - optLen;
      const pl = txt(p).length;
      if (stemLen >= 12 && pl > txt(c).length + 400) break;
      if (pl > 6000) break;
      c = p;
    }
    let stem = txt(c);
    texts.forEach((t) => { if (t) { const k = stem.indexOf(t); if (k >= 0) stem = (stem.slice(0, k) + ' ' + stem.slice(k + t.length)); } });
    stem = clean(stem).replace(/(?:\s*\(?[A-Ha-h][.)])+\s*$/, '').trim();
    if (stem.length < 8) {
      // soal ada di elemen sebelum wadah opsi
      for (let n = c; n && n !== document.body && stem.length < 8; n = n.parentElement) {
        let sb = n.previousElementSibling;
        for (let k = 0; sb && k < 3; k++, sb = sb.previousElementSibling) {
          if (others.some((e) => sb.contains(e))) break;
          const t = txt(sb);
          if (t.length >= 8) { stem = t; break; }
        }
        if (stem.length >= 8) break;
      }
    }
    if (stem.length < 4) stem = '(teks soal tidak terbaca)';
    const sig = stem.slice(0, 80) + '|' + texts.join('|').slice(0, 120);
    if (seen.has(sig)) return;
    seen.add(sig);

    const img = c.querySelectorAll('img').length;
    c.setAttribute('data-lgb-q', String(qi));
    const opts = items.map((it, j) => {
      const nd = optNode(it); if (nd) nd.setAttribute('data-lgb-o', String(j));
      return { l: String.fromCharCode(65 + (j % 26)), t: texts[j] || '(gambar/tanpa teks)' };
    });
    res.blocks.push({ i: qi, q: stem.slice(0, 1800), opts, kind: items[0].kind, img });
    qi++;
  });

  res.blocks.sort((a, b) => a.i - b.i);
  return res;
}

// ---------- Tandai jawaban benar di halaman ----------
// answers: [{ q: nomorLokal, letters: ['B'] }]; kosong = hapus tanda
function pageMarkAnswers(answers) {
  document.querySelectorAll('[data-lgb-hit]').forEach((n) => {
    n.style.outline = ''; n.style.outlineOffset = ''; n.style.background = ''; n.style.borderRadius = '';
    n.removeAttribute('data-lgb-hit');
  });
  let n = 0, first = null;
  (answers || []).forEach((a) => {
    const c = document.querySelector('[data-lgb-q="' + a.q + '"]');
    if (!c) return;
    a.letters.forEach((L) => {
      const idx = L.toUpperCase().charCodeAt(0) - 65;
      const node = c.querySelector('[data-lgb-o="' + idx + '"]') || (c.matches('[data-lgb-o="' + idx + '"]') ? c : null);
      if (!node) return;
      node.style.outline = '3px solid #22c55e';
      node.style.outlineOffset = '2px';
      node.style.borderRadius = '8px';
      node.style.background = 'rgba(34,197,94,.16)';
      node.setAttribute('data-lgb-hit', '1');
      if (!first) first = node;
      n++;
    });
  });
  if (first && first.scrollIntoView) first.scrollIntoView({ block: 'center', behavior: 'smooth' });
  return n;
}

// ---------- Sorot kutipan sumber di halaman ----------
// quotes: [string]; focus: index yang di-scroll (atau -1). Mengembalikan [true/false] per kutipan.
function pageHighlight(quotes, focus) {
  const STYLE_ID = 'lgb-hl-style';
  if (!document.getElementById(STYLE_ID)) {
    const st = document.createElement('style');
    st.id = STYLE_ID;
    st.textContent = '::highlight(lgb-answer){background-color:#fde047;color:#111}::highlight(lgb-focus){background-color:#fb923c;color:#111}';
    (document.head || document.documentElement).appendChild(st);
  }
  const hasAPI = window.CSS && CSS.highlights && typeof Highlight !== 'undefined';
  if (hasAPI) { CSS.highlights.delete('lgb-answer'); CSS.highlights.delete('lgb-focus'); }
  if (!quotes || !quotes.length) return [];

  const fold = (c) => {
    c = c.toLowerCase();
    if (c === '\u2019' || c === '\u2018') return "'";
    if (c === '\u201c' || c === '\u201d') return '"';
    if (c === '\u2013' || c === '\u2014') return '-';
    return c;
  };
  const flat = []; const map = [];
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
    acceptNode(n) {
      const p = n.parentElement;
      if (!p || /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|TEXTAREA)$/.test(p.tagName)) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  });
  while (w.nextNode()) {
    const n = w.currentNode, t = n.nodeValue;
    for (let i = 0; i < t.length; i++) {
      const ch = t[i];
      if (/[\s\u00a0\u200b]/.test(ch)) continue;
      flat.push(fold(ch)); map.push([n, i]);
    }
  }
  const hay = flat.join('');
  const ranges = [], found = [];
  quotes.forEach((q) => {
    let needle = '';
    for (const ch of String(q)) if (!/[\s\u00a0\u200b]/.test(ch)) needle += fold(ch);
    needle = needle.replace(/^["'\[\]\d.]+(?=[a-z])/i, (m) => (m.length < 4 ? '' : m));
    let at = needle.length >= 6 ? hay.indexOf(needle) : -1;
    let len = needle.length;
    if (at < 0 && needle.length > 50) { at = hay.indexOf(needle.slice(0, 50)); len = 50; }
    if (at < 0 && needle.length > 50) { const k = hay.indexOf(needle.slice(-50)); if (k >= 0) { at = k; len = 50; } }
    if (at < 0) { found.push(false); ranges.push(null); return; }
    const a = map[at], b = map[at + len - 1];
    const r = document.createRange();
    r.setStart(a[0], a[1]); r.setEnd(b[0], b[1] + 1);
    ranges.push(r); found.push(true);
  });
  const ok = ranges.filter(Boolean);
  if (hasAPI && ok.length) {
    CSS.highlights.set('lgb-answer', new Highlight(...ok));
    const f = ranges[focus >= 0 ? focus : ranges.findIndex(Boolean)];
    if (f && focus >= 0) CSS.highlights.set('lgb-focus', new Highlight(f));
  } else if (ok.length) {
    const s = window.getSelection(); s.removeAllRanges(); s.addRange(ok[0]);
  }
  const target = ranges[focus >= 0 ? focus : ranges.findIndex(Boolean)];
  if (target) {
    const el = target.startContainer.parentElement;
    if (el && el.scrollIntoView) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
  return found;
}

// ---------- Transkrip YouTube ----------
async function ytExtract(maxChars) {
  const out = { title: document.title.replace(/ - YouTube$/, ''), url: location.href, desc: '', transcript: '', source: '', error: '' };
  const vid = new URL(location.href).searchParams.get('v');
  if (!vid) { out.error = 'Ini bukan halaman video YouTube.'; return out; }
  const stamp = (ms) => {
    const s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
    return (h ? h + ':' + String(m).padStart(2, '0') : String(m)) + ':' + String(x).padStart(2, '0');
  };
  const build = (rows) => {
    const lines = []; let cur = '', start = 0;
    rows.forEach((r, i) => {
      if (!cur) start = r.t;
      cur += (cur ? ' ' : '') + r.s.replace(/\s+/g, ' ').trim();
      if (r.t - start > 25000 || i === rows.length - 1) { lines.push('[' + stamp(start) + '] ' + cur); cur = ''; }
    });
    return lines;
  };

  // 1) Jalur utama: daftar caption dari halaman watch
  try {
    const html = await (await fetch('https://www.youtube.com/watch?v=' + vid, { credentials: 'include' })).text();
    const d = html.match(/"shortDescription":"((?:[^"\\]|\\.)*)"/);
    if (d) { try { out.desc = JSON.parse('"' + d[1] + '"').slice(0, 3000); } catch (e) { /* abaikan */ } }
    const at = html.indexOf('"captionTracks":');
    if (at > 0) {
      const st = html.indexOf('[', at);
      let depth = 0, inStr = false, esc = false, en = -1;
      for (let i = st; i < html.length; i++) {
        const c = html[i];
        if (inStr) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') inStr = false; }
        else if (c === '"') inStr = true;
        else if (c === '[') depth++;
        else if (c === ']') { depth--; if (!depth) { en = i; break; } }
      }
      const tracks = JSON.parse(html.slice(st, en + 1));
      const pick = tracks.find((t) => !t.kind && /^(id|en)/.test(t.languageCode)) || tracks.find((t) => !t.kind) ||
        tracks.find((t) => /^(id|en)/.test(t.languageCode)) || tracks[0];
      if (pick) {
        const r = await fetch(pick.baseUrl + '&fmt=json3', { credentials: 'include' });
        const j = await r.json().catch(() => null);
        const rows = ((j && j.events) || []).filter((e) => e.segs).map((e) => ({ t: e.tStartMs || 0, s: e.segs.map((x) => x.utf8).join('') })).filter((r2) => r2.s.trim());
        if (rows.length) { out.transcript = build(rows).join('\n'); out.source = 'caption (' + pick.languageCode + (pick.kind ? ', otomatis' : '') + ')'; }
      }
    }
  } catch (e) { /* lanjut ke jalur cadangan */ }

  // 2) Cadangan: buka panel transkrip dan baca barisnya
  if (!out.transcript) {
    try {
      let segs = document.querySelectorAll('ytd-transcript-segment-renderer');
      if (!segs.length) {
        const btn = [...document.querySelectorAll('button')].find((b) => /transcript|transkrip/i.test((b.getAttribute('aria-label') || '') + ' ' + (b.innerText || '')));
        if (btn) btn.click();
        for (let i = 0; i < 20 && !segs.length; i++) {
          await new Promise((r) => setTimeout(r, 250));
          segs = document.querySelectorAll('ytd-transcript-segment-renderer');
        }
      }
      if (segs.length) {
        out.transcript = [...segs].map((s) => {
          const t = (s.querySelector('.segment-timestamp') || {}).innerText || '';
          const x = (s.querySelector('.segment-text') || {}).innerText || s.innerText;
          return '[' + t.trim() + '] ' + x.trim();
        }).join('\n');
        out.source = 'panel transkrip';
      }
    } catch (e) { /* abaikan */ }
  }

  if (!out.desc) out.desc = ((document.querySelector('#description-inner') || {}).innerText || '').slice(0, 3000);
  if (out.transcript.length > maxChars) {
    const head = out.transcript.slice(0, Math.floor(maxChars * 0.6));
    const tail = out.transcript.slice(-Math.floor(maxChars * 0.4));
    out.transcript = head + '\n[... bagian tengah dipotong karena video sangat panjang ...]\n' + tail;
    out.cut = true;
  }
  if (!out.transcript) out.error = 'Transkrip tidak tersedia untuk video ini (video tanpa subtitle atau diblokir). Aku pakai judul dan deskripsi saja.';
  return out;
}
