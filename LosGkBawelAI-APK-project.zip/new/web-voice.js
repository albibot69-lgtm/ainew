// Mikrofon versi web: rekam jernih (echo/noise cancel + filter + kompresor) lalu ditranskrip Whisper di server.
// Tidak lagi memakai Web Speech (yang sering terputus-putus & hasilnya jelek).
(function () {
  if (!window.LGB_WEB || !window.MediaRecorder || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return;
  const mic = document.getElementById('mic');
  if (!mic) return;
  const MAX_MS = 90000, TAIL_MS = 380, HOLD_MS = 550, SILENCE_MS = 1700, MIN_BYTES = 1800;
  const NOISE = /^(terima kasih( telah| sudah)? (menonton|mendengarkan)|thanks for watching|thank you( for watching)?|subtitle[s]? by.*|subtitles? by the.*|amara\.org.*|www\..*|\.+|you)\.?$/i;

  let stream = null, ctx = null, idleT = 0;
  let rec = null, chunks = [], active = false, startedAt = 0, heldStart = 0, by = '';
  let analyser = null, buf = null, raf = 0, heardSpeech = false, lastVoice = 0, peak = 0, base = '';
  let mime = '';
  ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'].some((m) => { try { if (MediaRecorder.isTypeSupported(m)) { mime = m; return true; } } catch (e) { /* abaikan */ } return false; });

  const note = (t) => { try { add('note', t); } catch (e) { /* abaikan */ } };
  const err = (t) => { try { add('err', t); } catch (e) { /* abaikan */ } };
  const ui = (t) => { try { showInd(t, 'mic'); } catch (e) { /* abaikan */ } };
  const ui0 = () => { try { hideInd(); } catch (e) { /* abaikan */ } };
  const busy = () => { try { return !!current; } catch (e) { return false; } };

  async function getStream() {
    clearTimeout(idleT);
    if (stream && stream.getTracks().some((t) => t.readyState === 'live')) return stream;
    stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1, sampleRate: 48000 }
    });
    return stream;
  }
  function releaseSoon() {
    clearTimeout(idleT);
    idleT = setTimeout(() => {
      if (active) return;
      try { stream && stream.getTracks().forEach((t) => t.stop()); } catch (e) { /* abaikan */ }
      stream = null;
      try { ctx && ctx.close(); } catch (e) { /* abaikan */ } ctx = null;
    }, 20000);
  }
  // rantai audio: filter suara rendah (dengung) -> kompresor (suara pelan jadi jelas, keras tidak pecah) -> perekam
  function chain(s) {
    if (!ctx || ctx.state === 'closed') ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    const src = ctx.createMediaStreamSource(s);
    const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 90; hp.Q.value = 0.7;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 7600;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -34; comp.knee.value = 18; comp.ratio.value = 3.5; comp.attack.value = 0.004; comp.release.value = 0.2;
    const gain = ctx.createGain(); gain.gain.value = 1.5;
    analyser = ctx.createAnalyser(); analyser.fftSize = 1024;
    const dest = ctx.createMediaStreamDestination();
    src.connect(hp); hp.connect(lp); lp.connect(comp); comp.connect(gain); gain.connect(dest); gain.connect(analyser);
    buf = new Float32Array(analyser.fftSize);
    return { dest, nodes: [src, hp, lp, comp, gain] };
  }

  function meter() {
    if (!active || !analyser) return;
    analyser.getFloatTimeDomainData(buf);
    let sum = 0; for (let i = 0; i < buf.length; i++) sum += buf[i] * buf[i];
    const rms = Math.sqrt(sum / buf.length), now = Date.now();
    if (rms > peak) peak = rms;
    mic.style.setProperty('--lv', Math.min(1, rms * 9).toFixed(2));
    if (rms > 0.022) { heardSpeech = true; lastVoice = now; }
    const dur = now - startedAt;
    if (by !== 'hold' && !mic._down && heardSpeech && now - lastVoice > SILENCE_MS && dur > 1200) return finish();
    if (dur > MAX_MS) return finish();
    raf = requestAnimationFrame(meter);
  }

  async function start(via) {
    if (active || busy()) return;
    by = via; active = true; heardSpeech = false; peak = 0; chunks = []; heldStart = Date.now();
    mic.classList.add('rec');
    ui('Menyiapkan mikrofon…');
    let s;
    try { s = await getStream(); }
    catch (e) {
      active = false; mic.classList.remove('rec'); ui0();
      if (e && (e.name === 'NotAllowedError' || e.name === 'SecurityError')) err('Mikrofon diblokir. Klik ikon gembok di address bar, izinkan Mikrofon, lalu coba lagi.');
      else if (e && e.name === 'NotFoundError') err('Mikrofon tidak ditemukan di perangkat ini.');
      else err('Mikrofon tidak bisa dipakai: ' + ((e && e.message) || e));
      return;
    }
    if (!active) { releaseSoon(); return; } // sudah dilepas sebelum siap
    base = input.value ? input.value.trim() + ' ' : '';
    const c = chain(s);
    try { rec = new MediaRecorder(c.dest.stream, Object.assign({ audioBitsPerSecond: 96000 }, mime ? { mimeType: mime } : {})); }
    catch (e) { try { rec = new MediaRecorder(c.dest.stream); } catch (e2) { active = false; mic.classList.remove('rec'); ui0(); err('Perekaman suara tidak didukung browser ini.'); return; } }
    rec.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
    rec.onstop = () => { c.nodes.forEach((n) => { try { n.disconnect(); } catch (e) { /* abaikan */ } }); onStopped(); };
    rec.start(250);
    startedAt = Date.now(); lastVoice = startedAt;
    ui('Mendengarkan… ' + (by === 'hold' ? 'lepas tombol untuk selesai' : 'ketuk lagi untuk selesai'));
    raf = requestAnimationFrame(meter);
  }

  function finish() {
    if (!active) return;
    active = false; cancelAnimationFrame(raf);
    mic.classList.remove('rec'); mic.style.removeProperty('--lv');
    ui('Merapikan suara…');
    // sisakan sedikit rekaman setelah tombol dilepas supaya akhir kalimat tidak terpotong
    setTimeout(() => { try { rec && rec.state !== 'inactive' && rec.stop(); } catch (e) { onStopped(); } }, TAIL_MS);
  }

  async function onStopped() {
    const blob = new Blob(chunks, { type: (rec && rec.mimeType) || mime || 'audio/webm' });
    chunks = []; releaseSoon();
    if (!heardSpeech || peak < 0.012 || blob.size < MIN_BYTES) { ui0(); note('Suaramu tidak terdengar. Coba dekatkan mikrofon dan bicara sedikit lebih keras.'); return; }
    ui('Mengubah suara jadi teks…');
    try {
      const text = await transcribe(blob);
      ui0();
      if (!text) { note('Tidak ada kata yang terbaca. Coba ulangi.'); return; }
      input.value = base + text; input.dispatchEvent(new Event('input')); input.focus();
      let auto = true; try { auto = S.voiceAutoSend !== false; } catch (e) { /* abaikan */ }
      if (auto) form.requestSubmit();
    } catch (e) { ui0(); err('Suara: ' + ((e && e.message) || e)); }
  }

  async function transcribe(blob) {
    const ext = /mp4/.test(blob.type) ? 'm4a' : /ogg/.test(blob.type) ? 'ogg' : 'webm';
    const fd = new FormData();
    fd.append('file', new File([blob], 'suara.' + ext, { type: blob.type }));
    fd.append('model', 'whisper-large-v3-turbo');
    fd.append('temperature', '0');
    fd.append('response_format', 'json');
    let lang = 'id'; try { lang = String(S.voiceLang || 'id-ID').split('-')[0].toLowerCase(); } catch (e) { /* abaikan */ }
    fd.append('language', lang);
    fd.append('prompt', 'Percakapan dengan asisten AI bernama Los Gk Bawel AI. Istilah: Roblox, Luau, JavaScript, Python, HTML, CSS, API.');
    let r;
    try { r = await fetch('/api/p/groq/audio/transcriptions', { method: 'POST', headers: { Authorization: 'Bearer server' }, body: fd }); }
    catch (e) { throw new Error('tidak bisa terhubung ke server.'); }
    let j = null; try { j = await r.json(); } catch (e) { /* abaikan */ }
    if (!r.ok) throw new Error((j && j.error && (j.error.message || j.error)) || ('gagal (' + r.status + ')'));
    const t = String((j && j.text) || '').replace(/\s+/g, ' ').trim();
    return NOISE.test(t) ? '' : t;
  }

  // ketuk = mulai/selesai, tahan = bicara selama ditahan
  mic.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    if (active) { finish(); return; }
    start('tap'); mic._down = Date.now();
  });
  const up = () => { if (active && mic._down && Date.now() - mic._down > HOLD_MS) { by = 'hold'; finish(); } mic._down = 0; };
  mic.addEventListener('pointerup', up);
  mic.addEventListener('pointercancel', () => { mic._down = 0; });
  mic.title = 'Ketuk untuk bicara, ketuk lagi untuk selesai (atau tahan, Alt+V)';
  document.addEventListener('keydown', (e) => { if (e.altKey && !e.ctrlKey && !e.metaKey && e.code === 'KeyV') { e.preventDefault(); if (!e.repeat && !active) { start('hold'); } } });
  document.addEventListener('keyup', (e) => { if (active && by === 'hold' && (e.code === 'KeyV' || e.key === 'Alt')) finish(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden && active) finish(); });
})();
