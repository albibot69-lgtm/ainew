// Tata letak ala aplikasi AI: sidebar riwayat + kolom obrolan di tengah. Kolom tulis (prompt bar) tidak diubah.
(function () {
  if (!window.LGB_WEB) return;
  const $ = (id) => document.getElementById(id);
  const root = document.documentElement;
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const wide = () => window.matchMedia('(min-width: 900px)').matches;
  const ico = (id, n, s) => { const e = $(id); if (e) e.innerHTML = ic(n, s || 18); };
  ico('sNewI', 'plus'); ico('sSearchI', 'search'); ico('sFeatI', 'sparkles'); ico('sSetI', 'settings'); ico('sClose', 'panel-left', 18);

  // buka / tutup sidebar (desktop ingat pilihan, HP selalu mulai tertutup)
  const pref = () => { try { return localStorage.getItem('lgbSide'); } catch (e) { return null; } };
  const setOpen = (v, save) => { root.classList.toggle('side-open', v); if (save && wide()) { try { localStorage.setItem('lgbSide', v ? '1' : '0'); } catch (e) { /* abaikan */ } } };
  setOpen(wide() && pref() !== '0');
  $('sToggle').onclick = () => setOpen(!root.classList.contains('side-open'), true);
  $('sClose').onclick = () => setOpen(false, true);
  $('sScrim').onclick = () => setOpen(false);
  const closeOnMobile = () => { if (!wide()) setOpen(false); };
  window.matchMedia('(min-width: 900px)').addEventListener('change', () => setOpen(wide() && pref() !== '0'));

  $('sNew').onclick = () => { closeOnMobile(); newChat(); };
  $('sSearch').onclick = () => { closeOnMobile(); $('palette').click(); };
  $('sFeat').onclick = () => { closeOnMobile(); $('tFeat').click(); };
  $('sSet').onclick = () => chrome.runtime.openOptionsPage();
  $('sAll').onclick = () => { closeOnMobile(); openHistory(); };
  $('sAcct').onclick = () => { closeOnMobile(); openAccount(); };

  // daftar percakapan
  let busy = false, again = false, curId = 0;
  async function draw() {
    if (busy) { again = true; return; }
    busy = true;
    try {
      const st = await chrome.storage.local.get({ chats: [], chatLog: [] });
      const list = $('sList');
      const cur = (st.chatLog.find((m) => m.role === 'user') || {}).text;
      const items = st.chats.slice().sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || (b.ts || 0) - (a.ts || 0));
      let h = '';
      if (cur) h += '<button type="button" class="s-item on" data-cur="1" title="' + esc(cur) + '"><span>' + esc(cur.slice(0, 60)) + '</span></button>';
      items.forEach((c, i) => { h += '<button type="button" class="s-item" data-i="' + i + '" title="' + esc(c.title) + '">' + (c.pinned ? ic('pin', 13) : '') + '<span>' + esc(c.title || 'Percakapan') + '</span></button>'; });
      list.innerHTML = h || '<div class="s-empty">Belum ada percakapan.</div>';
      list.onclick = async (e) => {
        const b = e.target.closest('.s-item'); if (!b || b.dataset.cur) { closeOnMobile(); return; }
        const fresh = (await chrome.storage.local.get({ chats: [] })).chats.slice().sort((a, b2) => (b2.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || (b2.ts || 0) - (a.ts || 0));
        const c = fresh[+b.dataset.i]; if (c) { closeOnMobile(); await loadChat(c); }
      };
    } finally { busy = false; if (again) { again = false; draw(); } }
  }
  let t = 0; const soon = () => { clearTimeout(t); t = setTimeout(draw, 250); };
  chrome.storage.onChanged.addListener((c) => { if (c.chats || c.chatLog) soon(); });
  draw();

  // akun
  async function acct() {
    try {
      const u = await Acct.user();
      $('sAcctName').textContent = u ? (u.name || (u.email || '').split('@')[0] || 'Akun') : 'Masuk / Akun';
      $('sAv').textContent = u ? ((u.name || u.email || '?')[0] || '?').toUpperCase() : '';
      if (!u) $('sAv').innerHTML = ic('user', 16);
      if (u && window.lgbPaintAcct) setTimeout(window.lgbPaintAcct, 0);
    } catch (e) { /* abaikan */ }
  }
  acct(); chrome.storage.onChanged.addListener((c) => { if (Object.keys(c).some((k) => /sess|acct/i.test(k))) acct(); });
})();
