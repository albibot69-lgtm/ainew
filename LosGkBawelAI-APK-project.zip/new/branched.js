// Menu bercabang (port vanilla JS dari komponen BranchedMenu, React Bits).
// Bagian bisa dilipat; garis cabang melengkung "menggambar" ke item yang aktif.
function BranchedMenu(nav, o) {
  const PAD = 6, MARK = 16, SVGNS = 'http://www.w3.org/2000/svg';
  const rowHeight = o.rowHeight || 36, indent = o.indent || 40, trunk = o.trunk || 14, radius = o.radius || 10;
  const items = o.items;
  const open = new Set(Array.isArray(o.defaultOpen) ? o.defaultOpen : o.defaultOpen >= 0 ? [o.defaultOpen] : [0]);
  let active = o.defaultActive || '';
  const heads = [], reaches = [], sections = [];

  const r = Math.min(radius, rowHeight / 2 - 2), endX = indent - 8;
  const rowY = (k) => PAD + k * rowHeight + rowHeight / 2;
  const branch = (k) => `M ${trunk} ${rowY(k) - r} A ${r} ${r} 0 0 0 ${trunk + r} ${rowY(k)} H ${endX}`;
  const reach = (k) => `M ${trunk} 0 V ${rowY(k) - r} A ${r} ${r} 0 0 0 ${trunk + r} ${rowY(k)} H ${endX}`;
  const length = (k) => rowY(k) - r + (Math.PI * r) / 2 + (endX - trunk - r);
  const el = (tag, cls, attrs) => { const e = document.createElement(tag); if (cls) e.className = cls; Object.assign(e, attrs || {}); return e; };
  const svg = (tag, attrs) => { const e = document.createElementNS(SVGNS, tag); Object.entries(attrs || {}).forEach(([k, v]) => e.setAttribute(k, v)); return e; };

  nav.classList.add('branched-menu');
  nav.style.setProperty('--bm-font', (o.fontSize || 14) + 'px');
  nav.style.setProperty('--bm-row', rowHeight + 'px');
  nav.style.setProperty('--bm-indent', indent + 'px');
  nav.style.setProperty('--bm-line-w', o.lineWidth || 1.5);
  nav.style.setProperty('--bm-draw', (o.drawDuration || 400) + 'ms');
  nav.style.setProperty('--bm-fold', (o.foldDuration || 300) + 'ms');
  if (!active) { const f = items.find((it, i) => it.children && open.has(i)); active = f ? f.children[0].value : ''; }

  const marker = el('span', 'branched-menu__marker'); marker.setAttribute('aria-hidden', 'true');
  nav.appendChild(marker);

  items.forEach((item, i) => {
    const sec = el('div', 'branched-menu__section');
    const head = el('button', 'branched-menu__head'); head.type = 'button'; head.textContent = item.label;
    head.setAttribute('aria-expanded', 'false');
    head.onclick = () => toggle(i);
    heads[i] = head; sections[i] = sec; reaches[i] = [];
    sec.appendChild(head);

    const kids = item.children || [];
    const bodyH = PAD * 2 + kids.length * rowHeight;
    const body = el('div', 'branched-menu__body'), fold = el('div', 'branched-menu__fold'), tree = el('div', 'branched-menu__tree');
    tree.style.height = bodyH + 'px';
    const s = svg('svg', { class: 'branched-menu__lines', width: indent, height: bodyH, 'aria-hidden': 'true' });
    s.appendChild(svg('path', { class: 'branched-menu__base', d: `M ${trunk} 0 V ${rowY(kids.length - 1) - r}` }));
    kids.forEach((_, k) => s.appendChild(svg('path', { class: 'branched-menu__base', d: branch(k) })));
    kids.forEach((kid, k) => {
      const p = svg('path', { class: 'branched-menu__reach', d: reach(k) });
      p.style.strokeDasharray = length(k);
      p.style.strokeDashoffset = length(k);
      reaches[i].push(p); s.appendChild(p);
    });
    tree.appendChild(s);
    kids.forEach((kid, k) => {
      const b = el('button', 'branched-menu__item'); b.type = 'button'; b.dataset.value = kid.value;
      if (kid.icon) { const ic = el('span', 'branched-menu__icon'); ic.setAttribute('aria-hidden', 'true'); ic.innerHTML = kid.icon; b.appendChild(ic); }
      const lb = el('span', 'branched-menu__label'); lb.textContent = kid.label; b.appendChild(lb);
      b.onclick = () => select(kid.value, kid);
      kid._el = b; tree.appendChild(b);
    });
    fold.appendChild(tree); body.appendChild(fold); sec.appendChild(body);
    nav.appendChild(sec);
  });

  function place(glide) {
    const idx = items.findIndex((it) => (it.children || []).some((k) => k.value === active));
    const on = idx >= 0 && open.has(idx) && heads[idx];
    if (!glide) marker.style.transition = 'none';
    if (on) marker.style.top = (heads[idx].offsetTop + (heads[idx].offsetHeight - MARK) / 2) + 'px';
    marker.toggleAttribute('data-on', Boolean(on));
    if (!glide) { void marker.offsetHeight; marker.style.transition = ''; }
  }
  function paint(glide) {
    items.forEach((item, i) => {
      const isOpen = open.has(i);
      sections[i].toggleAttribute('data-open', isOpen);
      heads[i].setAttribute('aria-expanded', String(isOpen));
      (item.children || []).forEach((kid, k) => {
        const on = kid.value === active;
        kid._el.toggleAttribute('data-active', on);
        kid._el.tabIndex = isOpen ? 0 : -1;
        if (on) kid._el.setAttribute('aria-current', 'true'); else kid._el.removeAttribute('aria-current');
        reaches[i][k].style.strokeDashoffset = on ? 0 : length(k);
      });
    });
    place(glide);
  }
  function select(value, item) { active = value; paint(true); o.onSelect && o.onSelect(value, item); }
  function toggle(i) {
    if (open.has(i)) open.delete(i); else open.add(i);
    paint(true); o.onToggle && o.onToggle(i, open.has(i));
  }

  let first = true;
  new ResizeObserver(() => { if (first) { first = false; return; } place(false); }).observe(nav);
  paint(false);
  return { select: (v) => { const it = items.flatMap((x) => (x.children || []).map((k) => [x, k])).find(([, k]) => k.value === v); if (it) { const i = items.indexOf(it[0]); open.add(i); select(v, it[1]); } } };
}
